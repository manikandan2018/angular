import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SchedulecmpComponent } from './schedulecmp.component';

describe('SchedulecmpComponent', () => {
  let component: SchedulecmpComponent;
  let fixture: ComponentFixture<SchedulecmpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SchedulecmpComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SchedulecmpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
