(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./node_modules/moment/locale sync recursive ^\\.\\/.*$":
/*!**************************************************!*\
  !*** ./node_modules/moment/locale sync ^\.\/.*$ ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./af": "./node_modules/moment/locale/af.js",
	"./af.js": "./node_modules/moment/locale/af.js",
	"./ar": "./node_modules/moment/locale/ar.js",
	"./ar-dz": "./node_modules/moment/locale/ar-dz.js",
	"./ar-dz.js": "./node_modules/moment/locale/ar-dz.js",
	"./ar-kw": "./node_modules/moment/locale/ar-kw.js",
	"./ar-kw.js": "./node_modules/moment/locale/ar-kw.js",
	"./ar-ly": "./node_modules/moment/locale/ar-ly.js",
	"./ar-ly.js": "./node_modules/moment/locale/ar-ly.js",
	"./ar-ma": "./node_modules/moment/locale/ar-ma.js",
	"./ar-ma.js": "./node_modules/moment/locale/ar-ma.js",
	"./ar-sa": "./node_modules/moment/locale/ar-sa.js",
	"./ar-sa.js": "./node_modules/moment/locale/ar-sa.js",
	"./ar-tn": "./node_modules/moment/locale/ar-tn.js",
	"./ar-tn.js": "./node_modules/moment/locale/ar-tn.js",
	"./ar.js": "./node_modules/moment/locale/ar.js",
	"./az": "./node_modules/moment/locale/az.js",
	"./az.js": "./node_modules/moment/locale/az.js",
	"./be": "./node_modules/moment/locale/be.js",
	"./be.js": "./node_modules/moment/locale/be.js",
	"./bg": "./node_modules/moment/locale/bg.js",
	"./bg.js": "./node_modules/moment/locale/bg.js",
	"./bm": "./node_modules/moment/locale/bm.js",
	"./bm.js": "./node_modules/moment/locale/bm.js",
	"./bn": "./node_modules/moment/locale/bn.js",
	"./bn.js": "./node_modules/moment/locale/bn.js",
	"./bo": "./node_modules/moment/locale/bo.js",
	"./bo.js": "./node_modules/moment/locale/bo.js",
	"./br": "./node_modules/moment/locale/br.js",
	"./br.js": "./node_modules/moment/locale/br.js",
	"./bs": "./node_modules/moment/locale/bs.js",
	"./bs.js": "./node_modules/moment/locale/bs.js",
	"./ca": "./node_modules/moment/locale/ca.js",
	"./ca.js": "./node_modules/moment/locale/ca.js",
	"./cs": "./node_modules/moment/locale/cs.js",
	"./cs.js": "./node_modules/moment/locale/cs.js",
	"./cv": "./node_modules/moment/locale/cv.js",
	"./cv.js": "./node_modules/moment/locale/cv.js",
	"./cy": "./node_modules/moment/locale/cy.js",
	"./cy.js": "./node_modules/moment/locale/cy.js",
	"./da": "./node_modules/moment/locale/da.js",
	"./da.js": "./node_modules/moment/locale/da.js",
	"./de": "./node_modules/moment/locale/de.js",
	"./de-at": "./node_modules/moment/locale/de-at.js",
	"./de-at.js": "./node_modules/moment/locale/de-at.js",
	"./de-ch": "./node_modules/moment/locale/de-ch.js",
	"./de-ch.js": "./node_modules/moment/locale/de-ch.js",
	"./de.js": "./node_modules/moment/locale/de.js",
	"./dv": "./node_modules/moment/locale/dv.js",
	"./dv.js": "./node_modules/moment/locale/dv.js",
	"./el": "./node_modules/moment/locale/el.js",
	"./el.js": "./node_modules/moment/locale/el.js",
	"./en-SG": "./node_modules/moment/locale/en-SG.js",
	"./en-SG.js": "./node_modules/moment/locale/en-SG.js",
	"./en-au": "./node_modules/moment/locale/en-au.js",
	"./en-au.js": "./node_modules/moment/locale/en-au.js",
	"./en-ca": "./node_modules/moment/locale/en-ca.js",
	"./en-ca.js": "./node_modules/moment/locale/en-ca.js",
	"./en-gb": "./node_modules/moment/locale/en-gb.js",
	"./en-gb.js": "./node_modules/moment/locale/en-gb.js",
	"./en-ie": "./node_modules/moment/locale/en-ie.js",
	"./en-ie.js": "./node_modules/moment/locale/en-ie.js",
	"./en-il": "./node_modules/moment/locale/en-il.js",
	"./en-il.js": "./node_modules/moment/locale/en-il.js",
	"./en-nz": "./node_modules/moment/locale/en-nz.js",
	"./en-nz.js": "./node_modules/moment/locale/en-nz.js",
	"./eo": "./node_modules/moment/locale/eo.js",
	"./eo.js": "./node_modules/moment/locale/eo.js",
	"./es": "./node_modules/moment/locale/es.js",
	"./es-do": "./node_modules/moment/locale/es-do.js",
	"./es-do.js": "./node_modules/moment/locale/es-do.js",
	"./es-us": "./node_modules/moment/locale/es-us.js",
	"./es-us.js": "./node_modules/moment/locale/es-us.js",
	"./es.js": "./node_modules/moment/locale/es.js",
	"./et": "./node_modules/moment/locale/et.js",
	"./et.js": "./node_modules/moment/locale/et.js",
	"./eu": "./node_modules/moment/locale/eu.js",
	"./eu.js": "./node_modules/moment/locale/eu.js",
	"./fa": "./node_modules/moment/locale/fa.js",
	"./fa.js": "./node_modules/moment/locale/fa.js",
	"./fi": "./node_modules/moment/locale/fi.js",
	"./fi.js": "./node_modules/moment/locale/fi.js",
	"./fo": "./node_modules/moment/locale/fo.js",
	"./fo.js": "./node_modules/moment/locale/fo.js",
	"./fr": "./node_modules/moment/locale/fr.js",
	"./fr-ca": "./node_modules/moment/locale/fr-ca.js",
	"./fr-ca.js": "./node_modules/moment/locale/fr-ca.js",
	"./fr-ch": "./node_modules/moment/locale/fr-ch.js",
	"./fr-ch.js": "./node_modules/moment/locale/fr-ch.js",
	"./fr.js": "./node_modules/moment/locale/fr.js",
	"./fy": "./node_modules/moment/locale/fy.js",
	"./fy.js": "./node_modules/moment/locale/fy.js",
	"./ga": "./node_modules/moment/locale/ga.js",
	"./ga.js": "./node_modules/moment/locale/ga.js",
	"./gd": "./node_modules/moment/locale/gd.js",
	"./gd.js": "./node_modules/moment/locale/gd.js",
	"./gl": "./node_modules/moment/locale/gl.js",
	"./gl.js": "./node_modules/moment/locale/gl.js",
	"./gom-latn": "./node_modules/moment/locale/gom-latn.js",
	"./gom-latn.js": "./node_modules/moment/locale/gom-latn.js",
	"./gu": "./node_modules/moment/locale/gu.js",
	"./gu.js": "./node_modules/moment/locale/gu.js",
	"./he": "./node_modules/moment/locale/he.js",
	"./he.js": "./node_modules/moment/locale/he.js",
	"./hi": "./node_modules/moment/locale/hi.js",
	"./hi.js": "./node_modules/moment/locale/hi.js",
	"./hr": "./node_modules/moment/locale/hr.js",
	"./hr.js": "./node_modules/moment/locale/hr.js",
	"./hu": "./node_modules/moment/locale/hu.js",
	"./hu.js": "./node_modules/moment/locale/hu.js",
	"./hy-am": "./node_modules/moment/locale/hy-am.js",
	"./hy-am.js": "./node_modules/moment/locale/hy-am.js",
	"./id": "./node_modules/moment/locale/id.js",
	"./id.js": "./node_modules/moment/locale/id.js",
	"./is": "./node_modules/moment/locale/is.js",
	"./is.js": "./node_modules/moment/locale/is.js",
	"./it": "./node_modules/moment/locale/it.js",
	"./it-ch": "./node_modules/moment/locale/it-ch.js",
	"./it-ch.js": "./node_modules/moment/locale/it-ch.js",
	"./it.js": "./node_modules/moment/locale/it.js",
	"./ja": "./node_modules/moment/locale/ja.js",
	"./ja.js": "./node_modules/moment/locale/ja.js",
	"./jv": "./node_modules/moment/locale/jv.js",
	"./jv.js": "./node_modules/moment/locale/jv.js",
	"./ka": "./node_modules/moment/locale/ka.js",
	"./ka.js": "./node_modules/moment/locale/ka.js",
	"./kk": "./node_modules/moment/locale/kk.js",
	"./kk.js": "./node_modules/moment/locale/kk.js",
	"./km": "./node_modules/moment/locale/km.js",
	"./km.js": "./node_modules/moment/locale/km.js",
	"./kn": "./node_modules/moment/locale/kn.js",
	"./kn.js": "./node_modules/moment/locale/kn.js",
	"./ko": "./node_modules/moment/locale/ko.js",
	"./ko.js": "./node_modules/moment/locale/ko.js",
	"./ku": "./node_modules/moment/locale/ku.js",
	"./ku.js": "./node_modules/moment/locale/ku.js",
	"./ky": "./node_modules/moment/locale/ky.js",
	"./ky.js": "./node_modules/moment/locale/ky.js",
	"./lb": "./node_modules/moment/locale/lb.js",
	"./lb.js": "./node_modules/moment/locale/lb.js",
	"./lo": "./node_modules/moment/locale/lo.js",
	"./lo.js": "./node_modules/moment/locale/lo.js",
	"./lt": "./node_modules/moment/locale/lt.js",
	"./lt.js": "./node_modules/moment/locale/lt.js",
	"./lv": "./node_modules/moment/locale/lv.js",
	"./lv.js": "./node_modules/moment/locale/lv.js",
	"./me": "./node_modules/moment/locale/me.js",
	"./me.js": "./node_modules/moment/locale/me.js",
	"./mi": "./node_modules/moment/locale/mi.js",
	"./mi.js": "./node_modules/moment/locale/mi.js",
	"./mk": "./node_modules/moment/locale/mk.js",
	"./mk.js": "./node_modules/moment/locale/mk.js",
	"./ml": "./node_modules/moment/locale/ml.js",
	"./ml.js": "./node_modules/moment/locale/ml.js",
	"./mn": "./node_modules/moment/locale/mn.js",
	"./mn.js": "./node_modules/moment/locale/mn.js",
	"./mr": "./node_modules/moment/locale/mr.js",
	"./mr.js": "./node_modules/moment/locale/mr.js",
	"./ms": "./node_modules/moment/locale/ms.js",
	"./ms-my": "./node_modules/moment/locale/ms-my.js",
	"./ms-my.js": "./node_modules/moment/locale/ms-my.js",
	"./ms.js": "./node_modules/moment/locale/ms.js",
	"./mt": "./node_modules/moment/locale/mt.js",
	"./mt.js": "./node_modules/moment/locale/mt.js",
	"./my": "./node_modules/moment/locale/my.js",
	"./my.js": "./node_modules/moment/locale/my.js",
	"./nb": "./node_modules/moment/locale/nb.js",
	"./nb.js": "./node_modules/moment/locale/nb.js",
	"./ne": "./node_modules/moment/locale/ne.js",
	"./ne.js": "./node_modules/moment/locale/ne.js",
	"./nl": "./node_modules/moment/locale/nl.js",
	"./nl-be": "./node_modules/moment/locale/nl-be.js",
	"./nl-be.js": "./node_modules/moment/locale/nl-be.js",
	"./nl.js": "./node_modules/moment/locale/nl.js",
	"./nn": "./node_modules/moment/locale/nn.js",
	"./nn.js": "./node_modules/moment/locale/nn.js",
	"./pa-in": "./node_modules/moment/locale/pa-in.js",
	"./pa-in.js": "./node_modules/moment/locale/pa-in.js",
	"./pl": "./node_modules/moment/locale/pl.js",
	"./pl.js": "./node_modules/moment/locale/pl.js",
	"./pt": "./node_modules/moment/locale/pt.js",
	"./pt-br": "./node_modules/moment/locale/pt-br.js",
	"./pt-br.js": "./node_modules/moment/locale/pt-br.js",
	"./pt.js": "./node_modules/moment/locale/pt.js",
	"./ro": "./node_modules/moment/locale/ro.js",
	"./ro.js": "./node_modules/moment/locale/ro.js",
	"./ru": "./node_modules/moment/locale/ru.js",
	"./ru.js": "./node_modules/moment/locale/ru.js",
	"./sd": "./node_modules/moment/locale/sd.js",
	"./sd.js": "./node_modules/moment/locale/sd.js",
	"./se": "./node_modules/moment/locale/se.js",
	"./se.js": "./node_modules/moment/locale/se.js",
	"./si": "./node_modules/moment/locale/si.js",
	"./si.js": "./node_modules/moment/locale/si.js",
	"./sk": "./node_modules/moment/locale/sk.js",
	"./sk.js": "./node_modules/moment/locale/sk.js",
	"./sl": "./node_modules/moment/locale/sl.js",
	"./sl.js": "./node_modules/moment/locale/sl.js",
	"./sq": "./node_modules/moment/locale/sq.js",
	"./sq.js": "./node_modules/moment/locale/sq.js",
	"./sr": "./node_modules/moment/locale/sr.js",
	"./sr-cyrl": "./node_modules/moment/locale/sr-cyrl.js",
	"./sr-cyrl.js": "./node_modules/moment/locale/sr-cyrl.js",
	"./sr.js": "./node_modules/moment/locale/sr.js",
	"./ss": "./node_modules/moment/locale/ss.js",
	"./ss.js": "./node_modules/moment/locale/ss.js",
	"./sv": "./node_modules/moment/locale/sv.js",
	"./sv.js": "./node_modules/moment/locale/sv.js",
	"./sw": "./node_modules/moment/locale/sw.js",
	"./sw.js": "./node_modules/moment/locale/sw.js",
	"./ta": "./node_modules/moment/locale/ta.js",
	"./ta.js": "./node_modules/moment/locale/ta.js",
	"./te": "./node_modules/moment/locale/te.js",
	"./te.js": "./node_modules/moment/locale/te.js",
	"./tet": "./node_modules/moment/locale/tet.js",
	"./tet.js": "./node_modules/moment/locale/tet.js",
	"./tg": "./node_modules/moment/locale/tg.js",
	"./tg.js": "./node_modules/moment/locale/tg.js",
	"./th": "./node_modules/moment/locale/th.js",
	"./th.js": "./node_modules/moment/locale/th.js",
	"./tl-ph": "./node_modules/moment/locale/tl-ph.js",
	"./tl-ph.js": "./node_modules/moment/locale/tl-ph.js",
	"./tlh": "./node_modules/moment/locale/tlh.js",
	"./tlh.js": "./node_modules/moment/locale/tlh.js",
	"./tr": "./node_modules/moment/locale/tr.js",
	"./tr.js": "./node_modules/moment/locale/tr.js",
	"./tzl": "./node_modules/moment/locale/tzl.js",
	"./tzl.js": "./node_modules/moment/locale/tzl.js",
	"./tzm": "./node_modules/moment/locale/tzm.js",
	"./tzm-latn": "./node_modules/moment/locale/tzm-latn.js",
	"./tzm-latn.js": "./node_modules/moment/locale/tzm-latn.js",
	"./tzm.js": "./node_modules/moment/locale/tzm.js",
	"./ug-cn": "./node_modules/moment/locale/ug-cn.js",
	"./ug-cn.js": "./node_modules/moment/locale/ug-cn.js",
	"./uk": "./node_modules/moment/locale/uk.js",
	"./uk.js": "./node_modules/moment/locale/uk.js",
	"./ur": "./node_modules/moment/locale/ur.js",
	"./ur.js": "./node_modules/moment/locale/ur.js",
	"./uz": "./node_modules/moment/locale/uz.js",
	"./uz-latn": "./node_modules/moment/locale/uz-latn.js",
	"./uz-latn.js": "./node_modules/moment/locale/uz-latn.js",
	"./uz.js": "./node_modules/moment/locale/uz.js",
	"./vi": "./node_modules/moment/locale/vi.js",
	"./vi.js": "./node_modules/moment/locale/vi.js",
	"./x-pseudo": "./node_modules/moment/locale/x-pseudo.js",
	"./x-pseudo.js": "./node_modules/moment/locale/x-pseudo.js",
	"./yo": "./node_modules/moment/locale/yo.js",
	"./yo.js": "./node_modules/moment/locale/yo.js",
	"./zh-cn": "./node_modules/moment/locale/zh-cn.js",
	"./zh-cn.js": "./node_modules/moment/locale/zh-cn.js",
	"./zh-hk": "./node_modules/moment/locale/zh-hk.js",
	"./zh-hk.js": "./node_modules/moment/locale/zh-hk.js",
	"./zh-tw": "./node_modules/moment/locale/zh-tw.js",
	"./zh-tw.js": "./node_modules/moment/locale/zh-tw.js"
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	var id = map[req];
	if(!(id + 1)) { // check for number or string
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return id;
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = "./node_modules/moment/locale sync recursive ^\\.\\/.*$";

/***/ }),

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var _pages_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pages/dashboard/dashboard.component */ "./src/app/pages/dashboard/dashboard.component.ts");
/* harmony import */ var _pages_admin_admin_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./pages/admin/admin.component */ "./src/app/pages/admin/admin.component.ts");
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./login/login.component */ "./src/app/login/login.component.ts");
/* harmony import */ var _pages_stuser_stuser_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./pages/stuser/stuser.component */ "./src/app/pages/stuser/stuser.component.ts");
/* harmony import */ var _pages_stuser_stuserdetails_stuserdetails_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./pages/stuser/stuserdetails/stuserdetails.component */ "./src/app/pages/stuser/stuserdetails/stuserdetails.component.ts");
/* harmony import */ var _pages_stcoach_stcoach_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./pages/stcoach/stcoach.component */ "./src/app/pages/stcoach/stcoach.component.ts");
/* harmony import */ var _pages_stcoach_stcoachdetails_stcoachdetails_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./pages/stcoach/stcoachdetails/stcoachdetails.component */ "./src/app/pages/stcoach/stcoachdetails/stcoachdetails.component.ts");
/* harmony import */ var _pages_admin_stsports_stsports_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./pages/admin/stsports/stsports.component */ "./src/app/pages/admin/stsports/stsports.component.ts");
/* harmony import */ var _pages_admin_stsports_stsportsdetails_stsportsdetails_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./pages/admin/stsports/stsportsdetails/stsportsdetails.component */ "./src/app/pages/admin/stsports/stsportsdetails/stsportsdetails.component.ts");
/* harmony import */ var _pages_admin_stsportsenrollment_stsportsenrollment_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./pages/admin/stsportsenrollment/stsportsenrollment.component */ "./src/app/pages/admin/stsportsenrollment/stsportsenrollment.component.ts");
/* harmony import */ var _pages_admin_stsportsenrollment_stsportsenrollmentdetails_stsportsenrollmentdetails_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./pages/admin/stsportsenrollment/stsportsenrollmentdetails/stsportsenrollmentdetails.component */ "./src/app/pages/admin/stsportsenrollment/stsportsenrollmentdetails/stsportsenrollmentdetails.component.ts");
/* harmony import */ var _pages_admin_stsportssession_stsportssession_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./pages/admin/stsportssession/stsportssession.component */ "./src/app/pages/admin/stsportssession/stsportssession.component.ts");
/* harmony import */ var _pages_admin_stsportssession_stsportssessiondetails_stsportssessiondetails_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./pages/admin/stsportssession/stsportssessiondetails/stsportssessiondetails.component */ "./src/app/pages/admin/stsportssession/stsportssessiondetails/stsportssessiondetails.component.ts");
/* harmony import */ var _pages_admin_stsportssessionstrail_stsportssessionstrail_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./pages/admin/stsportssessionstrail/stsportssessionstrail.component */ "./src/app/pages/admin/stsportssessionstrail/stsportssessionstrail.component.ts");
/* harmony import */ var _pages_admin_stsportssessionstrail_stsportssessionstraildetails_stsportssessionstraildetails_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./pages/admin/stsportssessionstrail/stsportssessionstraildetails/stsportssessionstraildetails.component */ "./src/app/pages/admin/stsportssessionstrail/stsportssessionstraildetails/stsportssessionstraildetails.component.ts");
/* harmony import */ var _pages_admin_stsportsactivation_stsportsactivation_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./pages/admin/stsportsactivation/stsportsactivation.component */ "./src/app/pages/admin/stsportsactivation/stsportsactivation.component.ts");
/* harmony import */ var _pages_admin_stsportsactivation_stsportsactivationdetails_stsportsactivationdetails_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./pages/admin/stsportsactivation/stsportsactivationdetails/stsportsactivationdetails.component */ "./src/app/pages/admin/stsportsactivation/stsportsactivationdetails/stsportsactivationdetails.component.ts");
/* harmony import */ var _pages_admin_stactivationdetails_stactivationdetails_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./pages/admin/stactivationdetails/stactivationdetails.component */ "./src/app/pages/admin/stactivationdetails/stactivationdetails.component.ts");
/* harmony import */ var _pages_admin_stactivationdetails_stactivationdetailsdetails_stactivationdetailsdetails_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./pages/admin/stactivationdetails/stactivationdetailsdetails/stactivationdetailsdetails.component */ "./src/app/pages/admin/stactivationdetails/stactivationdetailsdetails/stactivationdetailsdetails.component.ts");
/* harmony import */ var _pages_admin_sttrainerstatus_sttrainerstatus_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./pages/admin/sttrainerstatus/sttrainerstatus.component */ "./src/app/pages/admin/sttrainerstatus/sttrainerstatus.component.ts");
/* harmony import */ var _pages_admin_sttrainerstatus_sttrainerstatusdetails_sttrainerstatusdetails_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./pages/admin/sttrainerstatus/sttrainerstatusdetails/sttrainerstatusdetails.component */ "./src/app/pages/admin/sttrainerstatus/sttrainerstatusdetails/sttrainerstatusdetails.component.ts");
























var routes = [
    { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
    { path: 'login', component: _login_login_component__WEBPACK_IMPORTED_MODULE_5__["LoginComponent"] },
    { path: 'dashboard', component: _pages_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_3__["DashboardComponent"] },
    { path: 'admin', component: _pages_admin_admin_component__WEBPACK_IMPORTED_MODULE_4__["AdminComponent"] },
    { path: 'stuser', component: _pages_stuser_stuser_component__WEBPACK_IMPORTED_MODULE_6__["STUserComponent"] },
    { path: 'stuser/stuserdetails', component: _pages_stuser_stuserdetails_stuserdetails_component__WEBPACK_IMPORTED_MODULE_7__["STUserdetailsComponent"] },
    { path: 'stcoach', component: _pages_stcoach_stcoach_component__WEBPACK_IMPORTED_MODULE_8__["STCoachComponent"] },
    { path: 'stcoach/stcoachdetails', component: _pages_stcoach_stcoachdetails_stcoachdetails_component__WEBPACK_IMPORTED_MODULE_9__["STCoachdetailsComponent"] },
    { path: 'admin/stsports', component: _pages_admin_stsports_stsports_component__WEBPACK_IMPORTED_MODULE_10__["STSportsComponent"] },
    { path: 'admin/stsports/stsportsdetails', component: _pages_admin_stsports_stsportsdetails_stsportsdetails_component__WEBPACK_IMPORTED_MODULE_11__["STSportsdetailsComponent"] },
    { path: 'admin/stsportsenrollment', component: _pages_admin_stsportsenrollment_stsportsenrollment_component__WEBPACK_IMPORTED_MODULE_12__["STSportsEnrollmentComponent"] },
    { path: 'admin/stsportsenrollment/stsportsenrollmentdetails', component: _pages_admin_stsportsenrollment_stsportsenrollmentdetails_stsportsenrollmentdetails_component__WEBPACK_IMPORTED_MODULE_13__["STSportsEnrollmentdetailsComponent"] },
    { path: 'admin/stsportssession', component: _pages_admin_stsportssession_stsportssession_component__WEBPACK_IMPORTED_MODULE_14__["STSportsSessionComponent"] },
    { path: 'admin/stsportssession/stsportssessiondetails', component: _pages_admin_stsportssession_stsportssessiondetails_stsportssessiondetails_component__WEBPACK_IMPORTED_MODULE_15__["STSportsSessiondetailsComponent"] },
    { path: 'admin/stsportssessionstrail', component: _pages_admin_stsportssessionstrail_stsportssessionstrail_component__WEBPACK_IMPORTED_MODULE_16__["STSportsSessionsTrailComponent"] },
    { path: 'admin/stsportssessionstrail/stsportssessionstraildetails', component: _pages_admin_stsportssessionstrail_stsportssessionstraildetails_stsportssessionstraildetails_component__WEBPACK_IMPORTED_MODULE_17__["STSportsSessionsTraildetailsComponent"] },
    { path: 'admin/stsportsactivation', component: _pages_admin_stsportsactivation_stsportsactivation_component__WEBPACK_IMPORTED_MODULE_18__["STSportsActivationComponent"] },
    { path: 'admin/stsportsactivation/stsportsactivationdetails', component: _pages_admin_stsportsactivation_stsportsactivationdetails_stsportsactivationdetails_component__WEBPACK_IMPORTED_MODULE_19__["STSportsActivationdetailsComponent"] },
    { path: 'admin/stactivationdetails', component: _pages_admin_stactivationdetails_stactivationdetails_component__WEBPACK_IMPORTED_MODULE_20__["STActivationDetailsComponent"] },
    { path: 'admin/stactivationdetails/stactivationdetailsdetails', component: _pages_admin_stactivationdetails_stactivationdetailsdetails_stactivationdetailsdetails_component__WEBPACK_IMPORTED_MODULE_21__["STActivationDetailsdetailsComponent"] },
    { path: 'admin/sttrainerstatus', component: _pages_admin_sttrainerstatus_sttrainerstatus_component__WEBPACK_IMPORTED_MODULE_22__["STTrainerStatusComponent"] },
    { path: 'admin/sttrainerstatus/sttrainerstatusdetails', component: _pages_admin_sttrainerstatus_sttrainerstatusdetails_sttrainerstatusdetails_component__WEBPACK_IMPORTED_MODULE_23__["STTrainerStatusdetailsComponent"] },
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes)]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "main {\r\n    flex: 1;\r\n}\r\n\r\nmain, app-footer {\r\n    margin-left: 250px;\r\n  }\r\n\r\n@media only screen and (max-width : 992px) {\r\n    main, app-footer {\r\n      margin-left: 0;\r\n    }\r\n  }\r\n \r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYXBwLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxRQUFRO0NBQ1g7O0FBRUQ7SUFDSSxtQkFBbUI7R0FDcEI7O0FBR0g7SUFDSTtNQUNFLGVBQWU7S0FDaEI7R0FDRiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsibWFpbiB7XHJcbiAgICBmbGV4OiAxO1xyXG59XHJcblxyXG5tYWluLCBhcHAtZm9vdGVyIHtcclxuICAgIG1hcmdpbi1sZWZ0OiAyNTBweDtcclxuICB9XHJcblxyXG5cclxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoIDogOTkycHgpIHtcclxuICAgIG1haW4sIGFwcC1mb290ZXIge1xyXG4gICAgICBtYXJnaW4tbGVmdDogMDtcclxuICAgIH1cclxuICB9XHJcbiAiXX0= */"

/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-header>\n</app-header>\n<div *ngIf=\"isAuthenticated; else login\" style=\"    display: flex;\nflex-direction: column; flex: 1\" >\n   <app-menu *ngIf=\"adminMenuShow\"></app-menu>\n   \n  <main>\n    <!-- <app-dashboard></app-dashboard> -->\n    <router-outlet></router-outlet>\n  </main>\n  <app-footer></app-footer>\n</div>\n<ng-template #login>\n  <main style=\"margin-left:0px\">\n    <app-login></app-login>\n  </main>\n  <app-footer style=\"margin-left:0px\"></app-footer>\n</ng-template>"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./services/auth.service */ "./src/app/services/auth.service.ts");



var AppComponent = /** @class */ (function () {
    function AppComponent(authService) {
        this.authService = authService;
        this.userMenuShow = false;
        this.adminMenuShow = false;
        this.isAuthenticated = false;
    }
    AppComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.authService.loginEvent$.subscribe(function (id) { return _this.updateAuthentication(); });
        this.isAuthenticated = this.authService.isAuthenicated();
        console.log('Inside ngOnInit  app component  ');
    };
    AppComponent.prototype.ngOnDestroy = function () {
        debugger;
        console.log('Inside  ngOnDestroy app component  ');
        localStorage.removeItem('currentUser');
        localStorage.removeItem('role');
    };
    AppComponent.prototype.beforeUnloadHander = function (event) {
        localStorage.removeItem('currentUser');
        localStorage.removeItem('role');
        //debugger;
    };
    AppComponent.prototype.updateAuthentication = function () {
        console.log('Inside updateAuthentication  app component  ');
        var roleOfUser = localStorage.getItem('role');
        console.log('Printing Local Storage value ' + localStorage.getItem('role'));
        if (roleOfUser == '4') {
            this.userMenuShow = true;
            this.adminMenuShow = false;
        }
        if (roleOfUser == '0') {
            this.userMenuShow = false;
            this.adminMenuShow = true;
        }
        console.log('this.userMenuShow   ' + this.userMenuShow);
        console.log('this.adminMenuShow  ' + this.adminMenuShow);
        this.isAuthenticated = this.authService.isAuthenicated();
        if (this.isAuthenticated) {
            var $toastContent = $('<span class=""><i class="material-icons left green-text">mood</i>Welcome ' + localStorage.getItem('currentUser') + '</span>');
            Materialize.toast($toastContent, 3000);
        }
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["HostListener"])('window:beforeunload', ['$event']),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Function),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [Object]),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:returntype", void 0)
    ], AppComponent.prototype, "beforeUnloadHander", null);
    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")]
        }),
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-custodian',
            template: __webpack_require__(/*! ./appcustodian.component.html */ "./src/app/appcustodian.component.html"),
            styles: [__webpack_require__(/*! ./appcustodian.component.css */ "./src/app/appcustodian.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/esm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var angular2_materialize__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! angular2-materialize */ "./node_modules/angular2-materialize/dist/index.js");
/* harmony import */ var ng2_charts__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ng2-charts */ "./node_modules/ng2-charts/index.js");
/* harmony import */ var ng2_charts__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(ng2_charts__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _header_header_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./header/header.component */ "./src/app/header/header.component.ts");
/* harmony import */ var _footer_footer_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./footer/footer.component */ "./src/app/footer/footer.component.ts");
/* harmony import */ var _menu_menu_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./menu/menu.component */ "./src/app/menu/menu.component.ts");
/* harmony import */ var _pages_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./pages/dashboard/dashboard.component */ "./src/app/pages/dashboard/dashboard.component.ts");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! .//app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _pages_admin_admin_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./pages/admin/admin.component */ "./src/app/pages/admin/admin.component.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/esm5/forms.js");
/* harmony import */ var _angular_Http__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/Http */ "./node_modules/@angular/Http/esm5/http.js");
/* harmony import */ var _login_login_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./login/login.component */ "./src/app/login/login.component.ts");
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./services/auth.service */ "./src/app/services/auth.service.ts");
/* harmony import */ var _pages_stuser_stuser_component__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./pages/stuser/stuser.component */ "./src/app/pages/stuser/stuser.component.ts");
/* harmony import */ var _pages_stuser_stuserdetails_stuserdetails_component__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./pages/stuser/stuserdetails/stuserdetails.component */ "./src/app/pages/stuser/stuserdetails/stuserdetails.component.ts");
/* harmony import */ var _pages_stcoach_stcoach_component__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./pages/stcoach/stcoach.component */ "./src/app/pages/stcoach/stcoach.component.ts");
/* harmony import */ var _pages_stcoach_stcoachdetails_stcoachdetails_component__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./pages/stcoach/stcoachdetails/stcoachdetails.component */ "./src/app/pages/stcoach/stcoachdetails/stcoachdetails.component.ts");
/* harmony import */ var _pages_admin_stsports_stsports_component__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./pages/admin/stsports/stsports.component */ "./src/app/pages/admin/stsports/stsports.component.ts");
/* harmony import */ var _pages_admin_stsports_stsportsdetails_stsportsdetails_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./pages/admin/stsports/stsportsdetails/stsportsdetails.component */ "./src/app/pages/admin/stsports/stsportsdetails/stsportsdetails.component.ts");
/* harmony import */ var _pages_admin_stsportsenrollment_stsportsenrollment_component__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./pages/admin/stsportsenrollment/stsportsenrollment.component */ "./src/app/pages/admin/stsportsenrollment/stsportsenrollment.component.ts");
/* harmony import */ var _pages_admin_stsportsenrollment_stsportsenrollmentdetails_stsportsenrollmentdetails_component__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./pages/admin/stsportsenrollment/stsportsenrollmentdetails/stsportsenrollmentdetails.component */ "./src/app/pages/admin/stsportsenrollment/stsportsenrollmentdetails/stsportsenrollmentdetails.component.ts");
/* harmony import */ var _pages_admin_stsportssession_stsportssession_component__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./pages/admin/stsportssession/stsportssession.component */ "./src/app/pages/admin/stsportssession/stsportssession.component.ts");
/* harmony import */ var _pages_admin_stsportssession_stsportssessiondetails_stsportssessiondetails_component__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./pages/admin/stsportssession/stsportssessiondetails/stsportssessiondetails.component */ "./src/app/pages/admin/stsportssession/stsportssessiondetails/stsportssessiondetails.component.ts");
/* harmony import */ var _pages_admin_stsportssessionstrail_stsportssessionstrail_component__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./pages/admin/stsportssessionstrail/stsportssessionstrail.component */ "./src/app/pages/admin/stsportssessionstrail/stsportssessionstrail.component.ts");
/* harmony import */ var _pages_admin_stsportssessionstrail_stsportssessionstraildetails_stsportssessionstraildetails_component__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./pages/admin/stsportssessionstrail/stsportssessionstraildetails/stsportssessionstraildetails.component */ "./src/app/pages/admin/stsportssessionstrail/stsportssessionstraildetails/stsportssessionstraildetails.component.ts");
/* harmony import */ var _pages_admin_stsportsactivation_stsportsactivation_component__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./pages/admin/stsportsactivation/stsportsactivation.component */ "./src/app/pages/admin/stsportsactivation/stsportsactivation.component.ts");
/* harmony import */ var _pages_admin_stsportsactivation_stsportsactivationdetails_stsportsactivationdetails_component__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./pages/admin/stsportsactivation/stsportsactivationdetails/stsportsactivationdetails.component */ "./src/app/pages/admin/stsportsactivation/stsportsactivationdetails/stsportsactivationdetails.component.ts");
/* harmony import */ var _pages_admin_stactivationdetails_stactivationdetails_component__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./pages/admin/stactivationdetails/stactivationdetails.component */ "./src/app/pages/admin/stactivationdetails/stactivationdetails.component.ts");
/* harmony import */ var _pages_admin_stactivationdetails_stactivationdetailsdetails_stactivationdetailsdetails_component__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ./pages/admin/stactivationdetails/stactivationdetailsdetails/stactivationdetailsdetails.component */ "./src/app/pages/admin/stactivationdetails/stactivationdetailsdetails/stactivationdetailsdetails.component.ts");
/* harmony import */ var _pages_admin_sttrainerstatus_sttrainerstatus_component__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ./pages/admin/sttrainerstatus/sttrainerstatus.component */ "./src/app/pages/admin/sttrainerstatus/sttrainerstatus.component.ts");
/* harmony import */ var _pages_admin_sttrainerstatus_sttrainerstatusdetails_sttrainerstatusdetails_component__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! ./pages/admin/sttrainerstatus/sttrainerstatusdetails/sttrainerstatusdetails.component */ "./src/app/pages/admin/sttrainerstatus/sttrainerstatusdetails/sttrainerstatusdetails.component.ts");
/* harmony import */ var _pagination_pagination_component__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! ./pagination/pagination.component */ "./src/app/pagination/pagination.component.ts");
/* harmony import */ var primeng_schedule__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! primeng/schedule */ "./node_modules/primeng/schedule.js");
/* harmony import */ var primeng_schedule__WEBPACK_IMPORTED_MODULE_35___default = /*#__PURE__*/__webpack_require__.n(primeng_schedule__WEBPACK_IMPORTED_MODULE_35__);
/* harmony import */ var _angular_common_Http__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! @angular/common/Http */ "./node_modules/@angular/common/esm5/http.js");
/* harmony import */ var _services_httpcalls_service__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! ./services/httpcalls.service */ "./src/app/services/httpcalls.service.ts");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/esm5/animations.js");
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! primeng/dialog */ "./node_modules/primeng/dialog.js");
/* harmony import */ var primeng_dialog__WEBPACK_IMPORTED_MODULE_39___default = /*#__PURE__*/__webpack_require__.n(primeng_dialog__WEBPACK_IMPORTED_MODULE_39__);
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! primeng/dropdown */ "./node_modules/primeng/dropdown.js");
/* harmony import */ var primeng_dropdown__WEBPACK_IMPORTED_MODULE_40___default = /*#__PURE__*/__webpack_require__.n(primeng_dropdown__WEBPACK_IMPORTED_MODULE_40__);
/* harmony import */ var primeng_table__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! primeng/table */ "./node_modules/primeng/table.js");
/* harmony import */ var primeng_table__WEBPACK_IMPORTED_MODULE_41___default = /*#__PURE__*/__webpack_require__.n(primeng_table__WEBPACK_IMPORTED_MODULE_41__);
/* harmony import */ var primeng_growl__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! primeng/growl */ "./node_modules/primeng/growl.js");
/* harmony import */ var primeng_growl__WEBPACK_IMPORTED_MODULE_42___default = /*#__PURE__*/__webpack_require__.n(primeng_growl__WEBPACK_IMPORTED_MODULE_42__);
/* harmony import */ var primeng_components_common_messageservice__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! primeng/components/common/messageservice */ "./node_modules/primeng/components/common/messageservice.js");
/* harmony import */ var primeng_components_common_messageservice__WEBPACK_IMPORTED_MODULE_43___default = /*#__PURE__*/__webpack_require__.n(primeng_components_common_messageservice__WEBPACK_IMPORTED_MODULE_43__);
/* harmony import */ var primeng_calendar__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(/*! primeng/calendar */ "./node_modules/primeng/calendar.js");
/* harmony import */ var primeng_calendar__WEBPACK_IMPORTED_MODULE_44___default = /*#__PURE__*/__webpack_require__.n(primeng_calendar__WEBPACK_IMPORTED_MODULE_44__);
/* harmony import */ var primeng_primeng__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(/*! primeng/primeng */ "./node_modules/primeng/primeng.js");
/* harmony import */ var primeng_primeng__WEBPACK_IMPORTED_MODULE_45___default = /*#__PURE__*/__webpack_require__.n(primeng_primeng__WEBPACK_IMPORTED_MODULE_45__);
/* harmony import */ var primeng_inputswitch__WEBPACK_IMPORTED_MODULE_46__ = __webpack_require__(/*! primeng/inputswitch */ "./node_modules/primeng/inputswitch.js");
/* harmony import */ var primeng_inputswitch__WEBPACK_IMPORTED_MODULE_46___default = /*#__PURE__*/__webpack_require__.n(primeng_inputswitch__WEBPACK_IMPORTED_MODULE_46__);
/* harmony import */ var _pages_staff_staff_component__WEBPACK_IMPORTED_MODULE_47__ = __webpack_require__(/*! ./pages/staff/staff.component */ "./src/app/pages/staff/staff.component.ts");
/* harmony import */ var _pages_staff_staffdetails_staffdetails_component__WEBPACK_IMPORTED_MODULE_48__ = __webpack_require__(/*! ./pages/staff/staffdetails/staffdetails.component */ "./src/app/pages/staff/staffdetails/staffdetails.component.ts");













































//import {DropdownModule} from 'primeng/dropdown';
//import { FormsModule, ReactiveFormsModule } from '@angular/forms';
//import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
//import { HttpClientModule } from '@angular/common/Http';
//import {EventService} from './pages/schedulecmp/EventService'
//import { FullCalendar }      from 'fullcalendar/fullcalendar';





var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_5__["AppComponent"],
                _header_header_component__WEBPACK_IMPORTED_MODULE_6__["HeaderComponent"],
                _footer_footer_component__WEBPACK_IMPORTED_MODULE_7__["FooterComponent"],
                _menu_menu_component__WEBPACK_IMPORTED_MODULE_8__["MenuComponent"],
                _pages_dashboard_dashboard_component__WEBPACK_IMPORTED_MODULE_9__["DashboardComponent"],
                _pages_admin_admin_component__WEBPACK_IMPORTED_MODULE_11__["AdminComponent"],
                _login_login_component__WEBPACK_IMPORTED_MODULE_14__["LoginComponent"],
                _pagination_pagination_component__WEBPACK_IMPORTED_MODULE_34__["PaginationComponent"],
                _pages_admin_admin_component__WEBPACK_IMPORTED_MODULE_11__["AdminComponent"],
                _pages_staff_staff_component__WEBPACK_IMPORTED_MODULE_47__["StaffComponent"],
                _pages_staff_staffdetails_staffdetails_component__WEBPACK_IMPORTED_MODULE_48__["StaffdetailsComponent"],
                _pages_stuser_stuser_component__WEBPACK_IMPORTED_MODULE_16__["STUserComponent"],
                _pages_stuser_stuserdetails_stuserdetails_component__WEBPACK_IMPORTED_MODULE_17__["STUserdetailsComponent"],
                _pages_stcoach_stcoach_component__WEBPACK_IMPORTED_MODULE_18__["STCoachComponent"],
                _pages_stcoach_stcoachdetails_stcoachdetails_component__WEBPACK_IMPORTED_MODULE_19__["STCoachdetailsComponent"],
                _pages_admin_stsports_stsports_component__WEBPACK_IMPORTED_MODULE_20__["STSportsComponent"],
                _pages_admin_stsports_stsportsdetails_stsportsdetails_component__WEBPACK_IMPORTED_MODULE_21__["STSportsdetailsComponent"],
                _pages_admin_stsportsenrollment_stsportsenrollment_component__WEBPACK_IMPORTED_MODULE_22__["STSportsEnrollmentComponent"],
                _pages_admin_stsportsenrollment_stsportsenrollmentdetails_stsportsenrollmentdetails_component__WEBPACK_IMPORTED_MODULE_23__["STSportsEnrollmentdetailsComponent"],
                _pages_admin_stsportssession_stsportssession_component__WEBPACK_IMPORTED_MODULE_24__["STSportsSessionComponent"],
                _pages_admin_stsportssession_stsportssessiondetails_stsportssessiondetails_component__WEBPACK_IMPORTED_MODULE_25__["STSportsSessiondetailsComponent"],
                _pages_admin_stsportssessionstrail_stsportssessionstrail_component__WEBPACK_IMPORTED_MODULE_26__["STSportsSessionsTrailComponent"],
                _pages_admin_stsportssessionstrail_stsportssessionstraildetails_stsportssessionstraildetails_component__WEBPACK_IMPORTED_MODULE_27__["STSportsSessionsTraildetailsComponent"],
                _pages_admin_stsportsactivation_stsportsactivation_component__WEBPACK_IMPORTED_MODULE_28__["STSportsActivationComponent"],
                _pages_admin_stsportsactivation_stsportsactivationdetails_stsportsactivationdetails_component__WEBPACK_IMPORTED_MODULE_29__["STSportsActivationdetailsComponent"],
                _pages_admin_stactivationdetails_stactivationdetails_component__WEBPACK_IMPORTED_MODULE_30__["STActivationDetailsComponent"],
                _pages_admin_stactivationdetails_stactivationdetailsdetails_stactivationdetailsdetails_component__WEBPACK_IMPORTED_MODULE_31__["STActivationDetailsdetailsComponent"],
                _pages_admin_sttrainerstatus_sttrainerstatus_component__WEBPACK_IMPORTED_MODULE_32__["STTrainerStatusComponent"],
                _pages_admin_sttrainerstatus_sttrainerstatusdetails_sttrainerstatusdetails_component__WEBPACK_IMPORTED_MODULE_33__["STTrainerStatusdetailsComponent"],
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
                angular2_materialize__WEBPACK_IMPORTED_MODULE_3__["MaterializeModule"],
                _app_routing_module__WEBPACK_IMPORTED_MODULE_10__["AppRoutingModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_12__["FormsModule"],
                _angular_Http__WEBPACK_IMPORTED_MODULE_13__["HttpModule"],
                ng2_charts__WEBPACK_IMPORTED_MODULE_4__["ChartsModule"],
                primeng_table__WEBPACK_IMPORTED_MODULE_41__["TableModule"], primeng_dialog__WEBPACK_IMPORTED_MODULE_39__["DialogModule"],
                primeng_dropdown__WEBPACK_IMPORTED_MODULE_40__["DropdownModule"],
                primeng_growl__WEBPACK_IMPORTED_MODULE_42__["GrowlModule"],
                _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_38__["BrowserAnimationsModule"],
                primeng_schedule__WEBPACK_IMPORTED_MODULE_35__["ScheduleModule"],
                _angular_common_Http__WEBPACK_IMPORTED_MODULE_36__["HttpClientModule"],
                primeng_calendar__WEBPACK_IMPORTED_MODULE_44__["CalendarModule"],
                primeng_primeng__WEBPACK_IMPORTED_MODULE_45__["SharedModule"],
                primeng_primeng__WEBPACK_IMPORTED_MODULE_45__["ChartModule"],
                primeng_inputswitch__WEBPACK_IMPORTED_MODULE_46__["InputSwitchModule"],
                primeng_primeng__WEBPACK_IMPORTED_MODULE_45__["FileUploadModule"]
            ],
            providers: [
                _services_auth_service__WEBPACK_IMPORTED_MODULE_15__["AuthService"], _services_httpcalls_service__WEBPACK_IMPORTED_MODULE_37__["HhttpcallsService"], primeng_components_common_messageservice__WEBPACK_IMPORTED_MODULE_43__["MessageService"]
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_5__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/appcustodian.component.css":
/*!********************************************!*\
  !*** ./src/app/appcustodian.component.css ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "main {\r\n    flex: 1;\r\n}\r\n\r\nmain, app-footer {\r\n    margin-left: 250px;\r\n  }\r\n\r\n@media only screen and (max-width : 992px) {\r\n    main, app-footer {\r\n      margin-left: 0;\r\n    }\r\n  }\r\n\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYXBwY3VzdG9kaWFuLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSxRQUFRO0NBQ1g7O0FBRUQ7SUFDSSxtQkFBbUI7R0FDcEI7O0FBR0g7SUFDSTtNQUNFLGVBQWU7S0FDaEI7R0FDRiIsImZpbGUiOiJzcmMvYXBwL2FwcGN1c3RvZGlhbi5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsibWFpbiB7XHJcbiAgICBmbGV4OiAxO1xyXG59XHJcblxyXG5tYWluLCBhcHAtZm9vdGVyIHtcclxuICAgIG1hcmdpbi1sZWZ0OiAyNTBweDtcclxuICB9XHJcblxyXG5cclxuQG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoIDogOTkycHgpIHtcclxuICAgIG1haW4sIGFwcC1mb290ZXIge1xyXG4gICAgICBtYXJnaW4tbGVmdDogMDtcclxuICAgIH1cclxuICB9XHJcblxyXG4iXX0= */"

/***/ }),

/***/ "./src/app/appcustodian.component.html":
/*!*********************************************!*\
  !*** ./src/app/appcustodian.component.html ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-header>\n</app-header>\n<div *ngIf=\"isAuthenticated; else login\" style=\"    display: flex;\nflex-direction: column; flex: 1\" >\n  <!-- <app-menu></app-menu> -->\n  <main>\n    <!-- <app-dashboard></app-dashboard> -->\n    <router-outlet></router-outlet>\n  </main>\n  <app-footer></app-footer>\n</div>\n<ng-template #login>\n  <main style=\"margin-left:0px\">\n    <app-login></app-login>\n  </main>\n  <app-footer style=\"margin-left:0px\"></app-footer>\n</ng-template>"

/***/ }),

/***/ "./src/app/footer/footer.component.css":
/*!*********************************************!*\
  !*** ./src/app/footer/footer.component.css ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2Zvb3Rlci9mb290ZXIuY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/footer/footer.component.html":
/*!**********************************************!*\
  !*** ./src/app/footer/footer.component.html ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n  <footer class=\"page-footer grey darken-2\">    \n    <div class=\"footer-copyright\">\n      <div class=\"container\">\n          \n     <h6> <a class=\"white-text text-lighten-4\" target=\"_blank\" href=\"https://skillteck.co/\"> Powered by  SKILLTECK TECHNOLOGIES - \nTaking you to Tomorrow</a></h6>\n      </div>\n    </div>\n  </footer>\n\n"

/***/ }),

/***/ "./src/app/footer/footer.component.ts":
/*!********************************************!*\
  !*** ./src/app/footer/footer.component.ts ***!
  \********************************************/
/*! exports provided: FooterComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FooterComponent", function() { return FooterComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");


var FooterComponent = /** @class */ (function () {
    function FooterComponent() {
    }
    FooterComponent.prototype.ngOnInit = function () {
    };
    FooterComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-footer',
            template: __webpack_require__(/*! ./footer.component.html */ "./src/app/footer/footer.component.html"),
            styles: [__webpack_require__(/*! ./footer.component.css */ "./src/app/footer/footer.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], FooterComponent);
    return FooterComponent;
}());



/***/ }),

/***/ "./src/app/header/header.component.css":
/*!*********************************************!*\
  !*** ./src/app/header/header.component.css ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".material-icons.md-36 { \r\n    font-size: 36px; \r\n}\r\n\r\n \r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaGVhZGVyL2hlYWRlci5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksZ0JBQWdCO0NBQ25CIiwiZmlsZSI6InNyYy9hcHAvaGVhZGVyL2hlYWRlci5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm1hdGVyaWFsLWljb25zLm1kLTM2IHsgXHJcbiAgICBmb250LXNpemU6IDM2cHg7IFxyXG59XHJcblxyXG4gIl19 */"

/***/ }),

/***/ "./src/app/header/header.component.html":
/*!**********************************************!*\
  !*** ./src/app/header/header.component.html ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"navbar-fixed\">\n  <nav>\n    <div class=\"nav-wrapper grey darken-2\" style=\"overflow: hidden\">\n      <a  href=\"#\" data-activates=\"slide-out\" class=\"button-collapse\" ><i class=\"material-icons\">menu</i></a>\n      <!-- <a href=\"#\" class=\"brand-logo white\" style=\"width: 250px; height: 64px;\"><img src=\"https://res.cloudinary.com/dvpdghjuk/image/upload/v1547435181/isms_logo.png\" style=\"height: 64px\" /><i class=\"material-icons md-36 red-text text-darken-4 white\" style=\"font-size:40px; margin-right: 0px; padding: 0px 15px;\">school</i></a> -->\n        \n      <ul  class=\"center\"  >\n       <!--  <li><a  style=\"width: 250px; height: 64px;\"><img src=\"https://res.cloudinary.com/dvpdghjuk/image/upload/v1565853340/mmslogo.png\" style=\"height: 64px\" /> -->\n           <li><a  style=\"width: 250px; height: 64px;\"><img src=\"https://res.cloudinary.com/ddhwpdeaj/image/upload/v1588179714/sklogosmall_luj0pe.png\" style=\"height: 64px\" />\n\n\n          </a></li>\n        <li> <h4> </h4> </li>\n        <li> <div class=\"headerName\"><h5>Skillteck Admin</h5> </div></li>\n        <li> <h4> </h4> </li>\n      </ul>\n\n<ul id=\"nav-mobile\" class=\"right\" *ngIf=\"isAuthenticated\">\n         <li (click)=\"logout()\"><a><i class=\"material-icons \">logout</i></a></li>\n      </ul>\n    </div>\n  </nav>\n\n \n</div> \n "

/***/ }),

/***/ "./src/app/header/header.component.ts":
/*!********************************************!*\
  !*** ./src/app/header/header.component.ts ***!
  \********************************************/
/*! exports provided: HeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderComponent", function() { return HeaderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs/_esm5/add/operator/map.js");
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/auth.service */ "./src/app/services/auth.service.ts");




var HeaderComponent = /** @class */ (function () {
    function HeaderComponent(authService) {
        this.authService = authService;
        this.isAuthenticated = false;
    }
    HeaderComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.authService.loginEvent$.subscribe(function (id) { return _this.updateAuthentication(); });
        this.updateAuthentication();
    };
    HeaderComponent.prototype.logout = function () {
        this.authService.logout();
    };
    HeaderComponent.prototype.updateAuthentication = function () {
        this.isAuthenticated = this.authService.isAuthenicated();
    };
    HeaderComponent.prototype.toggleSideNav = function () {
        if (this.isAuthenticated) {
            $("#slide-out").sideNav("show");
        }
    };
    HeaderComponent.prototype.ngAfterViewChecked = function () {
    };
    HeaderComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-header',
            template: __webpack_require__(/*! ./header.component.html */ "./src/app/header/header.component.html"),
            styles: [__webpack_require__(/*! ./header.component.css */ "./src/app/header/header.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"]])
    ], HeaderComponent);
    return HeaderComponent;
}());



/***/ }),

/***/ "./src/app/login/login.component.css":
/*!*******************************************!*\
  !*** ./src/app/login/login.component.css ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".container  {\r\n   height: 100%;\r\n  width: 100%;\r\n\r\n}\r\n \r\n.container .row {\r\n  margin: 0 auto;\r\n\r\n}\r\n \r\n.login-container{\r\n     margin-top: 5%;\r\n    margin-bottom: 5%;\r\n}\r\n \r\n.login-form-1{\r\n    padding: 3%;\r\n    box-shadow: 0 5px 8px 0 rgba(0, 0, 0, 0.2), 0 9px 26px 0 rgba(0, 0, 0, 0.19);\r\n}\r\n \r\n.login-form-1 h3{\r\n    text-align: center;\r\n    color: #333;\r\n}\r\n \r\n.login-form-2{\r\n    padding: 5%;\r\n    background: #455d83;\r\n    box-shadow: 0 5px 8px 0 rgba(0, 0, 0, 0.2), 0 9px 26px 0 rgba(0, 0, 0, 0.19);\r\n}\r\n \r\n.login-form-2 h3{\r\n    text-align: center;\r\n    color: #fff;\r\n}\r\n \r\n.login-container form{\r\n    padding: 1%;\r\n}\r\n \r\n.btnSubmit\r\n{\r\n    width: 50%;\r\n    border-radius: 1rem;\r\n    padding: 1.5%;\r\n    border: none;\r\n    cursor: pointer;\r\n}\r\n \r\n.login-form-1 .btnSubmit{\r\n    font-weight: 600;\r\n    color: #fff;\r\n    background-color: #0062cc;\r\n}\r\n \r\n.login-form-2 .btnSubmit{\r\n    font-weight: 600;\r\n    color: #0062cc;\r\n    background-color: #fff;\r\n}\r\n \r\n.login-form-2 .ForgetPwd{\r\n    color: #fff;\r\n    font-weight: 600;\r\n    text-decoration: none;\r\n}\r\n \r\n.login-form-1 .ForgetPwd{\r\n    color: #0062cc;\r\n    font-weight: 600;\r\n    text-decoration: none;\r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbG9naW4vbG9naW4uY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtHQUNHLGFBQWE7RUFDZCxZQUFZOztDQUViOztBQUVEO0VBQ0UsZUFBZTs7Q0FFaEI7O0FBQ0Q7S0FDSyxlQUFlO0lBQ2hCLGtCQUFrQjtDQUNyQjs7QUFDRDtJQUNJLFlBQVk7SUFDWiw2RUFBNkU7Q0FDaEY7O0FBQ0Q7SUFDSSxtQkFBbUI7SUFDbkIsWUFBWTtDQUNmOztBQUNEO0lBQ0ksWUFBWTtJQUNaLG9CQUFvQjtJQUNwQiw2RUFBNkU7Q0FDaEY7O0FBQ0Q7SUFDSSxtQkFBbUI7SUFDbkIsWUFBWTtDQUNmOztBQUNEO0lBQ0ksWUFBWTtDQUNmOztBQUNEOztJQUVJLFdBQVc7SUFDWCxvQkFBb0I7SUFDcEIsY0FBYztJQUNkLGFBQWE7SUFDYixnQkFBZ0I7Q0FDbkI7O0FBQ0Q7SUFDSSxpQkFBaUI7SUFDakIsWUFBWTtJQUNaLDBCQUEwQjtDQUM3Qjs7QUFDRDtJQUNJLGlCQUFpQjtJQUNqQixlQUFlO0lBQ2YsdUJBQXVCO0NBQzFCOztBQUNEO0lBQ0ksWUFBWTtJQUNaLGlCQUFpQjtJQUNqQixzQkFBc0I7Q0FDekI7O0FBQ0Q7SUFDSSxlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLHNCQUFzQjtDQUN6QiIsImZpbGUiOiJzcmMvYXBwL2xvZ2luL2xvZ2luLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY29udGFpbmVyICB7XHJcbiAgIGhlaWdodDogMTAwJTtcclxuICB3aWR0aDogMTAwJTtcclxuXHJcbn1cclxuIFxyXG4uY29udGFpbmVyIC5yb3cge1xyXG4gIG1hcmdpbjogMCBhdXRvO1xyXG5cclxufVxyXG4ubG9naW4tY29udGFpbmVye1xyXG4gICAgIG1hcmdpbi10b3A6IDUlO1xyXG4gICAgbWFyZ2luLWJvdHRvbTogNSU7XHJcbn1cclxuLmxvZ2luLWZvcm0tMXtcclxuICAgIHBhZGRpbmc6IDMlO1xyXG4gICAgYm94LXNoYWRvdzogMCA1cHggOHB4IDAgcmdiYSgwLCAwLCAwLCAwLjIpLCAwIDlweCAyNnB4IDAgcmdiYSgwLCAwLCAwLCAwLjE5KTtcclxufVxyXG4ubG9naW4tZm9ybS0xIGgze1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgY29sb3I6ICMzMzM7XHJcbn1cclxuLmxvZ2luLWZvcm0tMntcclxuICAgIHBhZGRpbmc6IDUlO1xyXG4gICAgYmFja2dyb3VuZDogIzQ1NWQ4MztcclxuICAgIGJveC1zaGFkb3c6IDAgNXB4IDhweCAwIHJnYmEoMCwgMCwgMCwgMC4yKSwgMCA5cHggMjZweCAwIHJnYmEoMCwgMCwgMCwgMC4xOSk7XHJcbn1cclxuLmxvZ2luLWZvcm0tMiBoM3tcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGNvbG9yOiAjZmZmO1xyXG59XHJcbi5sb2dpbi1jb250YWluZXIgZm9ybXtcclxuICAgIHBhZGRpbmc6IDElO1xyXG59XHJcbi5idG5TdWJtaXRcclxue1xyXG4gICAgd2lkdGg6IDUwJTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDFyZW07XHJcbiAgICBwYWRkaW5nOiAxLjUlO1xyXG4gICAgYm9yZGVyOiBub25lO1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG59XHJcbi5sb2dpbi1mb3JtLTEgLmJ0blN1Ym1pdHtcclxuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICBjb2xvcjogI2ZmZjtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICMwMDYyY2M7XHJcbn1cclxuLmxvZ2luLWZvcm0tMiAuYnRuU3VibWl0e1xyXG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgIGNvbG9yOiAjMDA2MmNjO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcclxufVxyXG4ubG9naW4tZm9ybS0yIC5Gb3JnZXRQd2R7XHJcbiAgICBjb2xvcjogI2ZmZjtcclxuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XHJcbn1cclxuLmxvZ2luLWZvcm0tMSAuRm9yZ2V0UHdke1xyXG4gICAgY29sb3I6ICMwMDYyY2M7XHJcbiAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xyXG59XHJcbiJdfQ== */"

/***/ }),

/***/ "./src/app/login/login.component.html":
/*!********************************************!*\
  !*** ./src/app/login/login.component.html ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!--  \n\n       \n        \n\n<div class=\"row tm-services-row\">\n\n                <div class=\"col-xs-12 col-sm-12 col-md-12 col-lg-4 col-xl-4 tm-services-col-left\">\n                    \n                    <div>\n                        <img src=\"https://res.cloudinary.com/ddhwpdeaj/image/upload/v1585163325/samples/bllogo_it4euk.png\" alt=\"Image\" class=\"img-fluid col-xs-6 col-sm-6 col-md-6 col-lg-6 col-xl-6 tm-pad-0\">\n                         \n                    </div>\n                    \n                </div>\n                \n                <div class=\"col-xs-12 col-sm-12 col-md-12 col-lg-8 col-xl-8 tm-services-col-right\">                    \n                    <div class=\"tm-services-box\">\n                        <h2 class=\"tm-blue-text tm-services-title\"><b>ANDHRA PRADESH POLICE</b></h2>\n                        <p class=\"tm-services-description\"><b>Mission :</b> The officers and men of AP Police Department are committed to providing professional law enforcement services, protecting the rights of individuals, preventing crime, and building community partnerships.We will serve the community with integrity, diversity, and quality and to provide proactive interaction with the community to enhance the feeling of safety and security in the state.The AP Police Department, in affiliation with our community, is committed to serve the needs of the citizens of India by providing an efficient and effective level of service through crime prevention and protection programs. \n                        \n                        <b>Vision:</b> AP Police Department is committed to delivering the most efficient, effective, productive, and quality police service to the community. We are dedicated to the advancement of a cooperative partnership with our community to develop better community policing, improved communications, and reduced crime. We shall strive to develop a comprehensive strategy to resolve public safety issues, and enhance the quality of life within our community. The AP Police Department is an open, friendly, and community-minded organization devoted to quality public service, unyielding in purpose and dedicated to live by values reflecting a genuine desire to care for the safety and well-being of the public.</p>                       \n                    </div>\n                    \n                </div>\n\n            </div>\n\n           \n         \n  -->\n\n   <link href=\"//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css\" rel=\"stylesheet\" id=\"bootstrap-css\">\n<script src=\"//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js\"></script>\n<script src=\"//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>\n<!------ Include the above in your HEAD tag ---------->\n\n<div class=\"container login-container \" >\n            <div class=\"row\">\n                <div class=\"col-md-5 login-form-1\">\n                    <h3>Skillteck</h3>\n                    <form>\n                      <img src='https://res.cloudinary.com/ddhwpdeaj/image/upload/v1588179297/samples/sklogo_xsfhxd.png'   height=\"380\" width=\"360\" />\n                    </form>\n                </div>\n                <div class=\"col-md-4 login-form-2\">\n                    <h3>Login  </h3>\n                    <form>\n                        <div class=\"form-group\">\n                            <input type=\"text\" id=\"first_name\" type=\"text\" class=\"validate\" [(ngModel)]=\"username\" name=\"username \"/>\n                        </div>\n                        <div class=\"form-group\">\n                            <input type=\"password\" id=\"password\" type=\"password\" class=\"validate\" [(ngModel)]=\"password\" name=\"password\" />\n                        </div>\n                        <div class=\"form-group\">\n                            <input type=\"submit\" class=\"btnSubmit\" value=\"Login\" (click)=\"login()\"  />\n                        </div>\n                        <div class=\"form-group\">\n\n                            <a   class=\"ForgetPwd\" value=\"Login\">Forget Password?</a>\n                        </div>\n                    </form>\n                </div>\n            </div>\n        </div> "

/***/ }),

/***/ "./src/app/login/login.component.ts":
/*!******************************************!*\
  !*** ./src/app/login/login.component.ts ***!
  \******************************************/
/*! exports provided: LoginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginComponent", function() { return LoginComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/auth.service */ "./src/app/services/auth.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/esm5/router.js");




var LoginComponent = /** @class */ (function () {
    function LoginComponent(authService, router) {
        this.authService = authService;
        this.router = router;
        this.isLogin = true;
        this.isLoading = false;
    }
    LoginComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.authService.loginEvent$.subscribe(function (id) { return _this.isLoading = false; });
    };
    LoginComponent.prototype.login = function () {
        this.isLoading = true;
        this.authService.login(this.username, this.password);
    };
    LoginComponent.prototype.forgotPasswordClick = function () {
        this.isLogin = false;
    };
    LoginComponent.prototype.recover = function () {
        console.log("Send email to " + this.email);
        this.authService.recover(this.email);
        this.isLogin = true;
    };
    LoginComponent.prototype.cancel = function () {
        this.isLogin = true;
    };
    LoginComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-login',
            template: __webpack_require__(/*! ./login.component.html */ "./src/app/login/login.component.html"),
            styles: [__webpack_require__(/*! ./login.component.css */ "./src/app/login/login.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]])
    ], LoginComponent);
    return LoginComponent;
}());



/***/ }),

/***/ "./src/app/menu/menu.component.css":
/*!*****************************************!*\
  !*** ./src/app/menu/menu.component.css ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL21lbnUvbWVudS5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/menu/menu.component.html":
/*!******************************************!*\
  !*** ./src/app/menu/menu.component.html ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"adminMenu\">\n<ul  id=\"slide-out\" class=\"side-nav fixed  orange lighten-5\">\n  <hr>\n  <li><a [routerLink]=\"['./dashboard']\" routerLinkActive=\"   deep-orange lighten-5\" class=\"waves-effect\"><i class=\"material-icons\">dashboard</i>Dashboard</a></li><hr>\n  <li><a [routerLink]=\"['./admin']\" routerLinkActive=\"   deep-orange lighten-5\" class=\"waves-effect\" href=\"#!\"><i class=\"material-icons\">enhanced_encryption</i>Config</a></li><hr>\n <!--  <li><a  [routerLink]=\"['./spoorsemployees']\" routerLinkActive=\"   deep-orange lighten-5\" class=\"waves-effect\" ><i class=\"material-icons\">group</i>Employees</a></li>\n  \n  \n\n  <li><a   routerLinkActive=\"   deep-orange lighten-5\" class=\"waves-effect\" ><i class=\"material-icons\">business</i>Departments</a></li>\n  <li><a  routerLinkActive=\"   deep-orange lighten-5\" class=\"waves-effect\" ><i class=\"material-icons\">account_box</i>Customers</a></li>\n  <li><a  routerLinkActive=\"   deep-orange lighten-5\" class=\"waves-effect\" ><i class=\"material-icons\">network_check</i>Tasks</a></li> -->\n   \n   <li><a [routerLink]=\"['./stuser']\" routerLinkActive=\"    deep-orange lighten-5\" class=\"waves-effect\" ><i class=\"material-icons\">sports_handball</i>STUser</a></li><hr>\n\n    <li><a [routerLink]=\"['./stcoach']\" routerLinkActive=\"deep-orange lighten-5\" class=\"waves-effect\" ><i class=\"material-icons\">sports</i>STCoach</a></li><hr>\n\n    \n    \n\n\n <!--  <li><a [routerLink]=\"['./ragamusicprofile']\" routerLinkActive=\"   deep-orange lighten-5\" class=\"waves-effect\" ><i class=\"material-icons\">movie_filter</i>Music profile</a></li>\n  <li><a [routerLink]=\"['./ragalistenandlearn']\" routerLinkActive=\"   deep-orange lighten-5\" class=\"waves-effect\" href=\"#!\"><i class=\"material-icons\">radio</i>  Listen and earn</a></li>\n  <li><a [routerLink]=\"['./ragavisualpractice']\" routerLinkActive=\"active  deep-orange lighten-5\" class=\"waves-effect\" href=\"#!\"><i class=\"material-icons\">music_video</i>  Visual practice</a></li>\n  <li><a [routerLink]=\"['./ragafeedback']\" routerLinkActive=\"   deep-orange lighten-5\" class=\"waves-effect\" href=\"#!\"><i class=\"material-icons\">feedback</i> Feedback</a></li> \n \n   \n   <li><a [routerLink]=\"['./staff']\"class=\"waves-effect\"><i class=\"material-icons\">group</i>Staff</a></li> \n    <li><a [routerLink]=\"['./workallocate']\"class=\"waves-effect\"><i class=\"material-icons\">work</i>Allocate Work</a></li> \n \n<li><a [routerLink]=\"['./reports']\"class=\"waves-effect\"><i class=\"material-icons\">work</i>Reports</a></li> \n   -->\n</ul>\n</div>\n"

/***/ }),

/***/ "./src/app/menu/menu.component.ts":
/*!****************************************!*\
  !*** ./src/app/menu/menu.component.ts ***!
  \****************************************/
/*! exports provided: MenuComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MenuComponent", function() { return MenuComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");


var MenuComponent = /** @class */ (function () {
    function MenuComponent() {
    }
    MenuComponent.prototype.ngOnInit = function () {
        $(".button-collapse").sideNav({
            menuWidth: 250,
            closeOnClick: true,
            draggable: true
        });
    };
    MenuComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-menu',
            template: __webpack_require__(/*! ./menu.component.html */ "./src/app/menu/menu.component.html"),
            styles: [__webpack_require__(/*! ./menu.component.css */ "./src/app/menu/menu.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], MenuComponent);
    return MenuComponent;
}());



/***/ }),

/***/ "./src/app/pages/admin/admin.component.css":
/*!*************************************************!*\
  !*** ./src/app/pages/admin/admin.component.css ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2FkbWluL2FkbWluLmNvbXBvbmVudC5jc3MifQ== */"

/***/ }),

/***/ "./src/app/pages/admin/admin.component.html":
/*!**************************************************!*\
  !*** ./src/app/pages/admin/admin.component.html ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">\n<nav class=\"z-depth-0\">\n  <div class=\"nav-wrapper white \">\n    <div class=\"col s12\">\n      <a [routerLink]=\"['./']\" class=\"breadcrumb grey-text text-darken-2\">Configuration</a>\n    </div>\n  </div>\n</nav>\n<div class=\"row\" style=\"padding: 0px 20px\">\n<ul class=\"collapsible popout z-depth-5\" data-collapsible=\"accordion\">\n<li>\n<div class=\"collapsible-header   text-darken-4 active  grey lighten-3\" style=\"font-size: 20px\"><i class=\"material-icons amber-text text-darken-4\" style=\"font-size: 30px\">looks_one</i> Basic Configuration</div>\n  <div class=\"collapsible-body\">\n      <div class=\"row\">\n   <div class=\"col s7 m3 l2\">\n            <a [routerLink]=\"['./stsports']\">\n            <div class=\"card indigo darken-4 \" style=\"cursor: pointer\">\n              <div class=\"card-content white-text z-depth-5 \">\n                <span class=\"card-title\">Sports</span>\n                <i class=\"small material-icons \" style=\"margin-top: 10px;\">sports_tennis</i>\n              </div>\n            </div>\n            </a> \n        </div>\n\n        <div class=\"col s7 m3 l2\">\n            <a [routerLink]=\"['./stsportsenrollment']\">\n            <div class=\"card indigo darken-4 \" style=\"cursor: pointer\">\n              <div class=\"card-content white-text z-depth-5 \">\n                <span class=\"card-title\">Sports Enrollment</span>\n                <i class=\"small material-icons \" style=\"margin-top: 10px;\">sports_kabaddi</i>\n              </div>\n            </div>\n            </a> \n        </div>\n\n        <div class=\"col s7 m3 l2\">\n            <a [routerLink]=\"['./stsportssession']\">\n            <div class=\"card indigo darken-4 \" style=\"cursor: pointer\">\n              <div class=\"card-content white-text z-depth-5 \">\n                <span class=\"card-title\">Sports Session</span>\n                <i class=\"small material-icons \" style=\"margin-top: 10px;\">sports_mma</i>\n              </div>\n            </div>\n            </a> \n        </div>\n\n        <div class=\"col s7 m3 l2\">\n            <a [routerLink]=\"['./stsportssessionstrail']\">\n            <div class=\"card indigo darken-4 \" style=\"cursor: pointer\">\n              <div class=\"card-content white-text z-depth-5 \">\n                <span class=\"card-title\">Sports SessionTrail</span>\n                <i class=\"small material-icons \" style=\"margin-top: 10px;\">sports_hockey</i>\n              </div>\n            </div>\n            </a> \n        </div>\n\n        \n        <div class=\"col s7 m3 l2\">\n            <a [routerLink]=\"['./stsportsactivation']\">\n            <div class=\"card indigo darken-4 \" style=\"cursor: pointer\">\n              <div class=\"card-content white-text z-depth-5 \">\n                <span class=\"card-title\">Sports Activation</span>\n                <i class=\"small material-icons \" style=\"margin-top: 10px;\">sports_basketball</i>\n              </div>\n            </div>\n            </a> \n        </div>\n\n\n        <div class=\"col s7 m3 l2\">\n            <a [routerLink]=\"['./stactivationdetails']\">\n            <div class=\"card indigo darken-4 \" style=\"cursor: pointer\">\n              <div class=\"card-content white-text z-depth-5 \">\n                <span class=\"card-title\">Activation Details</span>\n                <i class=\"small material-icons \" style=\"margin-top: 10px;\">sports_cricket</i>\n              </div>\n            </div>\n            </a> \n        </div>\n\n\n        <div class=\"col s7 m3 l2\">\n            <a [routerLink]=\"['./sttrainerstatus']\">\n            <div class=\"card indigo darken-4 \" style=\"cursor: pointer\">\n              <div class=\"card-content white-text z-depth-5 \">\n                <span class=\"card-title\"> Trainer Status</span>\n                <i class=\"small material-icons \" style=\"margin-top: 10px;\">sports_football</i>\n              </div>\n            </div>\n            </a> \n        </div>\n\n\n  </div>\n   <a class=\"waves-effect  pink darken-4 btn\" (click)=\"moveNext($event, 1)\" >Next</a>\n  </div> \n</li> \n\n\n\n<li>\n    <div class=\"collapsible-header   text-darken-4 grey lighten-5\" style=\"font-size: 20px\"><i class=\"material-icons amber-text text-darken-4\" style=\"font-size: 30px\">looks_two</i> Reports</div>\n      <div class=\"collapsible-body \">\n        <div class=\"row\">\n                     <!--  <div class=\"col s7 m3 l2\">\n            <a  >\n            <div class=\"card indigo darken-4 \" style=\"cursor: pointer\">\n              <div class=\"card-content white-text z-depth-5 \">\n                <span class=\"card-title\">Sales Reports</span>\n                <i class=\"small material-icons \" style=\"margin-top: 10px;\">gradient</i>\n              </div>\n            </div>\n            </a>\n        </div>\n        \n        <div class=\"col s7 m3 l2\">\n            <a [routerLink]=\"['./stsports']\">\n            <div class=\"card indigo darken-4 \" style=\"cursor: pointer\">\n              <div class=\"card-content white-text z-depth-5 \">\n                <span class=\"card-title\">STSports</span>\n                <i class=\"small material-icons \" style=\"margin-top: 10px;\">people</i>\n              </div>\n            </div>\n            </a> \n        </div>\n\n        <div class=\"col s7 m3 l2\">\n            <a [routerLink]=\"['./stsportsenrollment']\">\n            <div class=\"card indigo darken-4 \" style=\"cursor: pointer\">\n              <div class=\"card-content white-text z-depth-5 \">\n                <span class=\"card-title\">STSports Enrollment</span>\n                <i class=\"small material-icons \" style=\"margin-top: 10px;\">people</i>\n              </div>\n            </div>\n            </a> \n        </div>\n\n        <div class=\"col s7 m3 l2\">\n            <a [routerLink]=\"['./stsportssession']\">\n            <div class=\"card indigo darken-4 \" style=\"cursor: pointer\">\n              <div class=\"card-content white-text z-depth-5 \">\n                <span class=\"card-title\">STSports Session</span>\n                <i class=\"small material-icons \" style=\"margin-top: 10px;\">people</i>\n              </div>\n            </div>\n            </a> \n        </div>\n\n        <div class=\"col s7 m3 l2\">\n            <a [routerLink]=\"['./stsportssessionstrail']\">\n            <div class=\"card indigo darken-4 \" style=\"cursor: pointer\">\n              <div class=\"card-content white-text z-depth-5 \">\n                <span class=\"card-title\">STSPorts SessionTrail</span>\n                <i class=\"small material-icons \" style=\"margin-top: 10px;\">people</i>\n              </div>\n            </div>\n            </a> \n        </div>\n\n        \n        <div class=\"col s7 m3 l2\">\n            <a [routerLink]=\"['./stsportsactivation']\">\n            <div class=\"card indigo darken-4 \" style=\"cursor: pointer\">\n              <div class=\"card-content white-text z-depth-5 \">\n                <span class=\"card-title\">STSPorts Activation</span>\n                <i class=\"small material-icons \" style=\"margin-top: 10px;\">people</i>\n              </div>\n            </div>\n            </a> \n        </div>\n\n\n        <div class=\"col s7 m3 l2\">\n            <a [routerLink]=\"['./stactivationdetails']\">\n            <div class=\"card indigo darken-4 \" style=\"cursor: pointer\">\n              <div class=\"card-content white-text z-depth-5 \">\n                <span class=\"card-title\">STActivation Details</span>\n                <i class=\"small material-icons \" style=\"margin-top: 10px;\">people</i>\n              </div>\n            </div>\n            </a> \n        </div>\n\n\n        <div class=\"col s7 m3 l2\">\n            <a [routerLink]=\"['./sttrainerstatus']\">\n            <div class=\"card indigo darken-4 \" style=\"cursor: pointer\">\n              <div class=\"card-content white-text z-depth-5 \">\n                <span class=\"card-title\">ST TrainerStatus</span>\n                <i class=\"small material-icons \" style=\"margin-top: 10px;\">people</i>\n              </div>\n            </div>\n            </a> \n        </div>\n\n\n\n      \n\n        \n\n        <div class=\"col s7 m3 l2\">\n            <a  >\n            <div class=\"card indigo darken-4 \" style=\"cursor: pointer\">\n              <div class=\"card-content white-text z-depth-5 \">\n                <span class=\"card-title\">Employee perfromances</span>\n                <i class=\"small material-icons \" style=\"margin-top: 10px;\">error</i>\n              </div>\n            </div>\n            </a> \n        </div> -->\n      </div>   \n          <a class=\"waves-effect    pink darken-4 btn\" (click)=\"moveNext($event, 2)\" >Next</a>        \n    </div>\n</li>\n\n\n\n\n<li>\n    <div class=\"collapsible-header   text-darken-4 active  grey lighten-3\" style=\"font-size: 20px\"><i class=\"material-icons amber-text text-darken-4\" style=\"font-size: 30px\">looks_3</i> Target and Task Allocation</div>\n      <div class=\"collapsible-body \">\n        <div class=\"row\">\n          <div class=\"col s7 m3 l2\">\n             <a  >  \n              <div class=\"card indigo darken-4 \" style=\"cursor: pointer\">\n                <div class=\"card-content white-text z-depth-5 \">\n                  <span class=\"card-title\">Sales Target</span>\n                  <i class=\"small material-icons \" style=\"margin-top: 10px;\">check</i>\n                </div>\n              </div>\n            </a>  \n          </div> \n          <div class=\"col s7 m3 l2\">\n              <a >\n              <div class=\"card indigo darken-4 \" style=\"cursor: pointer\">\n                <div class=\"card-content white-text z-depth-5 \">\n                  <span class=\"card-title\">TaskAllocation</span>\n                  <i class=\"small material-icons \" style=\"margin-top: 10px;\">dns</i>\n                </div>\n              </div>\n              </a>\n          </div>\n         \n          <div class=\"col s7 m3 l2\">\n               <a >  \n                <div class=\"card indigo darken-4 \" style=\"cursor: pointer\">\n                  <div class=\"card-content white-text z-depth-5 \">\n                    <span class=\"card-title\">Task Report</span>\n                    <i class=\"small material-icons \" style=\"margin-top: 10px;\">check</i>\n                  </div>\n                </div>\n              </a>  \n            </div> \n            \n      </div>   \n          <a class=\"waves-effect   pink darken-4 btn\" (click)=\"moveNext($event, 3)\" >Next</a>        \n    </div>\n</li>\n\n\n\n  \n\n  \n </ul> \n </div>\n </div>\n\n\n\n"

/***/ }),

/***/ "./src/app/pages/admin/admin.component.ts":
/*!************************************************!*\
  !*** ./src/app/pages/admin/admin.component.ts ***!
  \************************************************/
/*! exports provided: AdminComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdminComponent", function() { return AdminComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs/_esm5/add/operator/map.js");



var AdminComponent = /** @class */ (function () {
    function AdminComponent() {
    }
    //constructor() { }
    AdminComponent.prototype.ngOnInit = function () {
        $('.collapsible').collapsible({
            onOpen: function (el) { Materialize.updateTextFields(); }
        });
    };
    AdminComponent.prototype.moveNext = function (event, tab) {
        $('.collapsible').collapsible('open', tab);
    };
    AdminComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-admin',
            template: __webpack_require__(/*! ./admin.component.html */ "./src/app/pages/admin/admin.component.html"),
            styles: [__webpack_require__(/*! ./admin.component.css */ "./src/app/pages/admin/admin.component.css")]
        })
    ], AdminComponent);
    return AdminComponent;
}());



/***/ }),

/***/ "./src/app/pages/admin/stactivationdetails/stactivationdetails.component.css":
/*!***********************************************************************************!*\
  !*** ./src/app/pages/admin/stactivationdetails/stactivationdetails.component.css ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2FkbWluL3N0YWN0aXZhdGlvbmRldGFpbHMvc3RhY3RpdmF0aW9uZGV0YWlscy5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/pages/admin/stactivationdetails/stactivationdetails.component.html":
/*!************************************************************************************!*\
  !*** ./src/app/pages/admin/stactivationdetails/stactivationdetails.component.html ***!
  \************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">  \n    <nav class=\"z-depth-0\">\n        <div class=\"nav-wrapper white \">\n          <div class=\"col s5 m9 l9\">\n              <a [routerLink]=\"['../']\" class=\"breadcrumb grey-text\">Dashboard</a>\n               <a [routerLink]=\"['./']\" class=\"breadcrumb active\">STActivation</a>\n        \n          </div>    \n          \n                \n          <div class=\"col s2 m2 l1\">          \n              <a class=\"waves-effect cyan  btn-large\" style=\"    height: 42px;\n              line-height: 43px;\n              padding: 0px 20px;\"\n              [routerLink]=\"['./stactivationdetailsdetails']\"\n              href=\"!#\" ><i class=\"large material-icons\" style=\"font-size: 2rem; height: 42px;\n              line-height: 43px;\">add</i></a>\n          </div>\n        </div>\n    </nav>\n    <div  style=\"padding:5px\">\n        <div style=\"padding: 0px 10px\">\n            \n                  <table class=\"highlight bordered  \" style=\"border: 1px solid #ddd\">\n                    <thead class=\" blue lighten-5\">\n          <tr>\n              \n              <th>ID</th>\n              <th>ActId</th>\n              <th>Description</th>\n              <th>CoachInstruction</th>\n              <th>watchOutSteps</th>\n            <!--\n              <th>VideoLink</th>\n              <th>Time</th>\n              <th>NoOfCount</th>\n              <th>VideoReuired</th>\n              <th>Direction</th>\n              <th>TrainerStatus</th>\n              <th>TrainerNotes</th>\n              <th>MasterSessionId</th>\n              <th>HeaderText</th>\n              -->\n              <th>Action</th>\n            \n\n\n\n\n\n\n\n\n\n\n\n\n\n          </tr>\n        </thead>\n      \n        <tbody>\n          <tr *ngFor=\"let record of records;\">\n           <td>{{record.id}}</td>\n            <td>{{record.actId}}</td>\n            <td>{{record.description}}</td>\n            <td>{{record.coachInstruction}}</td>           \n            <td>{{record.watchOutSteps}}</td>\n            <!--\n            <td>{{record.videoLink}}</td>\n            <td>{{record.time}}</td>\n            <td>{{record.noOfCount}}</td>\n            <td>{{record.videoReuired}}</td>\n            <td>{{record.direction}}</td>\n            <td>{{record.trainerStatus}}</td>\n            <td>{{record.trainerNotes}}</td>\n            <td>{{record.masterSessionId}}</td>\n            <td>{{record.headerText}}</td>\n             -->\n          <!--   <td>{{record.isActive}}</td> -->\n            \n\n              \n            <td>              \n              <a class=\"btn-floating waves-effect waves-light blue darken-3\" (click)=\"edit(record.id)\" ><i class=\"material-icons\">edit</i></a>\n              <a class=\"btn-floating waves-effect waves-light red darken-2 modal-trigger\" (click)=\"selectForDelete(record.id)\" href=\"#modal1\"><i class=\"material-icons\">delete</i></a>\n            </td>\n          </tr>\n        </tbody>\n      </table>\n      <div class=\"progress\" *ngIf=\"isLoading\">\n          <div class=\"indeterminate\"></div>\n      </div>\n\n      <my-pagination\n        (goPage)=\"goToPage($event)\"\n        (goNext)=\"onNext()\"\n        (goPrev)=\"onPrev()\"\n        [pagesToShow]=\"10\"\n        [page]=\"page\"\n        [perPage]=\"limit\"\n        [count]=\"total\">\n    </my-pagination>   \n      </div>\n     \n  </div> \n  <div id=\"modal12\" class=\"modal\">\n      <div class=\"modal-content\">\n        <h4>Upload the Data</h4>\n        <p>Please Choose the File.</p> <p><input type=\"file\" name=\"file\"   #fileInput (change)=\"onFileSelect($event)\" /></p>\n     <!--  </div>\n      <div class=\"modal-footer\"> -->\n       <a [routerLink]=\"['./']\" (click)=\"uploadExcelSheet()\" class=\"modal-action modal-close waves-effect waves-green btn blue\">Upload</a>  \n </div> <div class=\"modal-content\">\n        <h4>Download the Data</h4>\n       <a [routerLink]=\"['./']\" (click)=\"downloadexcelfile()\" class=\"modal-action modal-close waves-effect waves-green btn red\">Download</a>\n       <p>Total Records: {{totalEmployees}}</p>  \n      </div>\n    </div>\n\n    <div id=\"modal1\" class=\"modal\">\n      <div class=\"modal-content\">\n        <h4>Delete?</h4>\n        <p>Are you sure, you want to delete this record?</p>\n      </div>\n      <div class=\"modal-footer\">\n        <a [routerLink]=\"['./']\" (click)=\"delete()\" class=\"modal-action modal-close waves-effect waves-green btn red\">Delete</a>\n      </div>\n    </div>\n</div>\n        "

/***/ }),

/***/ "./src/app/pages/admin/stactivationdetails/stactivationdetails.component.ts":
/*!**********************************************************************************!*\
  !*** ./src/app/pages/admin/stactivationdetails/stactivationdetails.component.ts ***!
  \**********************************************************************************/
/*! exports provided: STActivationDetailsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "STActivationDetailsComponent", function() { return STActivationDetailsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _angular_Http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/Http */ "./node_modules/@angular/Http/esm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs/_esm5/add/operator/map.js");





var STActivationDetailsComponent = /** @class */ (function () {
    function STActivationDetailsComponent(_router, _http) {
        this._http = _http;
        this.records = [];
        this.isLoading = false;
        this.total = 0;
        this.page = 1;
        this.limit = 10;
        this.router = _router;
        this.loadIntialListOfEmplyees();
        this.countEmployeeRecords();
    }
    STActivationDetailsComponent.prototype.goToPage = function (n) {
        this.page = n;
        this.loadIntialListOfEmplyees();
    };
    STActivationDetailsComponent.prototype.onNext = function () {
        this.page++;
        this.loadIntialListOfEmplyees();
    };
    STActivationDetailsComponent.prototype.onPrev = function () {
        this.page--;
        this.loadIntialListOfEmplyees();
    };
    STActivationDetailsComponent.prototype.loadIntialListOfEmplyees = function () {
        var _this = this;
        this.isLoading = true;
        return this._http.get('Http://52.66.246.140:8080/SkillTeck/listSTActivationDetailss?page=' + this.page + '&size=' + this.limit)
            .map(function (res) { return res.json(); })
            .subscribe(function (data) {
            _this.records = data.stactivationDetailsList;
            _this.total = data.totalRecords;
            console.log(_this.records);
            _this.isLoading = false;
        }, function (err) {
            console.log('Something went wrong!');
            _this.isLoading = false;
        });
    };
    STActivationDetailsComponent.prototype.edit = function (id) {
        var navigationExtras = {
            queryParams: { 'session_id': id },
            skipLocationChange: true
        };
        this.router.navigate(['/admin/stactivationdetails/stactivationdetailsdetails'], navigationExtras);
    };
    STActivationDetailsComponent.prototype.selectForDelete = function (id) {
        this.deleteId = id;
    };
    STActivationDetailsComponent.prototype.delete = function () {
        var _this = this;
        this.isLoading = true;
        return this._http.delete('Http://52.66.246.140:8080/SkillTeck/deleteSTActivationDetails/' + this.deleteId)
            .subscribe(function (data) {
            var $toastContent = $('<span>Record has been deleted successfully!!</span>');
            Materialize.toast($toastContent, 2000);
            _this.isLoading = false;
            _this.loadIntialListOfEmplyees();
        }, function (err) {
            console.log('Something went wrong!');
            _this.isLoading = false;
        });
    };
    STActivationDetailsComponent.prototype.moveNext = function (event, tab) {
        $('.collapsible').collapsible('open', tab);
    };
    STActivationDetailsComponent.prototype.ngOnInit = function () {
        $("select").material_select();
        $('.collapsible').collapsible();
        $('.modal').modal();
    };
    STActivationDetailsComponent.prototype.ngAfterViewChecked = function () {
        var self = this;
    };
    STActivationDetailsComponent.prototype.uploadExcelSheet = function () {
    };
    STActivationDetailsComponent.prototype.downloadexcel = function () {
    };
    STActivationDetailsComponent.prototype.downloadexcelfile = function () {
        var url = 'Http://34.93.202.192:8080/SpoorsReports/getAllEmployeesToPrintXL';
        this.downloadXLFile(url).subscribe(function (res) {
            var fileURL = URL.createObjectURL(res);
            window.open(fileURL);
        });
    };
    STActivationDetailsComponent.prototype.downloadXLFile = function (url) {
        return this._http.get(url, { responseType: _angular_Http__WEBPACK_IMPORTED_MODULE_2__["ResponseContentType"].Blob }).map(function (res) {
            return new Blob([res.blob()], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        });
    };
    STActivationDetailsComponent.prototype.downloadpdf = function () {
        var url = 'Http://34.93.202.192:8080/SpoorsReports/getAllEmployeesToPrint';
        this.downloadFile(url).subscribe(function (res) {
            var fileURL = URL.createObjectURL(res);
            window.open(fileURL);
        });
    };
    STActivationDetailsComponent.prototype.downloadFile = function (url) {
        return this._http.get(url, { responseType: _angular_Http__WEBPACK_IMPORTED_MODULE_2__["ResponseContentType"].Blob }).map(function (res) {
            return new Blob([res.blob()], { type: 'application/pdf' });
        });
    };
    STActivationDetailsComponent.prototype.countEmployeeRecords = function () {
        var _this = this;
        this.isLoading = true;
        return this._http.get('Http://34.93.202.192:8080/Spoors/employeesCount')
            .map(function (res) { return res.json(); })
            .subscribe(function (data) {
            _this.totalEmployees = data.totalRecords;
            console.log('Count of Emplyees --- ' + _this.totalEmployees);
        }, function (err) {
            console.log('Something went wrong!');
        });
        this.isLoading = false;
    };
    STActivationDetailsComponent.prototype.onFileSelect = function (event) {
        var _this = this;
        console.log('File Change Event !');
        if (event.target.files.length > 0) {
            var file = event.target.files[0];
            var formdata = new FormData();
            formdata.append('file', file);
            return this._http.post('Http://34.93.202.192:8080/SpoorsEmployees/importEmpData', formdata)
                .subscribe(function (res) {
                console.log(res);
                _this.isLoading = false;
                var $toastContent = $('<span>Record has been loaded successfully!!</span>');
                Materialize.toast($toastContent, 2000);
                _this.router.navigate(['/spoorsemployees']);
            }, function (err) {
                var $toastContent = $('<span>' + JSON.parse(err["_body"])[0]["errMessage"] + '</span>');
                Materialize.toast($toastContent, 2000);
                _this.isLoading = false;
            });
        }
    };
    STActivationDetailsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-stactivationdetails',
            template: __webpack_require__(/*! ./stactivationdetails.component.html */ "./src/app/pages/admin/stactivationdetails/stactivationdetails.component.html"),
            styles: [__webpack_require__(/*! ./stactivationdetails.component.css */ "./src/app/pages/admin/stactivationdetails/stactivationdetails.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _angular_Http__WEBPACK_IMPORTED_MODULE_2__["Http"]])
    ], STActivationDetailsComponent);
    return STActivationDetailsComponent;
}());



/***/ }),

/***/ "./src/app/pages/admin/stactivationdetails/stactivationdetailsdetails/stactivationdetailsdetails.component.css":
/*!*********************************************************************************************************************!*\
  !*** ./src/app/pages/admin/stactivationdetails/stactivationdetailsdetails/stactivationdetailsdetails.component.css ***!
  \*********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2FkbWluL3N0YWN0aXZhdGlvbmRldGFpbHMvc3RhY3RpdmF0aW9uZGV0YWlsc2RldGFpbHMvc3RhY3RpdmF0aW9uZGV0YWlsc2RldGFpbHMuY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/pages/admin/stactivationdetails/stactivationdetailsdetails/stactivationdetailsdetails.component.html":
/*!**********************************************************************************************************************!*\
  !*** ./src/app/pages/admin/stactivationdetails/stactivationdetailsdetails/stactivationdetailsdetails.component.html ***!
  \**********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">  \n    <nav>\n        <div class=\"nav-wrapper white grey-text text-darken-2\">\n          <div class=\"col s12 grey-text text-darken-2\">\n             <a [routerLink]=\"['../../']\" class=\"breadcrumb grey-text\">Dashboard</a>\n            <a [routerLink]=\"['../']\" class=\"breadcrumb grey-text\">STActivationDetails</a>\n            <a [routerLink]=\"['./']\" class=\"breadcrumb active\">Details</a>\n          </div>\n        </div>\n    </nav>\n\n    <div class=\"row\" style=\"padding: 0px 20px\">\n    <ul class=\"collapsible popout z-depth-5\" data-collapsible=\"accordion\">\n      <li>\n        <div class=\"collapsible-header light-green-text text-darken-4 active grey lighten-5\" style=\"font-size: 20px\"><i class=\"material-icons amber-text text-darken-4\" style=\"font-size: 30px\">looks_one</i>\n         STActivationDetailsProfile</div>\n        <div class=\"collapsible-body\">\n  \n          <form >\n                    <div class=\"row\">\n\n                        <div class=\"input-field col s12 m6  l4 \">\n                          <input  id=\"actId\" type=\"text\" class=\"validate\" [(ngModel)]=\"actId\" name=\"actId\">\n                          <label class=\"active\" for=\"v\">ActId</label>\n                        </div>\n\n                        <div class=\"input-field col s12 m6  l4 \">\n                          <input  id=\"description\" type=\"text\" class=\"validate\" [(ngModel)]=\"description\" name=\"description\">\n                          <label class=\"active\" for= \"description\">Description</label>\n                        </div> \n\n                        <div class=\"input-field col s12 m6  l4 \">\n                          <input  id=\"coachInstruction\" type=\"text\" class=\"validate\" [(ngModel)]=\"coachInstruction\" name=\"coachInstruction\">\n                          <label class=\"active\" for=\"coachInstruction\">CoachInstruction</label>\n                        </div>  \n                                               \n                        \n                                              \n                        <div class=\"input-field col s12 m6  l4 \">\n                          <input  id=\"watchOutSteps\" type=\"text\" class=\"validate\" [(ngModel)]=\"watchOutSteps\" name=\"watchOutSteps\">\n                          <label class=\"active\" for=\"watchOutSteps\">WatchOutSteps</label>\n                        </div> \n\n                        <div class=\"input-field col s12 m6  l4 \">\n                          <input  id=\"videoLink\" type=\"text\" class=\"validate\" [(ngModel)]=\"videoLink\" name=\"videoLink\">\n                          <label class=\"active\" for=\"videoLink\">VideoLink</label>\n                        </div> \n\n                         <div class=\"input-field col s12 m6  l4 \">\n                          <input  id=\"time\" type=\"text\" class=\"validate\" [(ngModel)]=\"time\" name=\"time\">\n                          <label class=\"active\" for=\"time\">Time</label>\n                        </div> \n\n                         <div class=\"input-field col s12 m6  l4 \">\n                         <input  id=\"noOfCount\" type=\"text\" class=\"validate\" [(ngModel)]=\"noOfCount\" name=\"noOfCount\">\n                          <label class=\"active\" for=\"noOfCount\">NoOfCount</label>\n                        </div> \n\n                        <div class=\"input-field col s12 m6  l4 \">\n                         <input  id=\"videoReuired\" type=\"text\" class=\"validate\" [(ngModel)]=\"videoReuired\" name=\"videoReuired\">\n                          <label class=\"active\" for=\"videoReuired\">VideoReuired</label>\n                        </div> \n\n                        \n                        <div class=\"input-field col s12 m6  l4 \">\n                         <input  id=\"direction\" type=\"text\" class=\"validate\" [(ngModel)]=\"direction\" name=\"direction\">\n                          <label class=\"active\" for=\"direction\">Direction</label>\n                        </div> \n\n                        <div class=\"input-field col s12 m6  l4 \">\n                         <input  id=\"trainerStatus\" type=\"text\" class=\"validate\" [(ngModel)]=\"trainerStatus\" name=\"trainerStatus\">\n                          <label class=\"active\" for=\"trainerStatus\">\n                          TrainerStatus</label>\n                        </div> \n\n\n                        <div class=\"input-field col s12 m6  l4 \">\n                         <input  id=\"trainerNotes\" type=\"text\" class=\"validate\" [(ngModel)]=\"trainerNotes\" name=\"trainerNotes\">\n                          <label class=\"active\" for=\"trainerNotes\">TrainerNotes</label>\n                        </div> \n\n                        <div class=\"input-field col s12 m6  l4 \">\n                         <input  id=\"masterSessionId\" type=\"text\" class=\"validate\" [(ngModel)]=\"masterSessionId\" name=\"masterSessionId\">\n                          <label class=\"active\" for=\"masterSessionId\">MasterSessionId</label>\n                        </div> \n\n                         <div class=\"input-field col s12 m6  l4 \">\n                         <input  id=\"headerText\" type=\"text\" class=\"validate\" [(ngModel)]=\"headerText\" name=\"headerText\">\n                          <label class=\"active\" for=\"headerText\">HeaderText</label>\n                        </div> \n                         \n                    \n\n\n\n                        \n                         \n                       \n                    </div>\n                    <button class=\"btn waves-effect waves-light cyan\"  (click)=\"createReminder()\" name=\"action\">Save                       <i class=\"material-icons right\">add</i>\n                      </button> \n                      <div class=\"progress\" *ngIf=\"isLoading\">\n                          <div class=\"indeterminate\"></div>\n                      </div>\n                    </form>\n        </div>\n      </li>\n\n     \n    </ul>   \n  </div> \n  \n  </div>\n        "

/***/ }),

/***/ "./src/app/pages/admin/stactivationdetails/stactivationdetailsdetails/stactivationdetailsdetails.component.ts":
/*!********************************************************************************************************************!*\
  !*** ./src/app/pages/admin/stactivationdetails/stactivationdetailsdetails/stactivationdetailsdetails.component.ts ***!
  \********************************************************************************************************************/
/*! exports provided: STActivationDetailsdetailsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "STActivationDetailsdetailsComponent", function() { return STActivationDetailsdetailsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _angular_Http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/Http */ "./node_modules/@angular/Http/esm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs/_esm5/add/operator/map.js");





var STActivationDetailsdetailsComponent = /** @class */ (function () {
    function STActivationDetailsdetailsComponent(_router, _http, route) {
        this._http = _http;
        this.route = route;
        this.isLoading = false;
        this.router = _router;
    }
    STActivationDetailsdetailsComponent.prototype.createReminder = function () {
        var _this = this;
        this.isLoading = true;
        var data = {
            "actId": this.actId,
            "description": this.description,
            "coachInstruction": this.coachInstruction,
            "watchOutSteps": this.watchOutSteps,
            "videoLink": this.videoLink,
            "time": this.time,
            "noOfCount": this.noOfCount,
            "videoReuired": this.videoReuired,
            "direction": this.direction,
            "trainerStatus": this.trainerStatus,
            "trainerNotes": this.trainerNotes,
            "masterSessionId": this.masterSessionId,
            "headerText": this.headerText,
            "isActive": 'y',
            "isAprroved": 'y',
        };
        if (this.actId == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>actId is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.description == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>description is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.coachInstruction == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>coachInstruction is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.watchOutSteps == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>watchOutSteps is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.videoLink == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>videoLink is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.time == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>time is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.noOfCount == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>noOfCount is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.videoReuired == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>videoReuired is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.direction == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>direction is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.trainerStatus == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>trainerStatus is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.trainerNotes == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>trainerNotes is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.masterSessionId == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>masterSessionId is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.headerText == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>headerText is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.editId && this.editId !== "" && this.editId !== "None") {
            data["id"] = this.editId;
            return this._http.put('Http://52.66.246.140:8080/SkillTeck/updateSTActivationDetails/', data)
                .subscribe(function (res) {
                console.log(res);
                _this.isLoading = false;
                var $toastContent = $('<span>Record has been saved successfully!!</span>');
                Materialize.toast($toastContent, 2000);
                _this.router.navigate(['/admin/stactivationdetails']);
            }, function (err) {
                var $toastContent = $('<span>' + JSON.parse(err["_body"])[0]["errMessage"] + '</span>');
                Materialize.toast($toastContent, 2000);
                _this.isLoading = false;
            });
        }
        else {
            return this._http.post('Http://52.66.246.140:8080/SkillTeck/addSTActivationDetails/', data)
                .subscribe(function (res) {
                console.log(res);
                _this.isLoading = false;
                var $toastContent = $('<span>Record has been saved successfully!!</span>');
                Materialize.toast($toastContent, 2000);
                _this.router.navigate(['/admin/stactivationdetails']);
            }, function (err) {
                var $toastContent = $('<span>' + JSON.parse(err["_body"])[0]["errMessage"] + '</span>');
                Materialize.toast($toastContent, 2000);
                _this.isLoading = false;
            });
        }
    };
    STActivationDetailsdetailsComponent.prototype.moveNext = function (event, tab) {
        $('.collapsible').collapsible('open', tab);
    };
    STActivationDetailsdetailsComponent.prototype.ngAfterViewInit = function () {
        this.things.changes.subscribe(function (t) {
            $("select").material_select();
        });
    };
    STActivationDetailsdetailsComponent.prototype.ngAfterViewChecked = function () {
        Materialize.updateTextFields();
    };
    STActivationDetailsdetailsComponent.prototype.ngOnInit = function () {
        var _this = this;
        $("select").material_select();
        $('.collapsible').collapsible({
            onOpen: function (el) { Materialize.updateTextFields(); }
        });
        this.route
            .queryParamMap
            .map(function (params) { return params.get('session_id') || 'None'; })
            .subscribe(function (val) { return _this.editId = val; });
        console.log(this.editId);
        if (this.editId && this.editId !== "" && this.editId !== "None") {
            this.isLoading = true;
            return this._http.get('Http://52.66.246.140:8080/SkillTeck/getSTActivationDetailsById/' + this.editId)
                .map(function (res) { return res.json(); })
                .subscribe(function (data) {
                var record = data[0];
                _this.actId = record["actId"];
                _this.description = record["description"];
                _this.coachInstruction = record["coachInstruction"];
                _this.watchOutSteps = record["watchOutSteps"];
                _this.videoLink = record["videoLink"];
                _this.time = record["time"];
                _this.noOfCount = record["noOfCount"];
                _this.videoReuired = record["videoReuired"];
                _this.direction = record["direction"];
                _this.trainerStatus = record["trainerStatus"];
                _this.trainerNotes = record["trainerNotes"];
                _this.masterSessionId = record["masterSessionId"];
                _this.headerText = record["headerText"];
                $("select").material_select();
                Materialize.updateTextFields();
                _this.isLoading = false;
                //debugger;
            }, function (err) {
                console.log('Something went wrong!');
                _this.isLoading = false;
            });
        }
        Materialize.updateTextFields();
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChildren"])('allTheseThings'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], STActivationDetailsdetailsComponent.prototype, "things", void 0);
    STActivationDetailsdetailsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-stactivationdetailsdetails',
            template: __webpack_require__(/*! ./stactivationdetailsdetails.component.html */ "./src/app/pages/admin/stactivationdetails/stactivationdetailsdetails/stactivationdetailsdetails.component.html"),
            styles: [__webpack_require__(/*! ./stactivationdetailsdetails.component.css */ "./src/app/pages/admin/stactivationdetails/stactivationdetailsdetails/stactivationdetailsdetails.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _angular_Http__WEBPACK_IMPORTED_MODULE_2__["Http"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]])
    ], STActivationDetailsdetailsComponent);
    return STActivationDetailsdetailsComponent;
}());



/***/ }),

/***/ "./src/app/pages/admin/stsports/stsports.component.css":
/*!*************************************************************!*\
  !*** ./src/app/pages/admin/stsports/stsports.component.css ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2FkbWluL3N0c3BvcnRzL3N0c3BvcnRzLmNvbXBvbmVudC5jc3MifQ== */"

/***/ }),

/***/ "./src/app/pages/admin/stsports/stsports.component.html":
/*!**************************************************************!*\
  !*** ./src/app/pages/admin/stsports/stsports.component.html ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">  \n    <nav class=\"z-depth-0\">\n        <div class=\"nav-wrapper white \">\n          <div class=\"col s5 m9 l9\">\n              <a [routerLink]=\"['../']\" class=\"breadcrumb grey-text\">Dashboard</a>\n               <a [routerLink]=\"['./']\" class=\"breadcrumb active\">STSports</a>\n          </div>    \n              \n                      \n          <div class=\"col s2 m2 l1\">          \n              <a class=\"waves-effect cyan  btn-large\" style=\"    height: 42px;\n              line-height: 43px;\n              padding: 0px 20px;\"\n              [routerLink]=\"['./stsportsdetails']\"\n              href=\"!#\" ><i class=\"large material-icons\" style=\"font-size: 2rem; height: 42px;\n              line-height: 43px;\">add</i></a>\n          </div>\n        </div>\n    </nav>\n    <div  style=\"padding:5px\">\n        <div style=\"padding: 0px 10px\">\n            \n                  <table class=\"highlight bordered  \" style=\"border: 1px solid #ddd\">\n                    <thead class=\" blue lighten-5\">\n          <tr>\n              <th>ID </th>\n              <th>SportsName</th>\n              <th>Description</th>\n              <th>SportsCode</th>\n              <th>Action</th><th></th>\n                                                 \n             \n\n          </tr>\n        </thead>\n      \n        <tbody>\n          <tr *ngFor=\"let record of records;\">\n            <td>{{record.id}}</td>\n            <td>{{record.stName}}</td>         \n            <td>{{record.description}}</td>\n            <td> {{record.stCode}}</td>\n            \n            \n              \n            \n          <!--   <td>{{record.isActive}}</td> -->\n            \n\n              \n            <td>              \n              <a class=\"btn-floating waves-effect waves-light blue darken-3\" (click)=\"edit(record.id)\" ><i class=\"material-icons\">edit</i></a>\n              <a class=\"btn-floating waves-effect waves-light red darken-2 modal-trigger\" (click)=\"selectForDelete(record.id)\" href=\"#modal1\"><i class=\"material-icons\">delete</i></a>\n            </td><td></td>\n          </tr>\n        </tbody>\n      </table>\n      <div class=\"progress\" *ngIf=\"isLoading\">\n          <div class=\"indeterminate\"></div>\n      </div>\n\n      <my-pagination\n        (goPage)=\"goToPage($event)\"\n        (goNext)=\"onNext()\"\n        (goPrev)=\"onPrev()\"\n        [pagesToShow]=\"10\"\n        [page]=\"page\"\n        [perPage]=\"limit\"\n        [count]=\"total\">\n    </my-pagination>   \n      </div>\n     \n  </div> \n  <div id=\"modal12\" class=\"modal\">\n      <div class=\"modal-content\">\n        <h4>Upload the Data</h4>\n        <p>Please Choose the File.</p> <p><input type=\"file\" name=\"file\"   #fileInput (change)=\"onFileSelect($event)\" /></p>\n     <!--  </div>\n      <div class=\"modal-footer\"> -->\n       <a [routerLink]=\"['./']\" (click)=\"uploadExcelSheet()\" class=\"modal-action modal-close waves-effect waves-green btn blue\">Upload</a>  \n </div> <div class=\"modal-content\">\n        <h4>Download the Data</h4>\n       <a [routerLink]=\"['./']\" (click)=\"downloadexcelfile()\" class=\"modal-action modal-close waves-effect waves-green btn red\">Download</a>\n       <p>Total Records: {{totalEmployees}}</p>  \n      </div>\n    </div>\n\n    <div id=\"modal1\" class=\"modal\">\n      <div class=\"modal-content\">\n        <h4>Delete?</h4>\n        <p>Are you sure, you want to delete this record?</p>\n      </div>\n      <div class=\"modal-footer\">\n        <a [routerLink]=\"['./']\" (click)=\"delete()\" class=\"modal-action modal-close waves-effect waves-green btn red\">Delete</a>\n      </div>\n    </div>\n</div>\n        "

/***/ }),

/***/ "./src/app/pages/admin/stsports/stsports.component.ts":
/*!************************************************************!*\
  !*** ./src/app/pages/admin/stsports/stsports.component.ts ***!
  \************************************************************/
/*! exports provided: STSportsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "STSportsComponent", function() { return STSportsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _angular_Http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/Http */ "./node_modules/@angular/Http/esm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs/_esm5/add/operator/map.js");





var STSportsComponent = /** @class */ (function () {
    function STSportsComponent(_router, _http) {
        this._http = _http;
        this.records = [];
        this.isLoading = false;
        this.total = 0;
        this.page = 1;
        this.limit = 10;
        this.router = _router;
        this.loadIntialListOfEmplyees();
        this.countEmployeeRecords();
    }
    STSportsComponent.prototype.goToPage = function (n) {
        this.page = n;
        this.loadIntialListOfEmplyees();
    };
    STSportsComponent.prototype.onNext = function () {
        this.page++;
        this.loadIntialListOfEmplyees();
    };
    STSportsComponent.prototype.onPrev = function () {
        this.page--;
        this.loadIntialListOfEmplyees();
    };
    STSportsComponent.prototype.loadIntialListOfEmplyees = function () {
        var _this = this;
        this.isLoading = true;
        return this._http.get('Http://52.66.246.140:8080/SkillTeck/listSTSportss?page=' + this.page + '&size=' + this.limit)
            .map(function (res) { return res.json(); })
            .subscribe(function (data) {
            _this.records = data.stsportsList;
            _this.total = data.totalRecords;
            console.log(_this.records);
            _this.isLoading = false;
        }, function (err) {
            console.log('Something went wrong!');
            _this.isLoading = false;
        });
    };
    STSportsComponent.prototype.edit = function (id) {
        var navigationExtras = {
            queryParams: { 'session_id': id },
            skipLocationChange: true
        };
        this.router.navigate(['/admin/stsports/stsportsdetails'], navigationExtras);
    };
    STSportsComponent.prototype.selectForDelete = function (id) {
        this.deleteId = id;
    };
    STSportsComponent.prototype.delete = function () {
        var _this = this;
        this.isLoading = true;
        return this._http.delete('Http://52.66.246.140:8080/SkillTeck/deleteSTSports/' + this.deleteId)
            .subscribe(function (data) {
            var $toastContent = $('<span>Record has been deleted successfully!!</span>');
            Materialize.toast($toastContent, 2000);
            _this.isLoading = false;
            _this.loadIntialListOfEmplyees();
        }, function (err) {
            console.log('Something went wrong!');
            _this.isLoading = false;
        });
    };
    STSportsComponent.prototype.moveNext = function (event, tab) {
        $('.collapsible').collapsible('open', tab);
    };
    STSportsComponent.prototype.ngOnInit = function () {
        $("select").material_select();
        $('.collapsible').collapsible();
        $('.modal').modal();
    };
    STSportsComponent.prototype.ngAfterViewChecked = function () {
        var self = this;
    };
    STSportsComponent.prototype.uploadExcelSheet = function () {
    };
    STSportsComponent.prototype.downloadexcel = function () {
    };
    STSportsComponent.prototype.downloadexcelfile = function () {
        var url = 'Http://34.93.202.192:8080/SpoorsReports/getAllEmployeesToPrintXL';
        this.downloadXLFile(url).subscribe(function (res) {
            var fileURL = URL.createObjectURL(res);
            window.open(fileURL);
        });
    };
    STSportsComponent.prototype.downloadXLFile = function (url) {
        return this._http.get(url, { responseType: _angular_Http__WEBPACK_IMPORTED_MODULE_2__["ResponseContentType"].Blob }).map(function (res) {
            return new Blob([res.blob()], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        });
    };
    STSportsComponent.prototype.downloadpdf = function () {
        var url = 'Http://34.93.202.192:8080/SpoorsReports/getAllEmployeesToPrint';
        this.downloadFile(url).subscribe(function (res) {
            var fileURL = URL.createObjectURL(res);
            window.open(fileURL);
        });
    };
    STSportsComponent.prototype.downloadFile = function (url) {
        return this._http.get(url, { responseType: _angular_Http__WEBPACK_IMPORTED_MODULE_2__["ResponseContentType"].Blob }).map(function (res) {
            return new Blob([res.blob()], { type: 'application/pdf' });
        });
    };
    STSportsComponent.prototype.countEmployeeRecords = function () {
        var _this = this;
        this.isLoading = true;
        return this._http.get('Http://34.93.202.192:8080/Spoors/employeesCount')
            .map(function (res) { return res.json(); })
            .subscribe(function (data) {
            _this.totalEmployees = data.totalRecords;
            console.log('Count of Emplyees --- ' + _this.totalEmployees);
        }, function (err) {
            console.log('Something went wrong!');
        });
        this.isLoading = false;
    };
    STSportsComponent.prototype.onFileSelect = function (event) {
        var _this = this;
        console.log('File Change Event !');
        if (event.target.files.length > 0) {
            var file = event.target.files[0];
            var formdata = new FormData();
            formdata.append('file', file);
            return this._http.post('Http://34.93.202.192:8080/SpoorsEmployees/importEmpData', formdata)
                .subscribe(function (res) {
                console.log(res);
                _this.isLoading = false;
                var $toastContent = $('<span>Record has been loaded successfully!!</span>');
                Materialize.toast($toastContent, 2000);
                _this.router.navigate(['/spoorsemployees']);
            }, function (err) {
                var $toastContent = $('<span>' + JSON.parse(err["_body"])[0]["errMessage"] + '</span>');
                Materialize.toast($toastContent, 2000);
                _this.isLoading = false;
            });
        }
    };
    STSportsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-stsports',
            template: __webpack_require__(/*! ./stsports.component.html */ "./src/app/pages/admin/stsports/stsports.component.html"),
            styles: [__webpack_require__(/*! ./stsports.component.css */ "./src/app/pages/admin/stsports/stsports.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _angular_Http__WEBPACK_IMPORTED_MODULE_2__["Http"]])
    ], STSportsComponent);
    return STSportsComponent;
}());



/***/ }),

/***/ "./src/app/pages/admin/stsports/stsportsdetails/stsportsdetails.component.css":
/*!************************************************************************************!*\
  !*** ./src/app/pages/admin/stsports/stsportsdetails/stsportsdetails.component.css ***!
  \************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2FkbWluL3N0c3BvcnRzL3N0c3BvcnRzZGV0YWlscy9zdHNwb3J0c2RldGFpbHMuY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/pages/admin/stsports/stsportsdetails/stsportsdetails.component.html":
/*!*************************************************************************************!*\
  !*** ./src/app/pages/admin/stsports/stsportsdetails/stsportsdetails.component.html ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">  \n    <nav>\n        <div class=\"nav-wrapper white grey-text text-darken-2\">\n          <div class=\"col s12 grey-text text-darken-2\">\n             <a [routerLink]=\"['../../']\" class=\"breadcrumb grey-text\">Dashboard</a>\n            <a [routerLink]=\"['../']\" class=\"breadcrumb grey-text\">STSports</a>\n            <a [routerLink]=\"['./']\" class=\"breadcrumb active\">Details</a>\n          </div>\n        </div>\n    </nav>\n\n    <div class=\"row\" style=\"padding: 0px 20px\">\n    <ul class=\"collapsible popout z-depth-5\" data-collapsible=\"accordion\">\n      <li>\n        <div class=\"collapsible-header light-green-text text-darken-4 active grey lighten-5\" style=\"font-size: 20px\"><i class=\"material-icons amber-text text-darken-4\" style=\"font-size: 30px\">looks_one</i>\n          STSports</div>\n        <div class=\"collapsible-body\">\n  \n          <form >\n                    <div class=\"row\">\n                      <div class=\"input-field col s12 m6  l4 \">\n                        <input  id=\"stName\" type=\"text\" class=\"validate\" [(ngModel)]=\"stName\" name=\"stName\">\n                        <label class=\"active\" for=\"stName\">SportsName</label>\n                      </div>\n\n                      <div class=\"input-field col s12 m6  l4 \">\n                        <input  id=\"description\" type=\"text\" class=\"validate\" [(ngModel)]=\"description\" name=\"description\">\n                         <label class=\"active\" for=\"description\">Description</label>\n                        </div>    \n\n                        <div class=\"input-field col s12 m6  l4 \">\n                          <input  id=\"stCode\" type=\"text\" class=\"validate\" [(ngModel)]=\"stCode\" name=\"stCode\">\n                          <label class=\"active\" for=\"stCode\">SportsCode</label>\n                        </div> \n\n                        \n\n                             \n                         \n                       \n                    </div>\n                    <button class=\"btn waves-effect waves-light cyan\"  (click)=\"createReminder()\" name=\"action\">Save                       <i class=\"material-icons right\">add</i>\n                      </button> \n                      <div class=\"progress\" *ngIf=\"isLoading\">\n                          <div class=\"indeterminate\"></div>\n                      </div>\n                    </form>\n        </div>\n      </li>\n\n     \n    </ul>   \n  </div> \n  \n  </div>\n        "

/***/ }),

/***/ "./src/app/pages/admin/stsports/stsportsdetails/stsportsdetails.component.ts":
/*!***********************************************************************************!*\
  !*** ./src/app/pages/admin/stsports/stsportsdetails/stsportsdetails.component.ts ***!
  \***********************************************************************************/
/*! exports provided: STSportsdetailsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "STSportsdetailsComponent", function() { return STSportsdetailsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _angular_Http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/Http */ "./node_modules/@angular/Http/esm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs/_esm5/add/operator/map.js");





var STSportsdetailsComponent = /** @class */ (function () {
    function STSportsdetailsComponent(_router, _http, route) {
        this._http = _http;
        this.route = route;
        this.isLoading = false;
        this.router = _router;
    }
    STSportsdetailsComponent.prototype.createReminder = function () {
        var _this = this;
        this.isLoading = true;
        var data = {
            "stName": this.stName,
            "description": this.description,
            "stCode": this.stCode,
            "isActive": 'y',
            "isAprroved": 'y'
        };
        if (this.stName == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>SportsName is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.description == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>Description is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.stCode == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>SportsCode is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.editId && this.editId !== "" && this.editId !== "None") {
            data["id"] = this.editId;
            return this._http.put('Http://52.66.246.140:8080/SkillTeck/updateSTSports/', data)
                .subscribe(function (res) {
                console.log(res);
                _this.isLoading = false;
                var $toastContent = $('<span>Record has been saved successfully!!</span>');
                Materialize.toast($toastContent, 2000);
                _this.router.navigate(['/admin/stsports']);
            }, function (err) {
                var $toastContent = $('<span>' + JSON.parse(err["_body"])[0]["errMessage"] + '</span>');
                Materialize.toast($toastContent, 2000);
                _this.isLoading = false;
            });
        }
        else {
            return this._http.post('Http://52.66.246.140:8080/SkillTeck/addSTSports/', data)
                .subscribe(function (res) {
                console.log(res);
                _this.isLoading = false;
                var $toastContent = $('<span>Record has been saved successfully!!</span>');
                Materialize.toast($toastContent, 2000);
                _this.router.navigate(['/admin/stsports']);
            }, function (err) {
                var $toastContent = $('<span>' + JSON.parse(err["_body"])[0]["errMessage"] + '</span>');
                Materialize.toast($toastContent, 2000);
                _this.isLoading = false;
            });
        }
    };
    STSportsdetailsComponent.prototype.moveNext = function (event, tab) {
        $('.collapsible').collapsible('open', tab);
    };
    STSportsdetailsComponent.prototype.ngAfterViewInit = function () {
        this.things.changes.subscribe(function (t) {
            $("select").material_select();
        });
    };
    STSportsdetailsComponent.prototype.ngAfterViewChecked = function () {
        Materialize.updateTextFields();
    };
    STSportsdetailsComponent.prototype.ngOnInit = function () {
        var _this = this;
        $("select").material_select();
        $('.collapsible').collapsible({
            onOpen: function (el) { Materialize.updateTextFields(); }
        });
        this.route
            .queryParamMap
            .map(function (params) { return params.get('session_id') || 'None'; })
            .subscribe(function (val) { return _this.editId = val; });
        console.log(this.editId);
        if (this.editId && this.editId !== "" && this.editId !== "None") {
            this.isLoading = true;
            return this._http.get('Http://52.66.246.140:8080/SkillTeck/getSTSportsById/' + this.editId)
                .map(function (res) { return res.json(); })
                .subscribe(function (data) {
                var record = data[0];
                _this.stName = record["stName"];
                _this.description = record["description"];
                _this.stCode = record["stCode"];
                $("select").material_select();
                Materialize.updateTextFields();
                _this.isLoading = false;
                //debugger;
            }, function (err) {
                console.log('Something went wrong!');
                _this.isLoading = false;
            });
        }
        Materialize.updateTextFields();
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChildren"])('allTheseThings'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], STSportsdetailsComponent.prototype, "things", void 0);
    STSportsdetailsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-stsportsdetails',
            template: __webpack_require__(/*! ./stsportsdetails.component.html */ "./src/app/pages/admin/stsports/stsportsdetails/stsportsdetails.component.html"),
            styles: [__webpack_require__(/*! ./stsportsdetails.component.css */ "./src/app/pages/admin/stsports/stsportsdetails/stsportsdetails.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _angular_Http__WEBPACK_IMPORTED_MODULE_2__["Http"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]])
    ], STSportsdetailsComponent);
    return STSportsdetailsComponent;
}());



/***/ }),

/***/ "./src/app/pages/admin/stsportsactivation/stsportsactivation.component.css":
/*!*********************************************************************************!*\
  !*** ./src/app/pages/admin/stsportsactivation/stsportsactivation.component.css ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2FkbWluL3N0c3BvcnRzYWN0aXZhdGlvbi9zdHNwb3J0c2FjdGl2YXRpb24uY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/pages/admin/stsportsactivation/stsportsactivation.component.html":
/*!**********************************************************************************!*\
  !*** ./src/app/pages/admin/stsportsactivation/stsportsactivation.component.html ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">  \n    <nav class=\"z-depth-0\">\n        <div class=\"nav-wrapper white \">\n          <div class=\"col s5 m9 l9\">\n              <a [routerLink]=\"['../']\" class=\"breadcrumb grey-text\">Dashboard</a>\n               <a [routerLink]=\"['./']\" class=\"breadcrumb active\">STSportsActivation</a>\n          </div>    \n              \n                      \n          <div class=\"col s2 m2 l1\">          \n              <a class=\"waves-effect cyan  btn-large\" style=\"    height: 42px;\n              line-height: 43px;\n              padding: 0px 20px;\"\n              [routerLink]=\"['./stsportsactivationdetails']\"\n              href=\"!#\" ><i class=\"large material-icons\" style=\"font-size: 2rem; height: 42px;\n              line-height: 43px;\">add</i></a>\n          </div>\n        </div>\n    </nav>\n    <div  style=\"padding:5px\">\n        <div style=\"padding: 0px 10px\">\n            \n                  <table class=\"highlight bordered  \" style=\"border: 1px solid #ddd\">\n                    <thead class=\" blue lighten-5\">\n          <tr>\n              <th>ID </th>\n              <th>ActName</th>\n              <th>Description</th>\n              <th>MasterSessionId</th>\n              <th>HeaderText</th>\n              <th>Action</th><th></th>\n                                                 \n             \n\n\n          </tr>\n        </thead>\n      \n        <tbody>\n          <tr *ngFor=\"let record of records;\">\n            <td>{{record.id}}</td>\n            <td>{{record.actName}}</td>         \n            <td>{{record.description}}</td>\n            <td>{{record.masterSessionId}}</td>\n            <td>{{record.headerText}}</td>\n            \n            \n              \n            \n          <!--   <td>{{record.isActive}}</td> -->\n            \n\n              \n            <td>              \n              <a class=\"btn-floating waves-effect waves-light blue darken-3\" (click)=\"edit(record.id)\" ><i class=\"material-icons\">edit</i></a>\n              <a class=\"btn-floating waves-effect waves-light red darken-2 modal-trigger\" (click)=\"selectForDelete(record.id)\" href=\"#modal1\"><i class=\"material-icons\">delete</i></a>\n            </td><td></td>\n          </tr>\n        </tbody>\n      </table>\n      <div class=\"progress\" *ngIf=\"isLoading\">\n          <div class=\"indeterminate\"></div>\n      </div>\n\n      <my-pagination\n        (goPage)=\"goToPage($event)\"\n        (goNext)=\"onNext()\"\n        (goPrev)=\"onPrev()\"\n        [pagesToShow]=\"10\"\n        [page]=\"page\"\n        [perPage]=\"limit\"\n        [count]=\"total\">\n    </my-pagination>   \n      </div>\n     \n  </div> \n  <div id=\"modal12\" class=\"modal\">\n      <div class=\"modal-content\">\n        <h4>Upload the Data</h4>\n        <p>Please Choose the File.</p> <p><input type=\"file\" name=\"file\"   #fileInput (change)=\"onFileSelect($event)\" /></p>\n     <!--  </div>\n      <div class=\"modal-footer\"> -->\n       <a [routerLink]=\"['./']\" (click)=\"uploadExcelSheet()\" class=\"modal-action modal-close waves-effect waves-green btn blue\">Upload</a>  \n </div> <div class=\"modal-content\">\n        <h4>Download the Data</h4>\n       <a [routerLink]=\"['./']\" (click)=\"downloadexcelfile()\" class=\"modal-action modal-close waves-effect waves-green btn red\">Download</a>\n       <p>Total Records: {{totalEmployees}}</p>  \n      </div>\n    </div>\n\n    <div id=\"modal1\" class=\"modal\">\n      <div class=\"modal-content\">\n        <h4>Delete?</h4>\n        <p>Are you sure, you want to delete this record?</p>\n      </div>\n      <div class=\"modal-footer\">\n        <a [routerLink]=\"['./']\" (click)=\"delete()\" class=\"modal-action modal-close waves-effect waves-green btn red\">Delete</a>\n      </div>\n    </div>\n</div>\n        "

/***/ }),

/***/ "./src/app/pages/admin/stsportsactivation/stsportsactivation.component.ts":
/*!********************************************************************************!*\
  !*** ./src/app/pages/admin/stsportsactivation/stsportsactivation.component.ts ***!
  \********************************************************************************/
/*! exports provided: STSportsActivationComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "STSportsActivationComponent", function() { return STSportsActivationComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _angular_Http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/Http */ "./node_modules/@angular/Http/esm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs/_esm5/add/operator/map.js");





var STSportsActivationComponent = /** @class */ (function () {
    function STSportsActivationComponent(_router, _http) {
        this._http = _http;
        this.records = [];
        this.isLoading = false;
        this.total = 0;
        this.page = 1;
        this.limit = 10;
        this.router = _router;
        this.loadIntialListOfEmplyees();
        this.countEmployeeRecords();
    }
    STSportsActivationComponent.prototype.goToPage = function (n) {
        this.page = n;
        this.loadIntialListOfEmplyees();
    };
    STSportsActivationComponent.prototype.onNext = function () {
        this.page++;
        this.loadIntialListOfEmplyees();
    };
    STSportsActivationComponent.prototype.onPrev = function () {
        this.page--;
        this.loadIntialListOfEmplyees();
    };
    STSportsActivationComponent.prototype.loadIntialListOfEmplyees = function () {
        var _this = this;
        this.isLoading = true;
        return this._http.get('Http://52.66.246.140:8080/SkillTeck/listSTSportsActivations?page=' + this.page + '&size=' + this.limit)
            .map(function (res) { return res.json(); })
            .subscribe(function (data) {
            _this.records = data.stsportsActivationList;
            _this.total = data.totalRecords;
            console.log(_this.records);
            _this.isLoading = false;
        }, function (err) {
            console.log('Something went wrong!');
            _this.isLoading = false;
        });
    };
    STSportsActivationComponent.prototype.edit = function (id) {
        var navigationExtras = {
            queryParams: { 'session_id': id },
            skipLocationChange: true
        };
        this.router.navigate(['/admin/stsportsactivation/stsportsactivationdetails'], navigationExtras);
    };
    STSportsActivationComponent.prototype.selectForDelete = function (id) {
        this.deleteId = id;
    };
    STSportsActivationComponent.prototype.delete = function () {
        var _this = this;
        this.isLoading = true;
        return this._http.delete('Http://52.66.246.140:8080/SkillTeck/deleteSTSportsActivation/' + this.deleteId)
            .subscribe(function (data) {
            var $toastContent = $('<span>Record has been deleted successfully!!</span>');
            Materialize.toast($toastContent, 2000);
            _this.isLoading = false;
            _this.loadIntialListOfEmplyees();
        }, function (err) {
            console.log('Something went wrong!');
            _this.isLoading = false;
        });
    };
    STSportsActivationComponent.prototype.moveNext = function (event, tab) {
        $('.collapsible').collapsible('open', tab);
    };
    STSportsActivationComponent.prototype.ngOnInit = function () {
        $("select").material_select();
        $('.collapsible').collapsible();
        $('.modal').modal();
    };
    STSportsActivationComponent.prototype.ngAfterViewChecked = function () {
        var self = this;
    };
    STSportsActivationComponent.prototype.uploadExcelSheet = function () {
    };
    STSportsActivationComponent.prototype.downloadexcel = function () {
    };
    STSportsActivationComponent.prototype.downloadexcelfile = function () {
        var url = 'Http://34.93.202.192:8080/SpoorsReports/getAllEmployeesToPrintXL';
        this.downloadXLFile(url).subscribe(function (res) {
            var fileURL = URL.createObjectURL(res);
            window.open(fileURL);
        });
    };
    STSportsActivationComponent.prototype.downloadXLFile = function (url) {
        return this._http.get(url, { responseType: _angular_Http__WEBPACK_IMPORTED_MODULE_2__["ResponseContentType"].Blob }).map(function (res) {
            return new Blob([res.blob()], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        });
    };
    STSportsActivationComponent.prototype.downloadpdf = function () {
        var url = 'Http://34.93.202.192:8080/SpoorsReports/getAllEmployeesToPrint';
        this.downloadFile(url).subscribe(function (res) {
            var fileURL = URL.createObjectURL(res);
            window.open(fileURL);
        });
    };
    STSportsActivationComponent.prototype.downloadFile = function (url) {
        return this._http.get(url, { responseType: _angular_Http__WEBPACK_IMPORTED_MODULE_2__["ResponseContentType"].Blob }).map(function (res) {
            return new Blob([res.blob()], { type: 'application/pdf' });
        });
    };
    STSportsActivationComponent.prototype.countEmployeeRecords = function () {
        var _this = this;
        this.isLoading = true;
        return this._http.get('Http://34.93.202.192:8080/Spoors/employeesCount')
            .map(function (res) { return res.json(); })
            .subscribe(function (data) {
            _this.totalEmployees = data.totalRecords;
            console.log('Count of Emplyees --- ' + _this.totalEmployees);
        }, function (err) {
            console.log('Something went wrong!');
        });
        this.isLoading = false;
    };
    STSportsActivationComponent.prototype.onFileSelect = function (event) {
        var _this = this;
        console.log('File Change Event !');
        if (event.target.files.length > 0) {
            var file = event.target.files[0];
            var formdata = new FormData();
            formdata.append('file', file);
            return this._http.post('Http://34.93.202.192:8080/SpoorsEmployees/importEmpData', formdata)
                .subscribe(function (res) {
                console.log(res);
                _this.isLoading = false;
                var $toastContent = $('<span>Record has been loaded successfully!!</span>');
                Materialize.toast($toastContent, 2000);
                _this.router.navigate(['/spoorsemployees']);
            }, function (err) {
                var $toastContent = $('<span>' + JSON.parse(err["_body"])[0]["errMessage"] + '</span>');
                Materialize.toast($toastContent, 2000);
                _this.isLoading = false;
            });
        }
    };
    STSportsActivationComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-stsportsactivation',
            template: __webpack_require__(/*! ./stsportsactivation.component.html */ "./src/app/pages/admin/stsportsactivation/stsportsactivation.component.html"),
            styles: [__webpack_require__(/*! ./stsportsactivation.component.css */ "./src/app/pages/admin/stsportsactivation/stsportsactivation.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _angular_Http__WEBPACK_IMPORTED_MODULE_2__["Http"]])
    ], STSportsActivationComponent);
    return STSportsActivationComponent;
}());



/***/ }),

/***/ "./src/app/pages/admin/stsportsactivation/stsportsactivationdetails/stsportsactivationdetails.component.css":
/*!******************************************************************************************************************!*\
  !*** ./src/app/pages/admin/stsportsactivation/stsportsactivationdetails/stsportsactivationdetails.component.css ***!
  \******************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2FkbWluL3N0c3BvcnRzYWN0aXZhdGlvbi9zdHNwb3J0c2FjdGl2YXRpb25kZXRhaWxzL3N0c3BvcnRzYWN0aXZhdGlvbmRldGFpbHMuY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/pages/admin/stsportsactivation/stsportsactivationdetails/stsportsactivationdetails.component.html":
/*!*******************************************************************************************************************!*\
  !*** ./src/app/pages/admin/stsportsactivation/stsportsactivationdetails/stsportsactivationdetails.component.html ***!
  \*******************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">  \n    <nav>\n        <div class=\"nav-wrapper white grey-text text-darken-2\">\n          <div class=\"col s12 grey-text text-darken-2\">\n             <a [routerLink]=\"['../../']\" class=\"breadcrumb grey-text\">Dashboard</a>\n            <a [routerLink]=\"['../']\" class=\"breadcrumb grey-text\">STSportsActivation</a>\n            <a [routerLink]=\"['./']\" class=\"breadcrumb active\">Details</a>\n          </div>\n        </div>\n    </nav>\n\n    <div class=\"row\" style=\"padding: 0px 20px\">\n    <ul class=\"collapsible popout z-depth-5\" data-collapsible=\"accordion\">\n      <li>\n        <div class=\"collapsible-header light-green-text text-darken-4 active grey lighten-5\" style=\"font-size: 20px\"><i class=\"material-icons amber-text text-darken-4\" style=\"font-size: 30px\">looks_one</i>\n          STSportsActivation</div>\n        <div class=\"collapsible-body\">\n  \n          <form >\n                    <div class=\"row\">\n                      <div class=\"input-field col s12 m6  l4 \">\n                        <input  id=\"actName\" type=\"text\" class=\"validate\" [(ngModel)]=\"actName\" name=\"actName\">\n                        <label class=\"active\" for=\"actName\">ActName</label>\n                      </div>\n\n                      <div class=\"input-field col s12 m6  l4 \">\n                        <input  id=\"description\" type=\"text\" class=\"validate\" [(ngModel)]=\"description\" name=\"description\">\n                         <label class=\"active\" for=\"description\">Description</label>\n                        </div>    \n\n                        <div class=\"input-field col s12 m6  l4 \">\n                          <input  id=\"masterSessionId\" type=\"text\" class=\"validate\" [(ngModel)]=\"masterSessionId\" name=\"masterSessionId\">\n                          <label class=\"active\" for=\"masterSessionId\">MasterSessionId</label>\n                        </div> \n\n                        <div class=\"input-field col s12 m6  l4 \">\n                          <input  id=\"headerText\" type=\"text\" class=\"validate\" [(ngModel)]=\"headerText\" name=\"headerText\">\n                          <label class=\"active\" for=\"headerText\">HeaderText</label>\n                        </div> \n\n                             \n                         \n                       \n                    </div>\n                    <button class=\"btn waves-effect waves-light cyan\"  (click)=\"createReminder()\" name=\"action\">Save                       <i class=\"material-icons right\">add</i>\n                      </button> \n                      <div class=\"progress\" *ngIf=\"isLoading\">\n                          <div class=\"indeterminate\"></div>\n                      </div>\n                    </form>\n        </div>\n      </li>\n\n     \n    </ul>   \n  </div> \n  \n  </div>\n        "

/***/ }),

/***/ "./src/app/pages/admin/stsportsactivation/stsportsactivationdetails/stsportsactivationdetails.component.ts":
/*!*****************************************************************************************************************!*\
  !*** ./src/app/pages/admin/stsportsactivation/stsportsactivationdetails/stsportsactivationdetails.component.ts ***!
  \*****************************************************************************************************************/
/*! exports provided: STSportsActivationdetailsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "STSportsActivationdetailsComponent", function() { return STSportsActivationdetailsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _angular_Http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/Http */ "./node_modules/@angular/Http/esm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs/_esm5/add/operator/map.js");





var STSportsActivationdetailsComponent = /** @class */ (function () {
    function STSportsActivationdetailsComponent(_router, _http, route) {
        this._http = _http;
        this.route = route;
        this.isLoading = false;
        this.router = _router;
    }
    STSportsActivationdetailsComponent.prototype.createReminder = function () {
        var _this = this;
        this.isLoading = true;
        var data = {
            "actName": this.actName,
            "description": this.description,
            "masterSessionId": this.masterSessionId,
            "headerText": this.headerText,
            "isActive": 'y',
            "isAprroved": 'y'
        };
        if (this.actName == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>actName is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.description == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>Description is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.masterSessionId == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>masterSessionId is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.headerText == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>headerText is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.editId && this.editId !== "" && this.editId !== "None") {
            data["id"] = this.editId;
            return this._http.put('Http://52.66.246.140:8080/SkillTeck/updateSTSportsActivation/', data)
                .subscribe(function (res) {
                console.log(res);
                _this.isLoading = false;
                var $toastContent = $('<span>Record has been saved successfully!!</span>');
                Materialize.toast($toastContent, 2000);
                _this.router.navigate(['/admin/stsportsactivation']);
            }, function (err) {
                var $toastContent = $('<span>' + JSON.parse(err["_body"])[0]["errMessage"] + '</span>');
                Materialize.toast($toastContent, 2000);
                _this.isLoading = false;
            });
        }
        else {
            return this._http.post('Http://52.66.246.140:8080/SkillTeck/addSTSportsActivation/', data)
                .subscribe(function (res) {
                console.log(res);
                _this.isLoading = false;
                var $toastContent = $('<span>Record has been saved successfully!!</span>');
                Materialize.toast($toastContent, 2000);
                _this.router.navigate(['/admin/stsportsactivation']);
            }, function (err) {
                var $toastContent = $('<span>' + JSON.parse(err["_body"])[0]["errMessage"] + '</span>');
                Materialize.toast($toastContent, 2000);
                _this.isLoading = false;
            });
        }
    };
    STSportsActivationdetailsComponent.prototype.moveNext = function (event, tab) {
        $('.collapsible').collapsible('open', tab);
    };
    STSportsActivationdetailsComponent.prototype.ngAfterViewInit = function () {
        this.things.changes.subscribe(function (t) {
            $("select").material_select();
        });
    };
    STSportsActivationdetailsComponent.prototype.ngAfterViewChecked = function () {
        Materialize.updateTextFields();
    };
    STSportsActivationdetailsComponent.prototype.ngOnInit = function () {
        var _this = this;
        $("select").material_select();
        $('.collapsible').collapsible({
            onOpen: function (el) { Materialize.updateTextFields(); }
        });
        this.route
            .queryParamMap
            .map(function (params) { return params.get('session_id') || 'None'; })
            .subscribe(function (val) { return _this.editId = val; });
        console.log(this.editId);
        if (this.editId && this.editId !== "" && this.editId !== "None") {
            this.isLoading = true;
            return this._http.get('Http://52.66.246.140:8080/SkillTeck/getSTSportsActivationById/' + this.editId)
                .map(function (res) { return res.json(); })
                .subscribe(function (data) {
                var record = data[0];
                _this.actName = record["actName"];
                _this.description = record["description"];
                _this.masterSessionId = record["masterSessionId"];
                _this.headerText = record["headerText"];
                $("select").material_select();
                Materialize.updateTextFields();
                _this.isLoading = false;
                //debugger;
            }, function (err) {
                console.log('Something went wrong!');
                _this.isLoading = false;
            });
        }
        Materialize.updateTextFields();
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChildren"])('allTheseThings'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], STSportsActivationdetailsComponent.prototype, "things", void 0);
    STSportsActivationdetailsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-stsportsactivationdetails',
            template: __webpack_require__(/*! ./stsportsactivationdetails.component.html */ "./src/app/pages/admin/stsportsactivation/stsportsactivationdetails/stsportsactivationdetails.component.html"),
            styles: [__webpack_require__(/*! ./stsportsactivationdetails.component.css */ "./src/app/pages/admin/stsportsactivation/stsportsactivationdetails/stsportsactivationdetails.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _angular_Http__WEBPACK_IMPORTED_MODULE_2__["Http"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]])
    ], STSportsActivationdetailsComponent);
    return STSportsActivationdetailsComponent;
}());



/***/ }),

/***/ "./src/app/pages/admin/stsportsenrollment/stsportsenrollment.component.css":
/*!*********************************************************************************!*\
  !*** ./src/app/pages/admin/stsportsenrollment/stsportsenrollment.component.css ***!
  \*********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2FkbWluL3N0c3BvcnRzZW5yb2xsbWVudC9zdHNwb3J0c2Vucm9sbG1lbnQuY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/pages/admin/stsportsenrollment/stsportsenrollment.component.html":
/*!**********************************************************************************!*\
  !*** ./src/app/pages/admin/stsportsenrollment/stsportsenrollment.component.html ***!
  \**********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">  \n    <nav class=\"z-depth-0\">\n        <div class=\"nav-wrapper white \">\n          <div class=\"col s5 m9 l9\">\n              <a [routerLink]=\"['../']\" class=\"breadcrumb grey-text\">Dashboard</a>\n               <a [routerLink]=\"['./']\" class=\"breadcrumb active\">STSportsEnrollment</a>\n          </div>    \n              \n                      \n          <div class=\"col s2 m2 l1\">          \n              <a class=\"waves-effect cyan  btn-large\" style=\"    height: 42px;\n              line-height: 43px;\n              padding: 0px 20px;\"\n              [routerLink]=\"['./stsportsenrollmentdetails']\"\n              href=\"!#\" ><i class=\"large material-icons\" style=\"font-size: 2rem; height: 42px;\n              line-height: 43px;\">add</i></a>\n          </div>\n        </div>\n    </nav>\n    <div  style=\"padding:5px\">\n        <div style=\"padding: 0px 10px\">\n            \n                  <table class=\"highlight bordered  \" style=\"border: 1px solid #ddd\">\n                    <thead class=\" blue lighten-5\">\n          <tr>\n              <th>ID </th>\n              <th>StudentId</th>\n              <th>SportsId</th>\n              <th>EnrollmentDate</th>\n              <th>coachId</th>\n              <th>Action</th><th></th>\n                      \n\n\n\n                           \n             \n\n          </tr>\n        </thead>\n      \n        <tbody>\n          <tr *ngFor=\"let record of records;\">\n            <td>{{record.id}}</td>\n            <td>{{record.studentId}}</td>         \n            <td>{{record.sportsId}}</td>\n            <td>{{record.enrollmentDate}}</td>\n            <td>{{record.coachId}}</td>\n            \n              \n            \n          <!--   <td>{{record.isActive}}</td> -->\n            \n\n              \n            <td>              \n              <a class=\"btn-floating waves-effect waves-light blue darken-3\" (click)=\"edit(record.id)\" ><i class=\"material-icons\">edit</i></a>\n              <a class=\"btn-floating waves-effect waves-light red darken-2 modal-trigger\" (click)=\"selectForDelete(record.id)\" href=\"#modal1\"><i class=\"material-icons\">delete</i></a>\n            </td><td></td>\n          </tr>\n        </tbody>\n      </table>\n      <div class=\"progress\" *ngIf=\"isLoading\">\n          <div class=\"indeterminate\"></div>\n      </div>\n\n      <my-pagination\n        (goPage)=\"goToPage($event)\"\n        (goNext)=\"onNext()\"\n        (goPrev)=\"onPrev()\"\n        [pagesToShow]=\"10\"\n        [page]=\"page\"\n        [perPage]=\"limit\"\n        [count]=\"total\">\n    </my-pagination>   \n      </div>\n     \n  </div> \n  <div id=\"modal12\" class=\"modal\">\n      <div class=\"modal-content\">\n        <h4>Upload the Data</h4>\n        <p>Please Choose the File.</p> <p><input type=\"file\" name=\"file\"   #fileInput (change)=\"onFileSelect($event)\" /></p>\n     <!--  </div>\n      <div class=\"modal-footer\"> -->\n       <a [routerLink]=\"['./']\" (click)=\"uploadExcelSheet()\" class=\"modal-action modal-close waves-effect waves-green btn blue\">Upload</a>  \n </div> <div class=\"modal-content\">\n        <h4>Download the Data</h4>\n       <a [routerLink]=\"['./']\" (click)=\"downloadexcelfile()\" class=\"modal-action modal-close waves-effect waves-green btn red\">Download</a>\n       <p>Total Records: {{totalEmployees}}</p>  \n      </div>\n    </div>\n\n    <div id=\"modal1\" class=\"modal\">\n      <div class=\"modal-content\">\n        <h4>Delete?</h4>\n        <p>Are you sure, you want to delete this record?</p>\n      </div>\n      <div class=\"modal-footer\">\n        <a [routerLink]=\"['./']\" (click)=\"delete()\" class=\"modal-action modal-close waves-effect waves-green btn red\">Delete</a>\n      </div>\n    </div>\n</div>\n        "

/***/ }),

/***/ "./src/app/pages/admin/stsportsenrollment/stsportsenrollment.component.ts":
/*!********************************************************************************!*\
  !*** ./src/app/pages/admin/stsportsenrollment/stsportsenrollment.component.ts ***!
  \********************************************************************************/
/*! exports provided: STSportsEnrollmentComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "STSportsEnrollmentComponent", function() { return STSportsEnrollmentComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _angular_Http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/Http */ "./node_modules/@angular/Http/esm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs/_esm5/add/operator/map.js");





var STSportsEnrollmentComponent = /** @class */ (function () {
    function STSportsEnrollmentComponent(_router, _http) {
        this._http = _http;
        this.records = [];
        this.isLoading = false;
        this.total = 0;
        this.page = 1;
        this.limit = 10;
        this.router = _router;
        this.loadIntialListOfEmplyees();
        this.countEmployeeRecords();
    }
    STSportsEnrollmentComponent.prototype.goToPage = function (n) {
        this.page = n;
        this.loadIntialListOfEmplyees();
    };
    STSportsEnrollmentComponent.prototype.onNext = function () {
        this.page++;
        this.loadIntialListOfEmplyees();
    };
    STSportsEnrollmentComponent.prototype.onPrev = function () {
        this.page--;
        this.loadIntialListOfEmplyees();
    };
    STSportsEnrollmentComponent.prototype.loadIntialListOfEmplyees = function () {
        var _this = this;
        this.isLoading = true;
        return this._http.get('Http://52.66.246.140:8080/SkillTeck/listSTSportsEnrollments?page=' + this.page + '&size=' + this.limit)
            .map(function (res) { return res.json(); })
            .subscribe(function (data) {
            _this.records = data.stsportsEnrollmentList;
            _this.total = data.totalRecords;
            console.log(_this.records);
            _this.isLoading = false;
        }, function (err) {
            console.log('Something went wrong!');
            _this.isLoading = false;
        });
    };
    STSportsEnrollmentComponent.prototype.edit = function (id) {
        var navigationExtras = {
            queryParams: { 'session_id': id },
            skipLocationChange: true
        };
        this.router.navigate(['/admin/stsportsenrollment/stsportsenrollmentdetails'], navigationExtras);
    };
    STSportsEnrollmentComponent.prototype.selectForDelete = function (id) {
        this.deleteId = id;
    };
    STSportsEnrollmentComponent.prototype.delete = function () {
        var _this = this;
        this.isLoading = true;
        return this._http.delete('Http://52.66.246.140:8080/SkillTeck/deleteSTSportsEnrollment/' + this.deleteId)
            .subscribe(function (data) {
            var $toastContent = $('<span>Record has been deleted successfully!!</span>');
            Materialize.toast($toastContent, 2000);
            _this.isLoading = false;
            _this.loadIntialListOfEmplyees();
        }, function (err) {
            console.log('Something went wrong!');
            _this.isLoading = false;
        });
    };
    STSportsEnrollmentComponent.prototype.moveNext = function (event, tab) {
        $('.collapsible').collapsible('open', tab);
    };
    STSportsEnrollmentComponent.prototype.ngOnInit = function () {
        $("select").material_select();
        $('.collapsible').collapsible();
        $('.modal').modal();
    };
    STSportsEnrollmentComponent.prototype.ngAfterViewChecked = function () {
        var self = this;
    };
    STSportsEnrollmentComponent.prototype.uploadExcelSheet = function () {
    };
    STSportsEnrollmentComponent.prototype.downloadexcel = function () {
    };
    STSportsEnrollmentComponent.prototype.downloadexcelfile = function () {
        var url = 'Http://34.93.202.192:8080/SpoorsReports/getAllEmployeesToPrintXL';
        this.downloadXLFile(url).subscribe(function (res) {
            var fileURL = URL.createObjectURL(res);
            window.open(fileURL);
        });
    };
    STSportsEnrollmentComponent.prototype.downloadXLFile = function (url) {
        return this._http.get(url, { responseType: _angular_Http__WEBPACK_IMPORTED_MODULE_2__["ResponseContentType"].Blob }).map(function (res) {
            return new Blob([res.blob()], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        });
    };
    STSportsEnrollmentComponent.prototype.downloadpdf = function () {
        var url = 'Http://34.93.202.192:8080/SpoorsReports/getAllEmployeesToPrint';
        this.downloadFile(url).subscribe(function (res) {
            var fileURL = URL.createObjectURL(res);
            window.open(fileURL);
        });
    };
    STSportsEnrollmentComponent.prototype.downloadFile = function (url) {
        return this._http.get(url, { responseType: _angular_Http__WEBPACK_IMPORTED_MODULE_2__["ResponseContentType"].Blob }).map(function (res) {
            return new Blob([res.blob()], { type: 'application/pdf' });
        });
    };
    STSportsEnrollmentComponent.prototype.countEmployeeRecords = function () {
        var _this = this;
        this.isLoading = true;
        return this._http.get('Http://34.93.202.192:8080/Spoors/employeesCount')
            .map(function (res) { return res.json(); })
            .subscribe(function (data) {
            _this.totalEmployees = data.totalRecords;
            console.log('Count of Emplyees --- ' + _this.totalEmployees);
        }, function (err) {
            console.log('Something went wrong!');
        });
        this.isLoading = false;
    };
    STSportsEnrollmentComponent.prototype.onFileSelect = function (event) {
        var _this = this;
        console.log('File Change Event !');
        if (event.target.files.length > 0) {
            var file = event.target.files[0];
            var formdata = new FormData();
            formdata.append('file', file);
            return this._http.post('Http://34.93.202.192:8080/SpoorsEmployees/importEmpData', formdata)
                .subscribe(function (res) {
                console.log(res);
                _this.isLoading = false;
                var $toastContent = $('<span>Record has been loaded successfully!!</span>');
                Materialize.toast($toastContent, 2000);
                _this.router.navigate(['/spoorsemployees']);
            }, function (err) {
                var $toastContent = $('<span>' + JSON.parse(err["_body"])[0]["errMessage"] + '</span>');
                Materialize.toast($toastContent, 2000);
                _this.isLoading = false;
            });
        }
    };
    STSportsEnrollmentComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-stsportsenrollment',
            template: __webpack_require__(/*! ./stsportsenrollment.component.html */ "./src/app/pages/admin/stsportsenrollment/stsportsenrollment.component.html"),
            styles: [__webpack_require__(/*! ./stsportsenrollment.component.css */ "./src/app/pages/admin/stsportsenrollment/stsportsenrollment.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _angular_Http__WEBPACK_IMPORTED_MODULE_2__["Http"]])
    ], STSportsEnrollmentComponent);
    return STSportsEnrollmentComponent;
}());



/***/ }),

/***/ "./src/app/pages/admin/stsportsenrollment/stsportsenrollmentdetails/stsportsenrollmentdetails.component.css":
/*!******************************************************************************************************************!*\
  !*** ./src/app/pages/admin/stsportsenrollment/stsportsenrollmentdetails/stsportsenrollmentdetails.component.css ***!
  \******************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2FkbWluL3N0c3BvcnRzZW5yb2xsbWVudC9zdHNwb3J0c2Vucm9sbG1lbnRkZXRhaWxzL3N0c3BvcnRzZW5yb2xsbWVudGRldGFpbHMuY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/pages/admin/stsportsenrollment/stsportsenrollmentdetails/stsportsenrollmentdetails.component.html":
/*!*******************************************************************************************************************!*\
  !*** ./src/app/pages/admin/stsportsenrollment/stsportsenrollmentdetails/stsportsenrollmentdetails.component.html ***!
  \*******************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">  \n    <nav>\n        <div class=\"nav-wrapper white grey-text text-darken-2\">\n          <div class=\"col s12 grey-text text-darken-2\">\n             <a [routerLink]=\"['../../']\" class=\"breadcrumb grey-text\">Dashboard</a>\n            <a [routerLink]=\"['../']\" class=\"breadcrumb grey-text\">STSportsEnrollment</a>\n            <a [routerLink]=\"['./']\" class=\"breadcrumb active\">Details</a>\n          </div>\n        </div>\n    </nav>\n\n    <div class=\"row\" style=\"padding: 0px 20px\">\n    <ul class=\"collapsible popout z-depth-5\" data-collapsible=\"accordion\">\n      <li>\n        <div class=\"collapsible-header light-green-text text-darken-4 active grey lighten-5\" style=\"font-size: 20px\"><i class=\"material-icons amber-text text-darken-4\" style=\"font-size: 30px\">looks_one</i>\n          STSportsEnrollment</div>\n        <div class=\"collapsible-body\">\n  \n          <form >\n                    <div class=\"row\">\n                      \n                        <div class=\"input-field col s12 m6  l4 \">\n                          <input  id=\"studentId\" type=\"text\" class=\"validate\" [(ngModel)]=\"studentId\" name=\"studentId\">\n                          <label class=\"active\" for=\"studentId\">StudentId</label>\n                        </div> \n\n                        <div class=\"input-field col s12 m6  l4 \">\n                        <input  id=\"sportsId\" type=\"text\" class=\"validate\" [(ngModel)]=\"sportsId\" name=\"sportsId\">\n                        <label class=\"active\" for=\"sportsId\">SportsId</label>\n                      </div>\n\n                      <div class=\"input-field col s12 m6  l4 \">\n                        <input  id=\"enrollmentDate\" type=\"text\" class=\"validate\" [(ngModel)]=\"enrollmentDate\" name=\"enrollmentDate\">\n                         <label class=\"active\" for=\"enrollmentDate\">EnrollmentDate</label>\n                        </div>    \n                      \n\n                      <div class=\"input-field col s12 m6  l4 \">\n                        <input  id=\"coachId\" type=\"text\" class=\"validate\" [(ngModel)]=\"coachId\" name=\"coachId\">\n                         <label class=\"active\" for=\"coachId\">CoachId</label>\n                        </div>    \n                             \n                         \n                       \n                    </div>\n                    <button class=\"btn waves-effect waves-light cyan\"  (click)=\"createReminder()\" name=\"action\">Save                       <i class=\"material-icons right\">add</i>\n                      </button> \n                      <div class=\"progress\" *ngIf=\"isLoading\">\n                          <div class=\"indeterminate\"></div>\n                      </div>\n                    </form>\n        </div>\n      </li>\n\n     \n    </ul>   \n  </div> \n  \n  </div>\n        "

/***/ }),

/***/ "./src/app/pages/admin/stsportsenrollment/stsportsenrollmentdetails/stsportsenrollmentdetails.component.ts":
/*!*****************************************************************************************************************!*\
  !*** ./src/app/pages/admin/stsportsenrollment/stsportsenrollmentdetails/stsportsenrollmentdetails.component.ts ***!
  \*****************************************************************************************************************/
/*! exports provided: STSportsEnrollmentdetailsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "STSportsEnrollmentdetailsComponent", function() { return STSportsEnrollmentdetailsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _angular_Http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/Http */ "./node_modules/@angular/Http/esm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs/_esm5/add/operator/map.js");





var STSportsEnrollmentdetailsComponent = /** @class */ (function () {
    function STSportsEnrollmentdetailsComponent(_router, _http, route) {
        this._http = _http;
        this.route = route;
        this.isLoading = false;
        this.router = _router;
    }
    STSportsEnrollmentdetailsComponent.prototype.createReminder = function () {
        var _this = this;
        this.isLoading = true;
        var data = {
            "studentId": this.studentId,
            "sportsId": this.sportsId,
            "enrollmentDate": this.enrollmentDate,
            "coachId": this.coachId,
            "isActive": 'y',
            "isAprroved": 'y'
        };
        if (this.studentId == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>studentId is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.sportsId == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>sportsId is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.enrollmentDate == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>enrollmentDate is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.coachId == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>coachId is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.editId && this.editId !== "" && this.editId !== "None") {
            data["id"] = this.editId;
            return this._http.put('Http://52.66.246.140:8080/SkillTeck/updateSTSportsEnrollment/', data)
                .subscribe(function (res) {
                console.log(res);
                _this.isLoading = false;
                var $toastContent = $('<span>Record has been saved successfully!!</span>');
                Materialize.toast($toastContent, 2000);
                _this.router.navigate(['/admin/stsportsenrollment']);
            }, function (err) {
                var $toastContent = $('<span>' + JSON.parse(err["_body"])[0]["errMessage"] + '</span>');
                Materialize.toast($toastContent, 2000);
                _this.isLoading = false;
            });
        }
        else {
            return this._http.post('Http://52.66.246.140:8080/SkillTeck/addSTSportsEnrollment/', data)
                .subscribe(function (res) {
                console.log(res);
                _this.isLoading = false;
                var $toastContent = $('<span>Record has been saved successfully!!</span>');
                Materialize.toast($toastContent, 2000);
                _this.router.navigate(['/admin/stsportsenrollment']);
            }, function (err) {
                var $toastContent = $('<span>' + JSON.parse(err["_body"])[0]["errMessage"] + '</span>');
                Materialize.toast($toastContent, 2000);
                _this.isLoading = false;
            });
        }
    };
    STSportsEnrollmentdetailsComponent.prototype.moveNext = function (event, tab) {
        $('.collapsible').collapsible('open', tab);
    };
    STSportsEnrollmentdetailsComponent.prototype.ngAfterViewInit = function () {
        this.things.changes.subscribe(function (t) {
            $("select").material_select();
        });
    };
    STSportsEnrollmentdetailsComponent.prototype.ngAfterViewChecked = function () {
        Materialize.updateTextFields();
    };
    STSportsEnrollmentdetailsComponent.prototype.ngOnInit = function () {
        var _this = this;
        $("select").material_select();
        $('.collapsible').collapsible({
            onOpen: function (el) { Materialize.updateTextFields(); }
        });
        this.route
            .queryParamMap
            .map(function (params) { return params.get('session_id') || 'None'; })
            .subscribe(function (val) { return _this.editId = val; });
        console.log(this.editId);
        if (this.editId && this.editId !== "" && this.editId !== "None") {
            this.isLoading = true;
            return this._http.get('Http://52.66.246.140:8080/SkillTeck/getSTSportsEnrollmentById/' + this.editId)
                .map(function (res) { return res.json(); })
                .subscribe(function (data) {
                var record = data[0];
                _this.studentId = record["studentId"];
                _this.sportsId = record["sportsId"];
                _this.enrollmentDate = record["enrollmentDate"];
                _this.coachId = record["coachId"];
                $("select").material_select();
                Materialize.updateTextFields();
                _this.isLoading = false;
                //debugger;
            }, function (err) {
                console.log('Something went wrong!');
                _this.isLoading = false;
            });
        }
        Materialize.updateTextFields();
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChildren"])('allTheseThings'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], STSportsEnrollmentdetailsComponent.prototype, "things", void 0);
    STSportsEnrollmentdetailsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-stsportsenrollmentdetails',
            template: __webpack_require__(/*! ./stsportsenrollmentdetails.component.html */ "./src/app/pages/admin/stsportsenrollment/stsportsenrollmentdetails/stsportsenrollmentdetails.component.html"),
            styles: [__webpack_require__(/*! ./stsportsenrollmentdetails.component.css */ "./src/app/pages/admin/stsportsenrollment/stsportsenrollmentdetails/stsportsenrollmentdetails.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _angular_Http__WEBPACK_IMPORTED_MODULE_2__["Http"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]])
    ], STSportsEnrollmentdetailsComponent);
    return STSportsEnrollmentdetailsComponent;
}());



/***/ }),

/***/ "./src/app/pages/admin/stsportssession/stsportssession.component.css":
/*!***************************************************************************!*\
  !*** ./src/app/pages/admin/stsportssession/stsportssession.component.css ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2FkbWluL3N0c3BvcnRzc2Vzc2lvbi9zdHNwb3J0c3Nlc3Npb24uY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/pages/admin/stsportssession/stsportssession.component.html":
/*!****************************************************************************!*\
  !*** ./src/app/pages/admin/stsportssession/stsportssession.component.html ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">  \n    <nav class=\"z-depth-0\">\n        <div class=\"nav-wrapper white \">\n          <div class=\"col s5 m9 l9\">\n              <a [routerLink]=\"['../']\" class=\"breadcrumb grey-text\">Dashboard</a>\n               <a [routerLink]=\"['./']\" class=\"breadcrumb active\">STSportsSession</a>\n          </div>    \n              \n                      \n          <div class=\"col s2 m2 l1\">          \n              <a class=\"waves-effect cyan  btn-large\" style=\"    height: 42px;\n              line-height: 43px;\n              padding: 0px 20px;\"\n              [routerLink]=\"['./stsportssessiondetails']\"\n              href=\"!#\" ><i class=\"large material-icons\" style=\"font-size: 2rem; height: 42px;\n              line-height: 43px;\">add</i></a>\n          </div>\n        </div>\n    </nav>\n    <div  style=\"padding:5px\">\n        <div style=\"padding: 0px 10px\">\n            \n                  <table class=\"highlight bordered  \" style=\"border: 1px solid #ddd\">\n                    <thead class=\" blue lighten-5\">\n          <tr>\n              <th>ID </th>\n              <th>StudentId</th>\n              <th>SportsId</th>\n              <th>SessionDate</th>\n              <th>sessionTime</th>\n              <!--\n              <th>videoURL</th>\n              <th>Description</th>\n              <th>HeaderText</th> -->\n              <th>Action</th><th></th>\n                                                 \n    \n\n          </tr>\n        </thead>\n      \n        <tbody>\n          <tr *ngFor=\"let record of records;\">\n            <td>{{record.id}}</td>\n            <td>{{record.studentId}}</td>\n            <td>{{record.sportsId}}</td>         \n            <td>{{record.sessionDate}}</td>\n            <td>{{record.sessionTime}}</td>\n            <!--\n            <td>{{record.videoURL}}</td>\n            <td>{{record.description}}</td>\n            <td>{{record.headerText}}</td> -->\n            \n              \n            \n          <!--   <td>{{record.isActive}}</td> -->\n            \n\n              \n            <td>              \n              <a class=\"btn-floating waves-effect waves-light blue darken-3\" (click)=\"edit(record.id)\" ><i class=\"material-icons\">edit</i></a>\n              <a class=\"btn-floating waves-effect waves-light red darken-2 modal-trigger\" (click)=\"selectForDelete(record.id)\" href=\"#modal1\"><i class=\"material-icons\">delete</i></a>\n            </td><td></td>\n          </tr>\n        </tbody>\n      </table>\n      <div class=\"progress\" *ngIf=\"isLoading\">\n          <div class=\"indeterminate\"></div>\n      </div>\n\n      <my-pagination\n        (goPage)=\"goToPage($event)\"\n        (goNext)=\"onNext()\"\n        (goPrev)=\"onPrev()\"\n        [pagesToShow]=\"10\"\n        [page]=\"page\"\n        [perPage]=\"limit\"\n        [count]=\"total\">\n    </my-pagination>   \n      </div>\n     \n  </div> \n  <div id=\"modal12\" class=\"modal\">\n      <div class=\"modal-content\">\n        <h4>Upload the Data</h4>\n        <p>Please Choose the File.</p> <p><input type=\"file\" name=\"file\"   #fileInput (change)=\"onFileSelect($event)\" /></p>\n     <!--  </div>\n      <div class=\"modal-footer\"> -->\n       <a [routerLink]=\"['./']\" (click)=\"uploadExcelSheet()\" class=\"modal-action modal-close waves-effect waves-green btn blue\">Upload</a>  \n </div> <div class=\"modal-content\">\n        <h4>Download the Data</h4>\n       <a [routerLink]=\"['./']\" (click)=\"downloadexcelfile()\" class=\"modal-action modal-close waves-effect waves-green btn red\">Download</a>\n       <p>Total Records: {{totalEmployees}}</p>  \n      </div>\n    </div>\n\n    <div id=\"modal1\" class=\"modal\">\n      <div class=\"modal-content\">\n        <h4>Delete?</h4>\n        <p>Are you sure, you want to delete this record?</p>\n      </div>\n      <div class=\"modal-footer\">\n        <a [routerLink]=\"['./']\" (click)=\"delete()\" class=\"modal-action modal-close waves-effect waves-green btn red\">Delete</a>\n      </div>\n    </div>\n</div>\n        "

/***/ }),

/***/ "./src/app/pages/admin/stsportssession/stsportssession.component.ts":
/*!**************************************************************************!*\
  !*** ./src/app/pages/admin/stsportssession/stsportssession.component.ts ***!
  \**************************************************************************/
/*! exports provided: STSportsSessionComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "STSportsSessionComponent", function() { return STSportsSessionComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _angular_Http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/Http */ "./node_modules/@angular/Http/esm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs/_esm5/add/operator/map.js");





var STSportsSessionComponent = /** @class */ (function () {
    function STSportsSessionComponent(_router, _http) {
        this._http = _http;
        this.records = [];
        this.isLoading = false;
        this.total = 0;
        this.page = 1;
        this.limit = 10;
        this.router = _router;
        this.loadIntialListOfEmplyees();
        this.countEmployeeRecords();
    }
    STSportsSessionComponent.prototype.goToPage = function (n) {
        this.page = n;
        this.loadIntialListOfEmplyees();
    };
    STSportsSessionComponent.prototype.onNext = function () {
        this.page++;
        this.loadIntialListOfEmplyees();
    };
    STSportsSessionComponent.prototype.onPrev = function () {
        this.page--;
        this.loadIntialListOfEmplyees();
    };
    STSportsSessionComponent.prototype.loadIntialListOfEmplyees = function () {
        var _this = this;
        this.isLoading = true;
        return this._http.get('Http://52.66.246.140:8080/SkillTeck/listSTSportsSessionss?page=' + this.page + '&size=' + this.limit)
            .map(function (res) { return res.json(); })
            .subscribe(function (data) {
            _this.records = data.stsportsSessionsList;
            _this.total = data.totalRecords;
            console.log(_this.records);
            _this.isLoading = false;
        }, function (err) {
            console.log('Something went wrong!');
            _this.isLoading = false;
        });
    };
    STSportsSessionComponent.prototype.edit = function (id) {
        var navigationExtras = {
            queryParams: { 'session_id': id },
            skipLocationChange: true
        };
        this.router.navigate(['/admin/stsportssession/stsportssessiondetails'], navigationExtras);
    };
    STSportsSessionComponent.prototype.selectForDelete = function (id) {
        this.deleteId = id;
    };
    STSportsSessionComponent.prototype.delete = function () {
        var _this = this;
        this.isLoading = true;
        return this._http.delete('Http://52.66.246.140:8080/SkillTeck/deleteSTSportsSessions/' + this.deleteId)
            .subscribe(function (data) {
            var $toastContent = $('<span>Record has been deleted successfully!!</span>');
            Materialize.toast($toastContent, 2000);
            _this.isLoading = false;
            _this.loadIntialListOfEmplyees();
        }, function (err) {
            console.log('Something went wrong!');
            _this.isLoading = false;
        });
    };
    STSportsSessionComponent.prototype.moveNext = function (event, tab) {
        $('.collapsible').collapsible('open', tab);
    };
    STSportsSessionComponent.prototype.ngOnInit = function () {
        $("select").material_select();
        $('.collapsible').collapsible();
        $('.modal').modal();
    };
    STSportsSessionComponent.prototype.ngAfterViewChecked = function () {
        var self = this;
    };
    STSportsSessionComponent.prototype.uploadExcelSheet = function () {
    };
    STSportsSessionComponent.prototype.downloadexcel = function () {
    };
    STSportsSessionComponent.prototype.downloadexcelfile = function () {
        var url = 'Http://34.93.202.192:8080/SpoorsReports/getAllEmployeesToPrintXL';
        this.downloadXLFile(url).subscribe(function (res) {
            var fileURL = URL.createObjectURL(res);
            window.open(fileURL);
        });
    };
    STSportsSessionComponent.prototype.downloadXLFile = function (url) {
        return this._http.get(url, { responseType: _angular_Http__WEBPACK_IMPORTED_MODULE_2__["ResponseContentType"].Blob }).map(function (res) {
            return new Blob([res.blob()], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        });
    };
    STSportsSessionComponent.prototype.downloadpdf = function () {
        var url = 'Http://34.93.202.192:8080/SpoorsReports/getAllEmployeesToPrint';
        this.downloadFile(url).subscribe(function (res) {
            var fileURL = URL.createObjectURL(res);
            window.open(fileURL);
        });
    };
    STSportsSessionComponent.prototype.downloadFile = function (url) {
        return this._http.get(url, { responseType: _angular_Http__WEBPACK_IMPORTED_MODULE_2__["ResponseContentType"].Blob }).map(function (res) {
            return new Blob([res.blob()], { type: 'application/pdf' });
        });
    };
    STSportsSessionComponent.prototype.countEmployeeRecords = function () {
        var _this = this;
        this.isLoading = true;
        return this._http.get('Http://34.93.202.192:8080/Spoors/employeesCount')
            .map(function (res) { return res.json(); })
            .subscribe(function (data) {
            _this.totalEmployees = data.totalRecords;
            console.log('Count of Emplyees --- ' + _this.totalEmployees);
        }, function (err) {
            console.log('Something went wrong!');
        });
        this.isLoading = false;
    };
    STSportsSessionComponent.prototype.onFileSelect = function (event) {
        var _this = this;
        console.log('File Change Event !');
        if (event.target.files.length > 0) {
            var file = event.target.files[0];
            var formdata = new FormData();
            formdata.append('file', file);
            return this._http.post('Http://34.93.202.192:8080/SpoorsEmployees/importEmpData', formdata)
                .subscribe(function (res) {
                console.log(res);
                _this.isLoading = false;
                var $toastContent = $('<span>Record has been loaded successfully!!</span>');
                Materialize.toast($toastContent, 2000);
                _this.router.navigate(['/spoorsemployees']);
            }, function (err) {
                var $toastContent = $('<span>' + JSON.parse(err["_body"])[0]["errMessage"] + '</span>');
                Materialize.toast($toastContent, 2000);
                _this.isLoading = false;
            });
        }
    };
    STSportsSessionComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-stsportssession',
            template: __webpack_require__(/*! ./stsportssession.component.html */ "./src/app/pages/admin/stsportssession/stsportssession.component.html"),
            styles: [__webpack_require__(/*! ./stsportssession.component.css */ "./src/app/pages/admin/stsportssession/stsportssession.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _angular_Http__WEBPACK_IMPORTED_MODULE_2__["Http"]])
    ], STSportsSessionComponent);
    return STSportsSessionComponent;
}());



/***/ }),

/***/ "./src/app/pages/admin/stsportssession/stsportssessiondetails/stsportssessiondetails.component.css":
/*!*********************************************************************************************************!*\
  !*** ./src/app/pages/admin/stsportssession/stsportssessiondetails/stsportssessiondetails.component.css ***!
  \*********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2FkbWluL3N0c3BvcnRzc2Vzc2lvbi9zdHNwb3J0c3Nlc3Npb25kZXRhaWxzL3N0c3BvcnRzc2Vzc2lvbmRldGFpbHMuY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/pages/admin/stsportssession/stsportssessiondetails/stsportssessiondetails.component.html":
/*!**********************************************************************************************************!*\
  !*** ./src/app/pages/admin/stsportssession/stsportssessiondetails/stsportssessiondetails.component.html ***!
  \**********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">  \n    <nav>\n        <div class=\"nav-wrapper white grey-text text-darken-2\">\n          <div class=\"col s12 grey-text text-darken-2\">\n             <a [routerLink]=\"['../../']\" class=\"breadcrumb grey-text\">Dashboard</a>\n            <a [routerLink]=\"['../']\" class=\"breadcrumb grey-text\">STSportsSession</a>\n            <a [routerLink]=\"['./']\" class=\"breadcrumb active\">Details</a>\n          </div>\n        </div>\n    </nav>\n\n    <div class=\"row\" style=\"padding: 0px 20px\">\n    <ul class=\"collapsible popout z-depth-5\" data-collapsible=\"accordion\">\n      <li>\n        <div class=\"collapsible-header light-green-text text-darken-4 active grey lighten-5\" style=\"font-size: 20px\"><i class=\"material-icons amber-text text-darken-4\" style=\"font-size: 30px\">looks_one</i>\n          STSportsSession</div>\n        <div class=\"collapsible-body\">\n  \n          <form >\n                    <div class=\"row\">\n                          \n\n                        <div class=\"input-field col s12 m6  l4 \">\n                          <input  id=\"studentId\" type=\"text\" class=\"validate\" [(ngModel)]=\"studentId\" name=\"studentId\">\n                          <label class=\"active\" for=\"studentId\">StudentId</label>\n                        </div> \n\n                        <div class=\"input-field col s12 m6  l4 \">\n                        <input  id=\"sportsId\" type=\"text\" class=\"validate\" [(ngModel)]=\"sportsId\" name=\"sportsId\">\n                        <label class=\"active\" for=\"sportsId\">SportsId</label>\n                       </div>\n\n                       <div class=\"input-field col s12 m6  l4 \">\n                        <input  id=\"sessionDate\" type=\"text\" class=\"validate\" [(ngModel)]=\"sessionDate\" name=\"sessionDate\">\n                         <label class=\"active\" for=\"sessionDate\">SessionDate</label>\n                        </div>\n\n                        <div class=\"input-field col s12 m6  l4 \">\n                          <input  id=\"sessionTime\" type=\"text\" class=\"validate\" [(ngModel)]=\"sessionTime\" name=\"sessionTime\">\n                          <label class=\"active\" for=\"sessionTime\">SessionTime</label>\n                        </div> \n\n                        <div class=\"input-field col s12 m6  l4 \">\n                        <input  id=\"videoURL\" type=\"text\" class=\"validate\" [(ngModel)]=\"videoURL\" name=\"videoURL\">\n                        <label class=\"active\" for=\"videoURL\">VideoURL</label>\n                       </div>\n\n                       <div class=\"input-field col s12 m6  l4 \">\n                        <input  id=\"description\" type=\"text\" class=\"validate\" [(ngModel)]=\"description\" name=\"description\">\n                         <label class=\"active\" for=\"description\">Description</label>\n                        </div>\n\n\n                        <div class=\"input-field col s12 m6  l4 \">\n                        <input  id=\"headerText\" type=\"text\" class=\"validate\" [(ngModel)]=\"headerText\" name=\"headerText\">\n                         <label class=\"active\" for=\"headerText\">HeaderText</label>\n                        </div>\n\n\n                        \n\n                             \n                         \n                       \n                    </div>\n                    <button class=\"btn waves-effect waves-light cyan\"  (click)=\"createReminder()\" name=\"action\">Save                       <i class=\"material-icons right\">add</i>\n                      </button> \n                      <div class=\"progress\" *ngIf=\"isLoading\">\n                          <div class=\"indeterminate\"></div>\n                      </div>\n                    </form>\n        </div>\n      </li>\n\n     \n    </ul>   \n  </div> \n  \n  </div>\n        "

/***/ }),

/***/ "./src/app/pages/admin/stsportssession/stsportssessiondetails/stsportssessiondetails.component.ts":
/*!********************************************************************************************************!*\
  !*** ./src/app/pages/admin/stsportssession/stsportssessiondetails/stsportssessiondetails.component.ts ***!
  \********************************************************************************************************/
/*! exports provided: STSportsSessiondetailsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "STSportsSessiondetailsComponent", function() { return STSportsSessiondetailsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _angular_Http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/Http */ "./node_modules/@angular/Http/esm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs/_esm5/add/operator/map.js");





var STSportsSessiondetailsComponent = /** @class */ (function () {
    function STSportsSessiondetailsComponent(_router, _http, route) {
        this._http = _http;
        this.route = route;
        this.isLoading = false;
        this.router = _router;
    }
    STSportsSessiondetailsComponent.prototype.createReminder = function () {
        var _this = this;
        this.isLoading = true;
        var data = {
            "studentId": this.studentId,
            "sportsId": this.sportsId,
            "sessionDate": this.sessionDate,
            "sessionTime": this.sessionTime,
            "videoURL": this.videoURL,
            "description": this.description,
            "headerText": this.headerText,
            "isActive": 'y',
            "isAprroved": 'y',
        };
        if (this.studentId == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>studentId is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.sportsId == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>sportsId is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.sessionDate == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>sessionDate is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.sessionTime == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>sessionTime is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.videoURL == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>videoURL is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.description == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>Description is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.headerText == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>headerText is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.editId && this.editId !== "" && this.editId !== "None") {
            data["id"] = this.editId;
            return this._http.put('Http://52.66.246.140:8080/SkillTeck/updateSTSportsSessions/', data)
                .subscribe(function (res) {
                console.log(res);
                _this.isLoading = false;
                var $toastContent = $('<span>Record has been saved successfully!!</span>');
                Materialize.toast($toastContent, 2000);
                _this.router.navigate(['/admin/stsportssession']);
            }, function (err) {
                var $toastContent = $('<span>' + JSON.parse(err["_body"])[0]["errMessage"] + '</span>');
                Materialize.toast($toastContent, 2000);
                _this.isLoading = false;
            });
        }
        else {
            return this._http.post('Http://52.66.246.140:8080/SkillTeck/addSTSportsSessions/', data)
                .subscribe(function (res) {
                console.log(res);
                _this.isLoading = false;
                var $toastContent = $('<span>Record has been saved successfully!!</span>');
                Materialize.toast($toastContent, 2000);
                _this.router.navigate(['/admin/stsportssession']);
            }, function (err) {
                var $toastContent = $('<span>' + JSON.parse(err["_body"])[0]["errMessage"] + '</span>');
                Materialize.toast($toastContent, 2000);
                _this.isLoading = false;
            });
        }
    };
    STSportsSessiondetailsComponent.prototype.moveNext = function (event, tab) {
        $('.collapsible').collapsible('open', tab);
    };
    STSportsSessiondetailsComponent.prototype.ngAfterViewInit = function () {
        this.things.changes.subscribe(function (t) {
            $("select").material_select();
        });
    };
    STSportsSessiondetailsComponent.prototype.ngAfterViewChecked = function () {
        Materialize.updateTextFields();
    };
    STSportsSessiondetailsComponent.prototype.ngOnInit = function () {
        var _this = this;
        $("select").material_select();
        $('.collapsible').collapsible({
            onOpen: function (el) { Materialize.updateTextFields(); }
        });
        this.route
            .queryParamMap
            .map(function (params) { return params.get('session_id') || 'None'; })
            .subscribe(function (val) { return _this.editId = val; });
        console.log(this.editId);
        if (this.editId && this.editId !== "" && this.editId !== "None") {
            this.isLoading = true;
            return this._http.get('Http://52.66.246.140:8080/SkillTeck/getSTSportsSessionsById/' + this.editId)
                .map(function (res) { return res.json(); })
                .subscribe(function (data) {
                var record = data[0];
                _this.studentId = record["studentId"];
                _this.sportsId = record["sportsId"];
                _this.sessionDate = record["sessionDate"];
                _this.sessionTime = record["sessionTime"];
                _this.videoURL = record["videoURL"];
                _this.description = record["description"];
                _this.headerText = record["headerText"];
                $("select").material_select();
                Materialize.updateTextFields();
                _this.isLoading = false;
                //debugger;
            }, function (err) {
                console.log('Something went wrong!');
                _this.isLoading = false;
            });
        }
        Materialize.updateTextFields();
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChildren"])('allTheseThings'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], STSportsSessiondetailsComponent.prototype, "things", void 0);
    STSportsSessiondetailsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-stsportssessiondetails',
            template: __webpack_require__(/*! ./stsportssessiondetails.component.html */ "./src/app/pages/admin/stsportssession/stsportssessiondetails/stsportssessiondetails.component.html"),
            styles: [__webpack_require__(/*! ./stsportssessiondetails.component.css */ "./src/app/pages/admin/stsportssession/stsportssessiondetails/stsportssessiondetails.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _angular_Http__WEBPACK_IMPORTED_MODULE_2__["Http"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]])
    ], STSportsSessiondetailsComponent);
    return STSportsSessiondetailsComponent;
}());



/***/ }),

/***/ "./src/app/pages/admin/stsportssessionstrail/stsportsSessionstrail.component.css":
/*!***************************************************************************************!*\
  !*** ./src/app/pages/admin/stsportssessionstrail/stsportsSessionstrail.component.css ***!
  \***************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2FkbWluL3N0c3BvcnRzc2Vzc2lvbnN0cmFpbC9zdHNwb3J0c1Nlc3Npb25zdHJhaWwuY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/pages/admin/stsportssessionstrail/stsportssessionstrail.component.html":
/*!****************************************************************************************!*\
  !*** ./src/app/pages/admin/stsportssessionstrail/stsportssessionstrail.component.html ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">  \n    <nav class=\"z-depth-0\">\n        <div class=\"nav-wrapper white \">\n          <div class=\"col s5 m9 l9\">\n              <a [routerLink]=\"['../']\" class=\"breadcrumb grey-text\">Dashboard</a>\n               <a [routerLink]=\"['./']\" class=\"breadcrumb active\">STSportsSessionsTrail</a>\n          </div>    \n              \n                      \n          <div class=\"col s2 m2 l1\">          \n              <a class=\"waves-effect cyan  btn-large\" style=\"    height: 42px;\n              line-height: 43px;\n              padding: 0px 20px;\"\n              [routerLink]=\"['./stsportssessionstraildetails']\"\n              href=\"!#\" ><i class=\"large material-icons\" style=\"font-size: 2rem; height: 42px;\n              line-height: 43px;\">add</i></a>\n          </div>\n        </div>\n    </nav>\n    <div  style=\"padding:5px\">\n        <div style=\"padding: 0px 10px\">\n            \n                  <table class=\"highlight bordered  \" style=\"border: 1px solid #ddd\">\n                    <thead class=\" blue lighten-5\">\n          <tr>\n              <th>ID </th>\n              <th>StudentId</th>\n              <th>SportsId</th>\n              <th>SessionDate</th>\n              <th>sessionTime</th>\n             <!--\n              <th>videoURL</th>\n              <th>Description</th>\n              <th>MasterSessionId</th>\n              <th>HeaderText</th>\n            -->\n              <th>Action</th><th></th>\n                                                 \n             \n\n          </tr>\n        </thead>\n      \n        <tbody>\n          <tr *ngFor=\"let record of records;\">\n             <td>{{record.id}}</td>\n            <td>{{record.studentId}}</td>\n            <td>{{record.sportsId}}</td>         \n            <td>{{record.sessionDate}}</td>\n            <td>{{record.sessionTime}}</td>\n            <!--\n            <td>{{record.videoURL}}</td>\n            <td>{{record.description}}</td>\n            <td>{{record.masterSessionId}}</td>\n            <td>{{record.headerText}}</td> -->\n            \n            \n              \n            \n          <!--   <td>{{record.isActive}}</td> -->\n            \n\n              \n            <td>              \n              <a class=\"btn-floating waves-effect waves-light blue darken-3\" (click)=\"edit(record.id)\" ><i class=\"material-icons\">edit</i></a>\n              <a class=\"btn-floating waves-effect waves-light red darken-2 modal-trigger\" (click)=\"selectForDelete(record.id)\" href=\"#modal1\"><i class=\"material-icons\">delete</i></a>\n            </td><td></td>\n          </tr>\n        </tbody>\n      </table>\n      <div class=\"progress\" *ngIf=\"isLoading\">\n          <div class=\"indeterminate\"></div>\n      </div>\n\n      <my-pagination\n        (goPage)=\"goToPage($event)\"\n        (goNext)=\"onNext()\"\n        (goPrev)=\"onPrev()\"\n        [pagesToShow]=\"10\"\n        [page]=\"page\"\n        [perPage]=\"limit\"\n        [count]=\"total\">\n    </my-pagination>   \n      </div>\n     \n  </div> \n  <div id=\"modal12\" class=\"modal\">\n      <div class=\"modal-content\">\n        <h4>Upload the Data</h4>\n        <p>Please Choose the File.</p> <p><input type=\"file\" name=\"file\"   #fileInput (change)=\"onFileSelect($event)\" /></p>\n     <!--  </div>\n      <div class=\"modal-footer\"> -->\n       <a [routerLink]=\"['./']\" (click)=\"uploadExcelSheet()\" class=\"modal-action modal-close waves-effect waves-green btn blue\">Upload</a>  \n </div> <div class=\"modal-content\">\n        <h4>Download the Data</h4>\n       <a [routerLink]=\"['./']\" (click)=\"downloadexcelfile()\" class=\"modal-action modal-close waves-effect waves-green btn red\">Download</a>\n       <p>Total Records: {{totalEmployees}}</p>  \n      </div>\n    </div>\n\n    <div id=\"modal1\" class=\"modal\">\n      <div class=\"modal-content\">\n        <h4>Delete?</h4>\n        <p>Are you sure, you want to delete this record?</p>\n      </div>\n      <div class=\"modal-footer\">\n        <a [routerLink]=\"['./']\" (click)=\"delete()\" class=\"modal-action modal-close waves-effect waves-green btn red\">Delete</a>\n      </div>\n    </div>\n</div>\n        "

/***/ }),

/***/ "./src/app/pages/admin/stsportssessionstrail/stsportssessionstrail.component.ts":
/*!**************************************************************************************!*\
  !*** ./src/app/pages/admin/stsportssessionstrail/stsportssessionstrail.component.ts ***!
  \**************************************************************************************/
/*! exports provided: STSportsSessionsTrailComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "STSportsSessionsTrailComponent", function() { return STSportsSessionsTrailComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _angular_Http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/Http */ "./node_modules/@angular/Http/esm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs/_esm5/add/operator/map.js");





var STSportsSessionsTrailComponent = /** @class */ (function () {
    function STSportsSessionsTrailComponent(_router, _http) {
        this._http = _http;
        this.records = [];
        this.isLoading = false;
        this.total = 0;
        this.page = 1;
        this.limit = 10;
        this.router = _router;
        this.loadIntialListOfEmplyees();
        this.countEmployeeRecords();
    }
    STSportsSessionsTrailComponent.prototype.goToPage = function (n) {
        this.page = n;
        this.loadIntialListOfEmplyees();
    };
    STSportsSessionsTrailComponent.prototype.onNext = function () {
        this.page++;
        this.loadIntialListOfEmplyees();
    };
    STSportsSessionsTrailComponent.prototype.onPrev = function () {
        this.page--;
        this.loadIntialListOfEmplyees();
    };
    STSportsSessionsTrailComponent.prototype.loadIntialListOfEmplyees = function () {
        var _this = this;
        this.isLoading = true;
        return this._http.get('Http://52.66.246.140:8080/SkillTeck/listSTSportsSessionsTrails?page=' + this.page + '&size=' + this.limit)
            .map(function (res) { return res.json(); })
            .subscribe(function (data) {
            _this.records = data.stsportsSessionsTrailList;
            _this.total = data.totalRecords;
            console.log(_this.records);
            _this.isLoading = false;
        }, function (err) {
            console.log('Something went wrong!');
            _this.isLoading = false;
        });
    };
    STSportsSessionsTrailComponent.prototype.edit = function (id) {
        var navigationExtras = {
            queryParams: { 'session_id': id },
            skipLocationChange: true
        };
        this.router.navigate(['/admin/stsportssessionstrail/stsportssessionstraildetails'], navigationExtras);
    };
    STSportsSessionsTrailComponent.prototype.selectForDelete = function (id) {
        this.deleteId = id;
    };
    STSportsSessionsTrailComponent.prototype.delete = function () {
        var _this = this;
        this.isLoading = true;
        return this._http.delete('Http://52.66.246.140:8080/SkillTeck/deleteSTSportsSessionsTrail/' + this.deleteId)
            .subscribe(function (data) {
            var $toastContent = $('<span>Record has been deleted successfully!!</span>');
            Materialize.toast($toastContent, 2000);
            _this.isLoading = false;
            _this.loadIntialListOfEmplyees();
        }, function (err) {
            console.log('Something went wrong!');
            _this.isLoading = false;
        });
    };
    STSportsSessionsTrailComponent.prototype.moveNext = function (event, tab) {
        $('.collapsible').collapsible('open', tab);
    };
    STSportsSessionsTrailComponent.prototype.ngOnInit = function () {
        $("select").material_select();
        $('.collapsible').collapsible();
        $('.modal').modal();
    };
    STSportsSessionsTrailComponent.prototype.ngAfterViewChecked = function () {
        var self = this;
    };
    STSportsSessionsTrailComponent.prototype.uploadExcelSheet = function () {
    };
    STSportsSessionsTrailComponent.prototype.downloadexcel = function () {
    };
    STSportsSessionsTrailComponent.prototype.downloadexcelfile = function () {
        var url = 'Http://34.93.202.192:8080/SpoorsReports/getAllEmployeesToPrintXL';
        this.downloadXLFile(url).subscribe(function (res) {
            var fileURL = URL.createObjectURL(res);
            window.open(fileURL);
        });
    };
    STSportsSessionsTrailComponent.prototype.downloadXLFile = function (url) {
        return this._http.get(url, { responseType: _angular_Http__WEBPACK_IMPORTED_MODULE_2__["ResponseContentType"].Blob }).map(function (res) {
            return new Blob([res.blob()], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        });
    };
    STSportsSessionsTrailComponent.prototype.downloadpdf = function () {
        var url = 'Http://34.93.202.192:8080/SpoorsReports/getAllEmployeesToPrint';
        this.downloadFile(url).subscribe(function (res) {
            var fileURL = URL.createObjectURL(res);
            window.open(fileURL);
        });
    };
    STSportsSessionsTrailComponent.prototype.downloadFile = function (url) {
        return this._http.get(url, { responseType: _angular_Http__WEBPACK_IMPORTED_MODULE_2__["ResponseContentType"].Blob }).map(function (res) {
            return new Blob([res.blob()], { type: 'application/pdf' });
        });
    };
    STSportsSessionsTrailComponent.prototype.countEmployeeRecords = function () {
        var _this = this;
        this.isLoading = true;
        return this._http.get('Http://34.93.202.192:8080/Spoors/employeesCount')
            .map(function (res) { return res.json(); })
            .subscribe(function (data) {
            _this.totalEmployees = data.totalRecords;
            console.log('Count of Emplyees --- ' + _this.totalEmployees);
        }, function (err) {
            console.log('Something went wrong!');
        });
        this.isLoading = false;
    };
    STSportsSessionsTrailComponent.prototype.onFileSelect = function (event) {
        var _this = this;
        console.log('File Change Event !');
        if (event.target.files.length > 0) {
            var file = event.target.files[0];
            var formdata = new FormData();
            formdata.append('file', file);
            return this._http.post('Http://34.93.202.192:8080/SpoorsEmployees/importEmpData', formdata)
                .subscribe(function (res) {
                console.log(res);
                _this.isLoading = false;
                var $toastContent = $('<span>Record has been loaded successfully!!</span>');
                Materialize.toast($toastContent, 2000);
                _this.router.navigate(['/spoorsemployees']);
            }, function (err) {
                var $toastContent = $('<span>' + JSON.parse(err["_body"])[0]["errMessage"] + '</span>');
                Materialize.toast($toastContent, 2000);
                _this.isLoading = false;
            });
        }
    };
    STSportsSessionsTrailComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-stsportssessionstrail',
            template: __webpack_require__(/*! ./stsportssessionstrail.component.html */ "./src/app/pages/admin/stsportssessionstrail/stsportssessionstrail.component.html"),
            styles: [__webpack_require__(/*! ./stsportsSessionstrail.component.css */ "./src/app/pages/admin/stsportssessionstrail/stsportsSessionstrail.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _angular_Http__WEBPACK_IMPORTED_MODULE_2__["Http"]])
    ], STSportsSessionsTrailComponent);
    return STSportsSessionsTrailComponent;
}());



/***/ }),

/***/ "./src/app/pages/admin/stsportssessionstrail/stsportssessionstraildetails/stsportssessionstraildetails.component.css":
/*!***************************************************************************************************************************!*\
  !*** ./src/app/pages/admin/stsportssessionstrail/stsportssessionstraildetails/stsportssessionstraildetails.component.css ***!
  \***************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2FkbWluL3N0c3BvcnRzc2Vzc2lvbnN0cmFpbC9zdHNwb3J0c3Nlc3Npb25zdHJhaWxkZXRhaWxzL3N0c3BvcnRzc2Vzc2lvbnN0cmFpbGRldGFpbHMuY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/pages/admin/stsportssessionstrail/stsportssessionstraildetails/stsportssessionstraildetails.component.html":
/*!****************************************************************************************************************************!*\
  !*** ./src/app/pages/admin/stsportssessionstrail/stsportssessionstraildetails/stsportssessionstraildetails.component.html ***!
  \****************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">  \n    <nav>\n        <div class=\"nav-wrapper white grey-text text-darken-2\">\n          <div class=\"col s12 grey-text text-darken-2\">\n             <a [routerLink]=\"['../../']\" class=\"breadcrumb grey-text\">Dashboard</a>\n            <a [routerLink]=\"['../']\" class=\"breadcrumb grey-text\">STSportsSessionTrail</a>\n            <a [routerLink]=\"['./']\" class=\"breadcrumb active\">Details</a>\n          </div>\n        </div>\n    </nav>\n\n    <div class=\"row\" style=\"padding: 0px 20px\">\n    <ul class=\"collapsible popout z-depth-5\" data-collapsible=\"accordion\">\n      <li>\n        <div class=\"collapsible-header light-green-text text-darken-4 active grey lighten-5\" style=\"font-size: 20px\"><i class=\"material-icons amber-text text-darken-4\" style=\"font-size: 30px\">looks_one</i>\n          STSportsSessionTrail</div>\n        <div class=\"collapsible-body\">\n  \n          <form >\n                    <div class=\"row\">\n                      <div class=\"input-field col s12 m6  l4 \">\n                          <input  id=\"studentId\" type=\"text\" class=\"validate\" [(ngModel)]=\"studentId\" name=\"studentId\">\n                          <label class=\"active\" for=\"studentId\">StudentId</label>\n                        </div> \n\n                        <div class=\"input-field col s12 m6  l4 \">\n                        <input  id=\"sportsId\" type=\"text\" class=\"validate\" [(ngModel)]=\"sportsId\" name=\"sportsId\">\n                        <label class=\"active\" for=\"sportsId\">SportsId</label>\n                       </div>\n\n                       <div class=\"input-field col s12 m6  l4 \">\n                        <input  id=\"sessionDate\" type=\"text\" class=\"validate\" [(ngModel)]=\"sessionDate\" name=\"sessionDate\">\n                         <label class=\"active\" for=\"sessionDate\">SessionDate</label>\n                        </div>\n\n                        <div class=\"input-field col s12 m6  l4 \">\n                          <input  id=\"sessionTime\" type=\"text\" class=\"validate\" [(ngModel)]=\"sessionTime\" name=\"sessionTime\">\n                          <label class=\"active\" for=\"sessionTime\">SessionTime</label>\n                        </div> \n\n                        <div class=\"input-field col s12 m6  l4 \">\n                        <input  id=\"videoURL\" type=\"text\" class=\"validate\" [(ngModel)]=\"videoURL\" name=\"videoURL\">\n                        <label class=\"active\" for=\"videoURL\">VideoURL</label>\n                       </div>\n\n                       <div class=\"input-field col s12 m6  l4 \">\n                        <input  id=\"description\" type=\"text\" class=\"validate\" [(ngModel)]=\"description\" name=\"description\">\n                         <label class=\"active\" for=\"description\">Description</label>\n                        </div>\n\n                        <div class=\"input-field col s12 m6  l4 \">\n                        <input  id=\"masterSessionId\" type=\"text\" class=\"validate\" [(ngModel)]=\"masterSessionId\" name=\"masterSessionId\">\n                         <label class=\"active\" for=\"masterSessionId\">MasterSessionId</label>\n                        </div>\n\n\n                        <div class=\"input-field col s12 m6  l4 \">\n                        <input  id=\"headerText\" type=\"text\" class=\"validate\" [(ngModel)]=\"headerText\" name=\"headerText\">\n                         <label class=\"active\" for=\"headerText\">HeaderText</label>\n                        </div> \n\n  \n                        \n\n                        \n                         \n                       \n                    </div>\n                    <button class=\"btn waves-effect waves-light cyan\"  (click)=\"createReminder()\" name=\"action\">Save                       <i class=\"material-icons right\">add</i>\n                      </button> \n                      <div class=\"progress\" *ngIf=\"isLoading\">\n                          <div class=\"indeterminate\"></div>\n                      </div>\n                    </form>\n        </div>\n      </li>\n\n     \n    </ul>   \n  </div> \n  \n  </div>\n        "

/***/ }),

/***/ "./src/app/pages/admin/stsportssessionstrail/stsportssessionstraildetails/stsportssessionstraildetails.component.ts":
/*!**************************************************************************************************************************!*\
  !*** ./src/app/pages/admin/stsportssessionstrail/stsportssessionstraildetails/stsportssessionstraildetails.component.ts ***!
  \**************************************************************************************************************************/
/*! exports provided: STSportsSessionsTraildetailsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "STSportsSessionsTraildetailsComponent", function() { return STSportsSessionsTraildetailsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _angular_Http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/Http */ "./node_modules/@angular/Http/esm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs/_esm5/add/operator/map.js");





var STSportsSessionsTraildetailsComponent = /** @class */ (function () {
    function STSportsSessionsTraildetailsComponent(_router, _http, route) {
        this._http = _http;
        this.route = route;
        this.isLoading = false;
        this.router = _router;
    }
    STSportsSessionsTraildetailsComponent.prototype.createReminder = function () {
        var _this = this;
        this.isLoading = true;
        var data = {
            "studentId": this.studentId,
            "sportsId": this.sportsId,
            "sessionDate": this.sessionDate,
            "sessionTime": this.sessionTime,
            "videoURL": this.videoURL,
            "description": this.description,
            "masterSessionId": this.masterSessionId,
            "headerText": this.headerText,
            "isActive": 'y',
            "isAprroved": 'y'
        };
        if (this.studentId == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>studentId is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.sportsId == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>sportsId is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.sessionDate == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>sessionDate is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.sessionTime == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>sessionTime is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.videoURL == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>videoURL is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.description == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>Description is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.masterSessionId == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>masterSessionId is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.headerText == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>headerText is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.editId && this.editId !== "" && this.editId !== "None") {
            data["id"] = this.editId;
            return this._http.put('Http://52.66.246.140:8080/SkillTeck/updateSTSportsSessionsTrail/', data)
                .subscribe(function (res) {
                console.log(res);
                _this.isLoading = false;
                var $toastContent = $('<span>Record has been saved successfully!!</span>');
                Materialize.toast($toastContent, 2000);
                _this.router.navigate(['/admin/stsportssessionstrail']);
            }, function (err) {
                var $toastContent = $('<span>' + JSON.parse(err["_body"])[0]["errMessage"] + '</span>');
                Materialize.toast($toastContent, 2000);
                _this.isLoading = false;
            });
        }
        else {
            return this._http.post('Http://52.66.246.140:8080/SkillTeck/addSTSportsSessionsTrail/', data)
                .subscribe(function (res) {
                console.log(res);
                _this.isLoading = false;
                var $toastContent = $('<span>Record has been saved successfully!!</span>');
                Materialize.toast($toastContent, 2000);
                _this.router.navigate(['/admin/stsportssessionstrail']);
            }, function (err) {
                var $toastContent = $('<span>' + JSON.parse(err["_body"])[0]["errMessage"] + '</span>');
                Materialize.toast($toastContent, 2000);
                _this.isLoading = false;
            });
        }
    };
    STSportsSessionsTraildetailsComponent.prototype.moveNext = function (event, tab) {
        $('.collapsible').collapsible('open', tab);
    };
    STSportsSessionsTraildetailsComponent.prototype.ngAfterViewInit = function () {
        this.things.changes.subscribe(function (t) {
            $("select").material_select();
        });
    };
    STSportsSessionsTraildetailsComponent.prototype.ngAfterViewChecked = function () {
        Materialize.updateTextFields();
    };
    STSportsSessionsTraildetailsComponent.prototype.ngOnInit = function () {
        var _this = this;
        $("select").material_select();
        $('.collapsible').collapsible({
            onOpen: function (el) { Materialize.updateTextFields(); }
        });
        this.route
            .queryParamMap
            .map(function (params) { return params.get('session_id') || 'None'; })
            .subscribe(function (val) { return _this.editId = val; });
        console.log(this.editId);
        if (this.editId && this.editId !== "" && this.editId !== "None") {
            this.isLoading = true;
            return this._http.get('Http://52.66.246.140:8080/SkillTeck/getSTSportsSessionsTrailById/' + this.editId)
                .map(function (res) { return res.json(); })
                .subscribe(function (data) {
                var record = data[0];
                _this.studentId = record["studentId"];
                _this.sportsId = record["sportsId"];
                _this.sessionDate = record["sessionDate"];
                _this.sessionTime = record["sessionTime"];
                _this.videoURL = record["videoURL"];
                _this.description = record["description"];
                _this.masterSessionId = record["masterSessionId"];
                _this.headerText = record["headerText"];
                $("select").material_select();
                Materialize.updateTextFields();
                _this.isLoading = false;
                //debugger;
            }, function (err) {
                console.log('Something went wrong!');
                _this.isLoading = false;
            });
        }
        Materialize.updateTextFields();
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChildren"])('allTheseThings'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], STSportsSessionsTraildetailsComponent.prototype, "things", void 0);
    STSportsSessionsTraildetailsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-stsportssessionstraildetails',
            template: __webpack_require__(/*! ./stsportssessionstraildetails.component.html */ "./src/app/pages/admin/stsportssessionstrail/stsportssessionstraildetails/stsportssessionstraildetails.component.html"),
            styles: [__webpack_require__(/*! ./stsportssessionstraildetails.component.css */ "./src/app/pages/admin/stsportssessionstrail/stsportssessionstraildetails/stsportssessionstraildetails.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _angular_Http__WEBPACK_IMPORTED_MODULE_2__["Http"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]])
    ], STSportsSessionsTraildetailsComponent);
    return STSportsSessionsTraildetailsComponent;
}());



/***/ }),

/***/ "./src/app/pages/admin/sttrainerstatus/sttrainerstatus.component.css":
/*!***************************************************************************!*\
  !*** ./src/app/pages/admin/sttrainerstatus/sttrainerstatus.component.css ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2FkbWluL3N0dHJhaW5lcnN0YXR1cy9zdHRyYWluZXJzdGF0dXMuY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/pages/admin/sttrainerstatus/sttrainerstatus.component.html":
/*!****************************************************************************!*\
  !*** ./src/app/pages/admin/sttrainerstatus/sttrainerstatus.component.html ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">  \n    <nav class=\"z-depth-0\">\n        <div class=\"nav-wrapper white \">\n          <div class=\"col s5 m9 l9\">\n              <a [routerLink]=\"['../']\" class=\"breadcrumb grey-text\">Dashboard</a>\n               <a [routerLink]=\"['./']\" class=\"breadcrumb active\">STTrainerStatus</a>\n          </div>    \n              \n                      \n          <div class=\"col s2 m2 l1\">          \n              <a class=\"waves-effect cyan  btn-large\" style=\"    height: 42px;\n              line-height: 43px;\n              padding: 0px 20px;\"\n              [routerLink]=\"['./sttrainerstatusdetails']\"\n              href=\"!#\" ><i class=\"large material-icons\" style=\"font-size: 2rem; height: 42px;\n              line-height: 43px;\">add</i></a>\n          </div>\n        </div>\n    </nav>\n    <div  style=\"padding:5px\">\n        <div style=\"padding: 0px 10px\">\n            \n                  <table class=\"highlight bordered  \" style=\"border: 1px solid #ddd\">\n                    <thead class=\" blue lighten-5\">\n          <tr>\n              <th>ID </th>\n              <th>Status</th>\n              <th>Description</th>\n              <th>MasterSessionId</th>\n              <th>HeaderText</th>\n              <th>Action</th><th></th>\n                                                 \n             \n\n          </tr>\n        </thead>\n      \n        <tbody>\n          <tr *ngFor=\"let record of records;\">\n            <td>{{record.id}}</td>\n            <td>{{record.status}}</td>         \n            <td>{{record.description}}</td>\n            <td>{{record.masterSessionId}}</td>\n            <td>{{record.headerText}}</td>\n            \n            \n              \n            \n          <!--   <td>{{record.isActive}}</td> -->\n            \n\n              \n            <td>              \n              <a class=\"btn-floating waves-effect waves-light blue darken-3\" (click)=\"edit(record.id)\" ><i class=\"material-icons\">edit</i></a>\n              <a class=\"btn-floating waves-effect waves-light red darken-2 modal-trigger\" (click)=\"selectForDelete(record.id)\" href=\"#modal1\"><i class=\"material-icons\">delete</i></a>\n            </td><td></td>\n          </tr>\n        </tbody>\n      </table>\n      <div class=\"progress\" *ngIf=\"isLoading\">\n          <div class=\"indeterminate\"></div>\n      </div>\n\n      <my-pagination\n        (goPage)=\"goToPage($event)\"\n        (goNext)=\"onNext()\"\n        (goPrev)=\"onPrev()\"\n        [pagesToShow]=\"10\"\n        [page]=\"page\"\n        [perPage]=\"limit\"\n        [count]=\"total\">\n    </my-pagination>   \n      </div>\n     \n  </div> \n  <div id=\"modal12\" class=\"modal\">\n      <div class=\"modal-content\">\n        <h4>Upload the Data</h4>\n        <p>Please Choose the File.</p> <p><input type=\"file\" name=\"file\"   #fileInput (change)=\"onFileSelect($event)\" /></p>\n     <!--  </div>\n      <div class=\"modal-footer\"> -->\n       <a [routerLink]=\"['./']\" (click)=\"uploadExcelSheet()\" class=\"modal-action modal-close waves-effect waves-green btn blue\">Upload</a>  \n </div> <div class=\"modal-content\">\n        <h4>Download the Data</h4>\n       <a [routerLink]=\"['./']\" (click)=\"downloadexcelfile()\" class=\"modal-action modal-close waves-effect waves-green btn red\">Download</a>\n       <p>Total Records: {{totalEmployees}}</p>  \n      </div>\n    </div>\n\n    <div id=\"modal1\" class=\"modal\">\n      <div class=\"modal-content\">\n        <h4>Delete?</h4>\n        <p>Are you sure, you want to delete this record?</p>\n      </div>\n      <div class=\"modal-footer\">\n        <a [routerLink]=\"['./']\" (click)=\"delete()\" class=\"modal-action modal-close waves-effect waves-green btn red\">Delete</a>\n      </div>\n    </div>\n</div>\n        "

/***/ }),

/***/ "./src/app/pages/admin/sttrainerstatus/sttrainerstatus.component.ts":
/*!**************************************************************************!*\
  !*** ./src/app/pages/admin/sttrainerstatus/sttrainerstatus.component.ts ***!
  \**************************************************************************/
/*! exports provided: STTrainerStatusComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "STTrainerStatusComponent", function() { return STTrainerStatusComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _angular_Http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/Http */ "./node_modules/@angular/Http/esm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs/_esm5/add/operator/map.js");





var STTrainerStatusComponent = /** @class */ (function () {
    function STTrainerStatusComponent(_router, _http) {
        this._http = _http;
        this.records = [];
        this.isLoading = false;
        this.total = 0;
        this.page = 1;
        this.limit = 10;
        this.router = _router;
        this.loadIntialListOfEmplyees();
        this.countEmployeeRecords();
    }
    STTrainerStatusComponent.prototype.goToPage = function (n) {
        this.page = n;
        this.loadIntialListOfEmplyees();
    };
    STTrainerStatusComponent.prototype.onNext = function () {
        this.page++;
        this.loadIntialListOfEmplyees();
    };
    STTrainerStatusComponent.prototype.onPrev = function () {
        this.page--;
        this.loadIntialListOfEmplyees();
    };
    STTrainerStatusComponent.prototype.loadIntialListOfEmplyees = function () {
        var _this = this;
        this.isLoading = true;
        return this._http.get('Http://52.66.246.140:8080/SkillTeck/listSTTrainerStatuss?page=' + this.page + '&size=' + this.limit)
            .map(function (res) { return res.json(); })
            .subscribe(function (data) {
            _this.records = data.sttrainerStatusList;
            _this.total = data.totalRecords;
            console.log(_this.records);
            _this.isLoading = false;
        }, function (err) {
            console.log('Something went wrong!');
            _this.isLoading = false;
        });
    };
    STTrainerStatusComponent.prototype.edit = function (id) {
        var navigationExtras = {
            queryParams: { 'session_id': id },
            skipLocationChange: true
        };
        this.router.navigate(['/admin/sttrainerstatus/sttrainerstatusdetails'], navigationExtras);
    };
    STTrainerStatusComponent.prototype.selectForDelete = function (id) {
        this.deleteId = id;
    };
    STTrainerStatusComponent.prototype.delete = function () {
        var _this = this;
        this.isLoading = true;
        return this._http.delete('Http://52.66.246.140:8080/SkillTeck/deleteSTTrainerStatus/' + this.deleteId)
            .subscribe(function (data) {
            var $toastContent = $('<span>Record has been deleted successfully!!</span>');
            Materialize.toast($toastContent, 2000);
            _this.isLoading = false;
            _this.loadIntialListOfEmplyees();
        }, function (err) {
            console.log('Something went wrong!');
            _this.isLoading = false;
        });
    };
    STTrainerStatusComponent.prototype.moveNext = function (event, tab) {
        $('.collapsible').collapsible('open', tab);
    };
    STTrainerStatusComponent.prototype.ngOnInit = function () {
        $("select").material_select();
        $('.collapsible').collapsible();
        $('.modal').modal();
    };
    STTrainerStatusComponent.prototype.ngAfterViewChecked = function () {
        var self = this;
    };
    STTrainerStatusComponent.prototype.uploadExcelSheet = function () {
    };
    STTrainerStatusComponent.prototype.downloadexcel = function () {
    };
    STTrainerStatusComponent.prototype.downloadexcelfile = function () {
        var url = 'Http://34.93.202.192:8080/SpoorsReports/getAllEmployeesToPrintXL';
        this.downloadXLFile(url).subscribe(function (res) {
            var fileURL = URL.createObjectURL(res);
            window.open(fileURL);
        });
    };
    STTrainerStatusComponent.prototype.downloadXLFile = function (url) {
        return this._http.get(url, { responseType: _angular_Http__WEBPACK_IMPORTED_MODULE_2__["ResponseContentType"].Blob }).map(function (res) {
            return new Blob([res.blob()], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        });
    };
    STTrainerStatusComponent.prototype.downloadpdf = function () {
        var url = 'Http://34.93.202.192:8080/SpoorsReports/getAllEmployeesToPrint';
        this.downloadFile(url).subscribe(function (res) {
            var fileURL = URL.createObjectURL(res);
            window.open(fileURL);
        });
    };
    STTrainerStatusComponent.prototype.downloadFile = function (url) {
        return this._http.get(url, { responseType: _angular_Http__WEBPACK_IMPORTED_MODULE_2__["ResponseContentType"].Blob }).map(function (res) {
            return new Blob([res.blob()], { type: 'application/pdf' });
        });
    };
    STTrainerStatusComponent.prototype.countEmployeeRecords = function () {
        var _this = this;
        this.isLoading = true;
        return this._http.get('Http://34.93.202.192:8080/Spoors/employeesCount')
            .map(function (res) { return res.json(); })
            .subscribe(function (data) {
            _this.totalEmployees = data.totalRecords;
            console.log('Count of Emplyees --- ' + _this.totalEmployees);
        }, function (err) {
            console.log('Something went wrong!');
        });
        this.isLoading = false;
    };
    STTrainerStatusComponent.prototype.onFileSelect = function (event) {
        var _this = this;
        console.log('File Change Event !');
        if (event.target.files.length > 0) {
            var file = event.target.files[0];
            var formdata = new FormData();
            formdata.append('file', file);
            return this._http.post('Http://34.93.202.192:8080/SpoorsEmployees/importEmpData', formdata)
                .subscribe(function (res) {
                console.log(res);
                _this.isLoading = false;
                var $toastContent = $('<span>Record has been loaded successfully!!</span>');
                Materialize.toast($toastContent, 2000);
                _this.router.navigate(['/spoorsemployees']);
            }, function (err) {
                var $toastContent = $('<span>' + JSON.parse(err["_body"])[0]["errMessage"] + '</span>');
                Materialize.toast($toastContent, 2000);
                _this.isLoading = false;
            });
        }
    };
    STTrainerStatusComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-sttrainerstatus',
            template: __webpack_require__(/*! ./sttrainerstatus.component.html */ "./src/app/pages/admin/sttrainerstatus/sttrainerstatus.component.html"),
            styles: [__webpack_require__(/*! ./sttrainerstatus.component.css */ "./src/app/pages/admin/sttrainerstatus/sttrainerstatus.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _angular_Http__WEBPACK_IMPORTED_MODULE_2__["Http"]])
    ], STTrainerStatusComponent);
    return STTrainerStatusComponent;
}());



/***/ }),

/***/ "./src/app/pages/admin/sttrainerstatus/sttrainerstatusdetails/sttrainerstatusdetails.component.css":
/*!*********************************************************************************************************!*\
  !*** ./src/app/pages/admin/sttrainerstatus/sttrainerstatusdetails/sttrainerstatusdetails.component.css ***!
  \*********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2FkbWluL3N0dHJhaW5lcnN0YXR1cy9zdHRyYWluZXJzdGF0dXNkZXRhaWxzL3N0dHJhaW5lcnN0YXR1c2RldGFpbHMuY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/pages/admin/sttrainerstatus/sttrainerstatusdetails/sttrainerstatusdetails.component.html":
/*!**********************************************************************************************************!*\
  !*** ./src/app/pages/admin/sttrainerstatus/sttrainerstatusdetails/sttrainerstatusdetails.component.html ***!
  \**********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">  \n    <nav>\n        <div class=\"nav-wrapper white grey-text text-darken-2\">\n          <div class=\"col s12 grey-text text-darken-2\">\n             <a [routerLink]=\"['../../']\" class=\"breadcrumb grey-text\">Dashboard</a>\n            <a [routerLink]=\"['../']\" class=\"breadcrumb grey-text\">STTrainerStatus</a>\n            <a [routerLink]=\"['./']\" class=\"breadcrumb active\">Details</a>\n          </div>\n        </div>\n    </nav>\n\n    <div class=\"row\" style=\"padding: 0px 20px\">\n    <ul class=\"collapsible popout z-depth-5\" data-collapsible=\"accordion\">\n      <li>\n        <div class=\"collapsible-header light-green-text text-darken-4 active grey lighten-5\" style=\"font-size: 20px\"><i class=\"material-icons amber-text text-darken-4\" style=\"font-size: 30px\">looks_one</i>\n          STTrainerStatus</div>\n        <div class=\"collapsible-body\">\n  \n          <form >\n                    <div class=\"row\">\n                      <div class=\"input-field col s12 m6  l4 \">\n                        <input  id=\"status\" type=\"text\" class=\"validate\" [(ngModel)]=\"status\" name=\"status\">\n                        <label class=\"active\" for=\"status\">Status</label>\n                      </div>\n\n                      <div class=\"input-field col s12 m6  l4 \">\n                        <input  id=\"description\" type=\"text\" class=\"validate\" [(ngModel)]=\"description\" name=\"description\">\n                         <label class=\"active\" for=\"description\">Description</label>\n                        </div>    \n\n                        <div class=\"input-field col s12 m6  l4 \">\n                          <input  id=\"masterSessionId\" type=\"text\" class=\"validate\" [(ngModel)]=\"masterSessionId\" name=\"masterSessionId\">\n                          <label class=\"active\" for=\"masterSessionId\">MasterSessionId</label>\n                        </div> \n\n                        <div class=\"input-field col s12 m6  l4 \">\n                          <input  id=\"headerText\" type=\"text\" class=\"validate\" [(ngModel)]=\"headerText\" name=\"headerText\">\n                          <label class=\"active\" for=\"headerText\">HeaderText</label>\n                        </div> \n\n\n  \n                        \n\n                        \n                         \n                       \n                    </div>\n                    <button class=\"btn waves-effect waves-light cyan\"  (click)=\"createReminder()\" name=\"action\">Save                       <i class=\"material-icons right\">add</i>\n                      </button> \n                      <div class=\"progress\" *ngIf=\"isLoading\">\n                          <div class=\"indeterminate\"></div>\n                      </div>\n                    </form>\n        </div>\n      </li>\n\n     \n    </ul>   \n  </div> \n  \n  </div>\n        "

/***/ }),

/***/ "./src/app/pages/admin/sttrainerstatus/sttrainerstatusdetails/sttrainerstatusdetails.component.ts":
/*!********************************************************************************************************!*\
  !*** ./src/app/pages/admin/sttrainerstatus/sttrainerstatusdetails/sttrainerstatusdetails.component.ts ***!
  \********************************************************************************************************/
/*! exports provided: STTrainerStatusdetailsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "STTrainerStatusdetailsComponent", function() { return STTrainerStatusdetailsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _angular_Http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/Http */ "./node_modules/@angular/Http/esm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs/_esm5/add/operator/map.js");





var STTrainerStatusdetailsComponent = /** @class */ (function () {
    function STTrainerStatusdetailsComponent(_router, _http, route) {
        this._http = _http;
        this.route = route;
        this.isLoading = false;
        this.router = _router;
    }
    STTrainerStatusdetailsComponent.prototype.createReminder = function () {
        var _this = this;
        this.isLoading = true;
        var data = {
            "status": this.status,
            "description": this.description,
            "masterSessionId": this.masterSessionId,
            "headerText": this.headerText,
            "isActive": 'y',
            "isAprroved": 'y'
        };
        if (this.status == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>status is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.description == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>Description is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.masterSessionId == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>masterSessionId is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.headerText == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>headerText is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.editId && this.editId !== "" && this.editId !== "None") {
            data["id"] = this.editId;
            return this._http.put('Http://52.66.246.140:8080/SkillTeck/updateSTTrainerStatus/', data)
                .subscribe(function (res) {
                console.log(res);
                _this.isLoading = false;
                var $toastContent = $('<span>Record has been saved successfully!!</span>');
                Materialize.toast($toastContent, 2000);
                _this.router.navigate(['/admin/sttrainerstatus']);
            }, function (err) {
                var $toastContent = $('<span>' + JSON.parse(err["_body"])[0]["errMessage"] + '</span>');
                Materialize.toast($toastContent, 2000);
                _this.isLoading = false;
            });
        }
        else {
            return this._http.post('Http://52.66.246.140:8080/SkillTeck/addSTTrainerStatus/', data)
                .subscribe(function (res) {
                console.log(res);
                _this.isLoading = false;
                var $toastContent = $('<span>Record has been saved successfully!!</span>');
                Materialize.toast($toastContent, 2000);
                _this.router.navigate(['/admin/sttrainerstatus']);
            }, function (err) {
                var $toastContent = $('<span>' + JSON.parse(err["_body"])[0]["errMessage"] + '</span>');
                Materialize.toast($toastContent, 2000);
                _this.isLoading = false;
            });
        }
    };
    STTrainerStatusdetailsComponent.prototype.moveNext = function (event, tab) {
        $('.collapsible').collapsible('open', tab);
    };
    STTrainerStatusdetailsComponent.prototype.ngAfterViewInit = function () {
        this.things.changes.subscribe(function (t) {
            $("select").material_select();
        });
    };
    STTrainerStatusdetailsComponent.prototype.ngAfterViewChecked = function () {
        Materialize.updateTextFields();
    };
    STTrainerStatusdetailsComponent.prototype.ngOnInit = function () {
        var _this = this;
        $("select").material_select();
        $('.collapsible').collapsible({
            onOpen: function (el) { Materialize.updateTextFields(); }
        });
        this.route
            .queryParamMap
            .map(function (params) { return params.get('session_id') || 'None'; })
            .subscribe(function (val) { return _this.editId = val; });
        console.log(this.editId);
        if (this.editId && this.editId !== "" && this.editId !== "None") {
            this.isLoading = true;
            return this._http.get('Http://52.66.246.140:8080/SkillTeck/getSTTrainerStatusById/' + this.editId)
                .map(function (res) { return res.json(); })
                .subscribe(function (data) {
                var record = data[0];
                _this.status = record["status"];
                _this.description = record["description"];
                _this.masterSessionId = record["masterSessionId"];
                _this.headerText = record["headerText"];
                $("select").material_select();
                Materialize.updateTextFields();
                _this.isLoading = false;
                //debugger;
            }, function (err) {
                console.log('Something went wrong!');
                _this.isLoading = false;
            });
        }
        Materialize.updateTextFields();
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChildren"])('allTheseThings'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], STTrainerStatusdetailsComponent.prototype, "things", void 0);
    STTrainerStatusdetailsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-sttrainerstatusdetails',
            template: __webpack_require__(/*! ./sttrainerstatusdetails.component.html */ "./src/app/pages/admin/sttrainerstatus/sttrainerstatusdetails/sttrainerstatusdetails.component.html"),
            styles: [__webpack_require__(/*! ./sttrainerstatusdetails.component.css */ "./src/app/pages/admin/sttrainerstatus/sttrainerstatusdetails/sttrainerstatusdetails.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _angular_Http__WEBPACK_IMPORTED_MODULE_2__["Http"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]])
    ], STTrainerStatusdetailsComponent);
    return STTrainerStatusdetailsComponent;
}());



/***/ }),

/***/ "./src/app/pages/dashboard/dashboard.component.css":
/*!*********************************************************!*\
  !*** ./src/app/pages/dashboard/dashboard.component.css ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".size {\r\n    font-size: 50px;\r\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvZGFzaGJvYXJkL2Rhc2hib2FyZC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksZ0JBQWdCO0NBQ25CIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvZGFzaGJvYXJkL2Rhc2hib2FyZC5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnNpemUge1xyXG4gICAgZm9udC1zaXplOiA1MHB4O1xyXG59Il19 */"

/***/ }),

/***/ "./src/app/pages/dashboard/dashboard.component.html":
/*!**********************************************************!*\
  !*** ./src/app/pages/dashboard/dashboard.component.html ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">  \n      <div class=\"col s12 m3\">\n      <div class=\"card pink accent-2\">\n        <div class=\"card-content white-text z-depth-5 info-tile\"> \n          <span class=\"card-title\"><b>Coaches</b></span>\n          <i class=\"material-icons size left\" style=\"margin-top: 10px;\">sports</i> \n\n          <!--  <p class=\"size\">{{totalEmployees}}</p>     stcoach/stcoachdetails   --> \n          <p class=\"size\">9000</p> \n\n            <a   [routerLink]=\"['../stcoach/stcoachdetails']\"   class=\"btn-floating halfway-fab waves-effect waves-light blue\"><i class=\"material-icons\">add</i></a>  \n        </div>       \n      </div>\n    </div>\n    <div class=\"col s12 m3\">\n        <div class=\"card blue accent-3\">\n          <div class=\"card-content white-text z-depth-5 info-tile\">\n            <span class=\"card-title\"><b>Students</b></span>\n            <i class=\"material-icons size left\" style=\"margin-top: 10px;\">sports_handball</i>\n            <!-- <p class=\"size\">{{totalStaffs}}</p> -->\n            <p class=\"size\">20000</p>\n            <a    [routerLink]=\"['../stuser/stuserdetails']\"   class=\"btn-floating halfway-fab waves-effect waves-light green\"><i class=\"material-icons\">add</i></a> \n          </div>       \n        </div>\n    </div> \n    <div class=\"col s12 m3\">\n        <div class=\"card teal darken-4\">\n          <div class=\"card-content white-text z-depth-5 info-tile\">\n            <span class=\"card-title\" ><b>Videos</b></span>\n            <i class=\"material-icons size left\" style=\"margin-top: 10px;\">ondemand_video</i>\n            <!-- <p class=\"size\">5</p> -->\n            <p class=\"size\">540000</p>\n\n            <a    class=\"btn-floating halfway-fab waves-effect waves-light purple\"><i class=\"material-icons\">add</i></a> \n\n          </div>       \n        </div>\n    </div> \n    <div class=\"col s12 m3\">\n        <div class=\"card purple darken-4\">\n          <div class=\"card-content white-text z-depth-5 info-tile\">\n            <span class=\"card-title\"><b>Tasks</b></span>\n            <i class=\"material-icons size left\" style=\"margin-top: 10px;\">sports_baseball</i><p class=\"size\">1000000</p>\n            <a    class=\"btn-floating halfway-fab waves-effect waves-light red\"><i class=\"material-icons\">add</i></a>\n          </div>       \n        </div>\n    </div>   \n    \n    <div class=\"col s12 m6\">\n        <div class=\"card medium white z-depth-5\">\n          <div class=\"card-content black-text\">\n            <span class=\"card-title\">Coaches</span>\n            <div>\n              <div style=\"display: block\">\n                <canvas baseChart\n                        [datasets]=\"barChartData1\"\n                        [labels]=\"barChartLabels1\"\n                         [colors]=\"barChartColors1\" \n                        [legend]=\"barChartLegend1\"\n                        [chartType]=\"barChartType1\"\n                        (chartHover)=\"chartHovered($event)\"\n                        (chartClick)=\"chartClicked($event)\"></canvas>\n              </div>\n            </div>\n          </div>       \n        </div>\n    </div> \n    <div class=\"col s12 m6\">\n        <div class=\"card medium white z-depth-5\">\n          <div class=\"card-content black-text\">\n            <span class=\"card-title\">Practice Completed</span>\n            <div>\n              <div style=\"display: block\">\n                 <canvas baseChart\n                        [datasets]=\"barChartData\"\n                        [labels]=\"barChartLabels\"\n                        [options]=\" {\n                          scales: {\n                              xAxes: [{\n                                  stacked: true,\n                                  gridLines: {\n                                    offsetGridLines: false\n                                }\n                              }],\n                              yAxes: [{\n                                  stacked: true,\n                                  gridLines: {\n                                    offsetGridLines: false\n                                }\n                              }]\n                          }                        \n                      }\"\n                        [legend]=\"barChartLegend\"\n                        [colors]=\"barChartColors2\"\n                        [chartType]=\"barChartType\"\n                        (chartHover)=\"chartHovered($event)\"\n                        (chartClick)=\"chartClicked($event)\"></canvas>  \n\n                       \n\n              </div>\n            </div>\n          </div>       \n        </div>\n    </div> \n    <div class=\"col s12 m6\">\n        <div class=\"card medium white z-depth-5\">\n          <div class=\"card-content black-text\">\n            <span class=\"card-title\">Videos</span>\n            <div style=\"display: block\">\n              <canvas baseChart\n                          [data]=\"doughnutChartData\"\n                          [labels]=\"doughnutChartLabels\"\n                          [chartType]=\"doughnutChartType\"\n                          (chartHover)=\"chartHovered($event)\"\n                          (chartClick)=\"chartClicked($event)\"></canvas>\n            </div>\n          </div>       \n        </div>\n    </div> \n    <div class=\"col s12 m6\">\n        <div class=\"card medium white z-depth-5\">\n          <div class=\"card-content black-text\">\n            <span class=\"card-title\">Sales Vs Revenue</span>\n            <div class=\"row\">\n              <div class=\"col-md-6\">\n                <div style=\"display: block;\">\n                <canvas baseChart \n                            [datasets]=\"lineChartData\"\n                            [labels]=\"lineChartLabels\"\n                            [options]=\"lineChartOptions\"\n                            [colors]=\"lineChartColors\"\n                            [legend]=\"lineChartLegend\"\n                            [chartType]=\"lineChartType\"\n                            (chartHover)=\"chartHovered($event)\"\n                            (chartClick)=\"chartClicked($event)\"></canvas>\n                </div>\n              </div>\n\n            </div>\n          </div>       \n        </div>\n    </div> \n \n</div>\n        "

/***/ }),

/***/ "./src/app/pages/dashboard/dashboard.component.ts":
/*!********************************************************!*\
  !*** ./src/app/pages/dashboard/dashboard.component.ts ***!
  \********************************************************/
/*! exports provided: DashboardComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DashboardComponent", function() { return DashboardComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _angular_Http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/Http */ "./node_modules/@angular/Http/esm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/esm5/router.js");




var DashboardComponent = /** @class */ (function () {
    //private isLoading: boolean;
    function DashboardComponent(_router, _http) {
        this._http = _http;
        this.isLoading = false;
        this.records = [];
        this.lineChartData = [
            { data: [40, 20, 58, 76, 56, 55, 40], label: 'Sales' },
            { data: [28, 48, 40, 19, 86, 27, 90], label: 'Revenue' }
        ];
        this.lineChartLabels = ['January', 'February', 'March', 'April', 'May', 'June', 'July'];
        this.lineChartOptions = {
            responsive: true
        };
        this.lineChartColors = [
            {
                backgroundColor: 'rgba(191,55,36,0.6)'
            },
            {
                backgroundColor: 'rgba(131,191,237,0.9)'
            }
        ];
        this.lineChartLegend = true;
        this.lineChartType = 'line';
        this.barChartOptions = {
            scaleShowVerticalLines: false,
            responsive: true
        };
        this.barChartLabels = ['31 Mar', '1 Apr', '2 Apr', '3 Apr', '4 Apr', '7 Apr', '8 Apr'];
        this.barChartType = 'bar';
        this.barChartLegend = true;
        this.barChartColors = [
            {
                backgroundColor: 'rgba(139,195,74,0.9)'
            },
            {
                backgroundColor: 'rgba(191,55,36,0.8)'
            }
        ];
        this.barChartData = [
            { data: [80, 92, 70, 81, 66, 78, 69], label: 'Completed' },
            { data: [20, 8, 30, 19, 34, 22, 31], label: 'In Progess' }
        ];
        this.barChartLabels1 = ['Rahul K', 'Sanjay T', 'Rajiv Menon', 'Ganesh A', 'SivShankar', 'John Doe', 'Clara K'];
        this.barChartType1 = 'horizontalBar';
        this.barChartLegend1 = false;
        this.barChartColors2 = [
            { backgroundColor: '#80d8ff' },
            { backgroundColor: '#01579b' }
        ];
        this.barChartData1 = [
            { data: [80, 92, 70, 81, 66, 78, 69], label: 'Hours (Completed)' },
        ];
        this.barChartColors1 = [
            { backgroundColor: '#4a148c' },
            { backgroundColor: '#1a237e' }
        ];
        this.doughnutChartLabels = ['Operation', 'Marketing', 'Database'];
        this.doughnutChartData = [23, 65, 12];
        this.doughnutChartType = 'doughnut';
        this.router = _router;
        // this.countStudentsRecords();
        // this.countStaffRecords();
        // this.countLibraryBooks();
    }
    DashboardComponent.prototype.countStudentsRecords = function () {
        var _this = this;
        this.isLoading = true;
        this.delay(5000);
        return this._http.get('Http://34.93.202.192:8080/Spoors/employeesCount')
            .map(function (res) { return res.json(); })
            .subscribe(function (data) {
            _this.totalEmployees = data.totalRecords;
            //console.log(this.records);
        }, function (err) {
            console.log('Something went wrong!');
        });
        this.isLoading = false;
    };
    DashboardComponent.prototype.countStaffRecords = function () {
        var _this = this;
        this.isLoading = true;
        this.delay(5000);
        return this._http.get('Http://musictrainer.smartx.services:8080/NoteTrainer/staffCount')
            .map(function (res) { return res.json(); })
            .subscribe(function (data) {
            _this.totalStaffs = data.totalRecords;
            console.log(_this.totalStaffs);
        }, function (err) {
            console.log('Something went wrong!');
        });
        this.isLoading = false;
    };
    DashboardComponent.prototype.countLibraryBooks = function () {
        var _this = this;
        this.isLoading = true;
        return this._http.get('Http://musictrainer.smartx.services:8080/NoteTrainer/booksCount')
            .map(function (res) { return res.json(); })
            .subscribe(function (data) {
            _this.totalBooks = data.totalRecords;
        }, function (err) {
            console.log('Something went wrong!');
        });
        this.isLoading = false;
    };
    DashboardComponent.prototype.ngOnInit = function () {
        //this.countStudentsRecords();
        //   this.countStaffRecords();
        //  this.countLibraryBooks();
    };
    // events
    DashboardComponent.prototype.chartClicked = function (e) {
        console.log(e);
    };
    DashboardComponent.prototype.chartHovered = function (e) {
        console.log(e);
    };
    DashboardComponent.prototype.delay = function (ms) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, new Promise(function (resolve) { return setTimeout(function () { return resolve(); }, ms); }).then(function () { return console.log("fired"); })];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    DashboardComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-dashboard',
            template: __webpack_require__(/*! ./dashboard.component.html */ "./src/app/pages/dashboard/dashboard.component.html"),
            styles: [__webpack_require__(/*! ./dashboard.component.css */ "./src/app/pages/dashboard/dashboard.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _angular_Http__WEBPACK_IMPORTED_MODULE_2__["Http"]])
    ], DashboardComponent);
    return DashboardComponent;
}());



/***/ }),

/***/ "./src/app/pages/staff/staff.component.css":
/*!*************************************************!*\
  !*** ./src/app/pages/staff/staff.component.css ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = " .circular--square {\r\n  border-radius: 50%;\r\n   width: 100px;\r\n  height: 100px;\r\n \r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvc3RhZmYvc3RhZmYuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQ0FBQztFQUNDLG1CQUFtQjtHQUNsQixhQUFhO0VBQ2QsY0FBYzs7Q0FFZiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3N0YWZmL3N0YWZmLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIgLmNpcmN1bGFyLS1zcXVhcmUge1xyXG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgd2lkdGg6IDEwMHB4O1xyXG4gIGhlaWdodDogMTAwcHg7XHJcbiBcclxufVxyXG4iXX0= */"

/***/ }),

/***/ "./src/app/pages/staff/staff.component.html":
/*!**************************************************!*\
  !*** ./src/app/pages/staff/staff.component.html ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">  \n  <nav class=\"z-depth-0\">\n      <div class=\"nav-wrapper white \">\n        <div class=\"col s8 m10 l11\">          \n          <a [routerLink]=\"['./']\" class=\"breadcrumb active\">Employees</a>\n        </div>    \n        <div class=\"col s2 m2 l1\">          \n            <a class=\"waves-effect  btn-large pink darken-4\" style=\"    height: 42px;\n            line-height: 43px;\n            padding: 0px 20px;\"\n            [routerLink]=\"['./details']\"\n            href=\"!#\" ><i class=\"large material-icons\" style=\"font-size: 2rem; height: 42px;\n            line-height: 43px;\">add</i></a>\n        </div>\n      </div>\n  </nav>\n\n    <div class=\"input-field col s12 m6  l2 \">\n    <label class=\"active\" for=\"categoryIdFilter\">Department</label>\n    <select id=\"depatFilter\">\n      <option value=\"1\">All</option>\n      <option value=\"2\">Opertaions</option>\n      <option value=\"3\">Business Analytics</option>\n      <option value=\"4\">Tariff Support</option>\n      <option value=\"5\">Marketing</option>\n      <option value=\"6\">Quality Analyst</option>\n      <option value=\"7\">Database</option>\n      <option value=\"8\">Lead</option>\n\n    </select>\n  </div>\n  <div  style=\"padding:5px\">\n      <div style=\"padding: 0px 10px\">\n          \n                <table class=\"highlight bordered \" style=\"border: 1px solid #ddd\">\n                   <thead class=\"deep-orange lighten-5\">\n        <tr>\n          <th> </th>\n            <th>Name</th>\n              <th>Qualification</th> \n            <th>DOJ</th>\n            <th>Phone</th>\n            <th>Extn.</th>\n            <th>Email</th>            \n            <th>Actions</th>\n        </tr>\n      </thead>\n    \n      <tbody>\n     <!--    <tr *ngFor=\"let record of records;\">   \n        <th><img  class=\"circular--square\" src=\"https://res.cloudinary.com/dvpdghjuk/image/upload/v1565863633/MMS/staffs/{{record.id}}.jpg\">\n </th>       \n          <td><h5>{{record.empName}} {{record.fatherName}}</h5></td>           \n           <td>{{record.qualification}}</td>  \n          <td>{{record.doj}}</td>\n          <td>{{record.phone}}</td>\n          <td>{{record.extn}}</td>   \n          <td>{{record.email}}</td>                       \n          <td>              \n            <a class=\"btn-floating waves-effect waves-light amber darken-4\" (click)=\"edit(record.id)\"><i class=\"material-icons\">edit</i></a>\n           <a class=\"btn-floating waves-effect waves-light red darken-4 modal-trigger\"  href=\"#modal1\"><i class=\"material-icons\">delete</i></a>\n              <a class=\"btn-floating waves-effect waves-light red darken-4 modal-trigger\"    (click)=\"selectForDelete(record.id)\"  href=\"#modal1\"><i class=\"material-icons\">delete</i></a>\n\n\n          </td>\n        </tr> -->\n\n   <tr>   \n        <th><img  class=\"circular--square\" src=\"https://res.cloudinary.com/dvpdghjuk/image/upload/v1565541577/STAFF/20.jpg\">\n </th>       \n          <td><h5>John Doe</h5></td>           \n           <td>MSc</td>  \n          <td>20Jan2019</td>\n          <td>41510011</td>\n          <td>1234</td>   \n          <td>john.doe@testmail.com</td>                       \n          <td>              \n            <a class=\"btn-floating waves-effect waves-light amber darken-4\"  ><i class=\"material-icons\">edit</i></a>\n           <a class=\"btn-floating waves-effect waves-light red darken-4 modal-trigger\"  href=\"#modal1\"><i class=\"material-icons\">delete</i></a>\n \n\n          </td>\n        </tr>  \n\n        <tr>   \n        <th><img  class=\"circular--square\" src=\"https://res.cloudinary.com/dvpdghjuk/image/upload/v1565541576/STAFF/10.jpg\">\n </th>       \n          <td><h5>Shivani Puja</h5></td>           \n           <td>BBA</td>  \n          <td>25Jan2016</td>\n          <td>41510011</td>\n          <td>1234</td>   \n          <td>shivani.puja@testmail.com</td>                       \n          <td>              \n            <a class=\"btn-floating waves-effect waves-light amber darken-4\"  ><i class=\"material-icons\">edit</i></a>\n           <a class=\"btn-floating waves-effect waves-light red darken-4 modal-trigger\"  href=\"#modal1\"><i class=\"material-icons\">delete</i></a>\n \n\n          </td>\n        </tr>  \n\n\n        <tr>   \n        <th><img  class=\"circular--square\" src=\"https://res.cloudinary.com/dvpdghjuk/image/upload/v1565541577/STAFF/15.jpg\">\n </th>       \n          <td><h5>Patricia S</h5></td>           \n           <td>MCA</td>  \n          <td>01May2017</td>\n          <td>41510021</td>\n          <td>1230</td>   \n          <td>patricia.s@testmail.com</td>                       \n          <td>              \n            <a class=\"btn-floating waves-effect waves-light amber darken-4\"  ><i class=\"material-icons\">edit</i></a>\n           <a class=\"btn-floating waves-effect waves-light red darken-4 modal-trigger\"  href=\"#modal1\"><i class=\"material-icons\">delete</i></a>\n \n\n          </td>\n        </tr>  \n\n\n        <tr>   \n        <th><img  class=\"circular--square\" src=\"https://res.cloudinary.com/dvpdghjuk/image/upload/v1565541576/STAFF/1.jpg\">\n </th>       \n          <td><h5>Sean Hugh</h5></td>           \n           <td>BCom</td>  \n          <td>18Dec2016</td>\n          <td>41510015</td>\n          <td>1233</td>   \n          <td>sean.h@testmail.com</td>                       \n          <td>              \n            <a class=\"btn-floating waves-effect waves-light amber darken-4\"  ><i class=\"material-icons\">edit</i></a>\n           <a class=\"btn-floating waves-effect waves-light red darken-4 modal-trigger\"  href=\"#modal1\"><i class=\"material-icons\">delete</i></a>\n \n\n          </td>\n        </tr>  \n\n\n\n      </tbody>\n    </table>\n     <div class=\"progress\" *ngIf=\"isLoading\">\n        <div class=\"indeterminate\"></div>\n      </div>\n    <!--  <my-pagination\n        (goPage)=\"goToPage($event)\"\n        (goNext)=\"onNext()\"\n        (goPrev)=\"onPrev()\"\n        [pagesToShow]=\"10\"\n        [page]=\"page\"\n        [perPage]=\"limit\"\n        [count]=\"total\">\n    </my-pagination>       -->\n    <ul class=\"pagination\">\n          <li class=\"disabled\"> <i class=\"material-icons\">chevron_left</i> </li>\n          <li class=\"active light-green\"> 1 </li>\n          <li class=\"waves-effect\"> 2 </li>\n          <li class=\"waves-effect\"> 3 </li>\n          <li class=\"waves-effect\"> <i class=\"material-icons\">chevron_right</i> </li>\n        </ul> \n    \n      </div>\n     \n  </div> \n<div id=\"modal1\" class=\"modal\">\n    <div class=\"modal-content\">\n      <h4>Delete?</h4>\n      <p>Are you sure, you want to delete this record?</p>\n    </div>\n    <div class=\"modal-footer\">\n      <a [routerLink]=\"['./']\" (click)=\"delete()\" class=\"modal-action modal-close waves-effect waves-green btn red\">Delete</a>\n    </div>\n  </div>\n</div>\n      "

/***/ }),

/***/ "./src/app/pages/staff/staff.component.ts":
/*!************************************************!*\
  !*** ./src/app/pages/staff/staff.component.ts ***!
  \************************************************/
/*! exports provided: StaffComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StaffComponent", function() { return StaffComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _angular_Http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/Http */ "./node_modules/@angular/Http/esm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs/_esm5/add/operator/map.js");





var StaffComponent = /** @class */ (function () {
    function StaffComponent(_router, _http) {
        this._http = _http;
        this.records = [];
        this.isLoading = false;
        this.staffs = [];
        this.loading = false;
        this.total = 0;
        this.page = 1;
        this.limit = 5;
        this.router = _router;
        // this.loadReminders();
    }
    StaffComponent.prototype.goToPage = function (n) {
        this.page = n;
        this.loadReminders();
    };
    StaffComponent.prototype.onNext = function () {
        this.page++;
        this.loadReminders();
    };
    StaffComponent.prototype.onPrev = function () {
        this.page--;
        this.loadReminders();
    };
    StaffComponent.prototype.loadReminders = function () {
        var _this = this;
        this.isLoading = true;
        return this._http.get('Http://musictrainer.smartx.services:8080/NoteTrainer/listSchoolEmployees?page=' + this.page + '&size=' + this.limit)
            .map(function (res) { return res.json(); })
            .subscribe(function (data) {
            _this.records = data.staffVOlist;
            _this.total = data.totalRecords;
            console.log(_this.records);
            _this.isLoading = false;
        }, function (err) {
            console.log('Something went wrong!');
            _this.isLoading = false;
        });
    };
    StaffComponent.prototype.edit = function (id) {
        var navigationExtras = {
            queryParams: { 'session_id': id },
            skipLocationChange: true
        };
        this.router.navigate(['staff/details'], navigationExtras);
    };
    StaffComponent.prototype.selectForDelete = function (id) {
        this.deleteId = id;
    };
    StaffComponent.prototype.delete = function () {
        var _this = this;
        this.isLoading = true;
        return this._http.delete('Http://musictrainer.smartx.services:8080/NoteTrainer/deleteSchoolEmployee/' + this.deleteId)
            .subscribe(function (data) {
            var $toastContent = $('<span>Record has been deleted successfully!!</span>');
            Materialize.toast($toastContent, 2000);
            _this.isLoading = false;
            _this.loadReminders();
        }, function (err) {
            console.log('Something went wrong!');
            _this.isLoading = false;
        });
    };
    StaffComponent.prototype.moveNext = function (event, tab) {
        $('.collapsible').collapsible('open', tab);
    };
    StaffComponent.prototype.ngOnInit = function () {
        $("select").material_select();
        $('.collapsible').collapsible();
        $('.modal').modal();
    };
    StaffComponent.prototype.ngAfterViewChecked = function () {
        var self = this;
    };
    StaffComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-staff',
            template: __webpack_require__(/*! ./staff.component.html */ "./src/app/pages/staff/staff.component.html"),
            styles: [__webpack_require__(/*! ./staff.component.css */ "./src/app/pages/staff/staff.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _angular_Http__WEBPACK_IMPORTED_MODULE_2__["Http"]])
    ], StaffComponent);
    return StaffComponent;
}());



/***/ }),

/***/ "./src/app/pages/staff/staffdetails/staffdetails.component.css":
/*!*********************************************************************!*\
  !*** ./src/app/pages/staff/staffdetails/staffdetails.component.css ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3N0YWZmL3N0YWZmZGV0YWlscy9zdGFmZmRldGFpbHMuY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/pages/staff/staffdetails/staffdetails.component.html":
/*!**********************************************************************!*\
  !*** ./src/app/pages/staff/staffdetails/staffdetails.component.html ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">\n  <nav>\n    <div class=\"nav-wrapper white grey-text text-darken-2\">\n      <div class=\"col s12 grey-text text-darken-2\">\n        <a [routerLink]=\"['../']\" class=\"breadcrumb grey-text\">Employees</a>\n        <a [routerLink]=\"['./']\" class=\"breadcrumb active\">Details</a>\n      </div>\n    </div>\n  </nav>\n  <form>\n    <div class=\"row\" style=\"padding: 0px 20px\">\n      <ul class=\"collapsible popout z-depth-5\" data-collapsible=\"accordion\">\n        <li>\n          <div class=\"collapsible-header light-green-text text-darken-4 active grey lighten-5\" style=\"font-size: 20px\">\n            <i class=\"material-icons amber-text text-darken-4\" style=\"font-size: 30px\">looks_one</i>  Personal Information</div>\n          <div class=\"collapsible-body\">\n\n\n            <div class=\"row\">\n               \n\n              <div class=\"input-field col s12 m6  l4 \">\n                <label class=\"active\" for=\"last_name\">Salutation *</label>\n\n                <select id=\"salutation\">\n                  <option value=\"Mr.\">Mr.</option>\n                  <option value=\"Ms.\">Ms.</option>\n                  <option value=\"Mrs.\">Mrs.</option>\n                  <option value=\"Dr.\">Dr.</option>\n                </select>\n\n              </div>\n              <div class=\"input-field col s12 m6  l4 \">\n                <input id=\"empName\" type=\"text\" class=\"validate\" [(ngModel)]=\"empName\" name=\"empName\">\n                <label class=\"active\" for=\"empName\">First Name *</label>\n              </div>\n              <div class=\"input-field col s12 m6  l4 \">\n                <input id=\"fatherName\" type=\"text\" class=\"validate\" [(ngModel)]=\"fatherName\" name=\"fatherName\">\n                <label class=\"active\" for=\"fatherName\">Last Name *</label>\n              </div>\n              <!--               <div class=\"input-field col s12 m6  l4 \">\n                <input id=\"last_name\" type=\"text\" class=\"validate\" [(ngModel)]=\"qualification\"  name=\"qualification\">\n                <label class=\"active\" for=\"last_name\">Qualification</label>\n              </div> -->\n             <!--  <div class=\"input-field col s12 m6  l4 \">\n                <label class=\"active\" for=\"last_name\">Qualification *</label>\n                <select  id=\"qualification\">     - \n                <select id=\"qualification\" ng-model=\"selection\" multiple=\"multiple\" multi-select>\n                  <option value=\"PhD\">PhD</option>\n                  <option value=\"MPhil\">MPhil</option>\n                  <option value=\"Masters\">Masters</option>\n                  <option value=\"Bachelors\">Bachelors</option> \n                </select>\n              </div> -->\n              <div class=\"input-field col s12 m6  l4 \">\n                <input id=\"dob\" type=\"text\" class=\"datepicker\" materialize=\"pickadate\" [(ngModel)]=\"doj\" name=\"doj\">\n\n                <label class=\"active\" for=\"last_name\">Date Of Joining *</label>\n              </div>\n              <!--  <div class=\"input-field col s12 m6  l4 \">\n                  <input id=\"last_name\" type=\"text\" class=\"validate\" [(ngModel)]=\"natureofApp\"  name=\"natureofApp\">\n                  <label class=\"active\" for=\"last_name\">Nature Of Application</label>\n                </div>  -->\n\n              <div class=\"input-field col s12 m6  l4 \">\n                <input type=\"text\" class=\"validate\" [(ngModel)]=\"adhaarno\" name=\"adhaarno\">\n                <label class=\"active\" for=\"first_name\">Adhaar *</label>\n              </div>\n              <div class=\"input-field col s12 m6  l4 \">\n                <input type=\"text\" class=\"validate\" [(ngModel)]=\"pancardno\" name=\"pancardno\">\n                <label class=\"active\" for=\"first_name\">Pan Number *</label>\n              </div>\n\n              \n              <!-- <div class=\"input-field col s12 m6  l4 \">\n                    <input id=\"last_name\" type=\"text\" class=\"validate\" [(ngModel)]=\"designation\"  name=\"designation\">\n                    <label class=\"active\" for=\"last_name\">Designation</label>\n                  </div>   -->\n              <div class=\"input-field col s12 m6  l4 \">\n                <label class=\"active\" for=\"last_name\">Designation *</label>\n                <select id=\"designation\">\n                  <option value=\"1\">QA</option>\n                  <option value=\"2\">Operation</option>\n                  <option value=\"3\">DBA</option>\n                  \n                </select>\n              </div>\n              <div class=\"input-field col s12 m6  l4 \">                \n                <label class=\"active\" for=\"last_name\">Department *</label>\n              <select id=\"SchoolId\" >                                     \n                <!--  <option #allTheseThings *ngFor=\"let School of Schools;\" [value]=\"School.schoolID\">{{School.schoolname}}</option>   -->\n                 <option value=\"2\">Opertaions</option>\n      <option value=\"3\">Business Analytics</option>\n      <option value=\"4\">Tariff Support</option>\n      <option value=\"5\">Marketing</option>\n      <option value=\"6\">Quality Analyst</option>\n      <option value=\"7\">Database</option>\n      <option value=\"8\">Lead</option>\n              </select>\n              </div>\n              <!-- <div class=\"input-field col s12 m6  l4 \">                \n                <label class=\"active\" for=\"last_name\">Department *</label>\n                <select id=\"universityId\">\n                  <option #allTheseThings *ngFor=\"let univ of universities;\" [value]=\"univ.id\">{{univ.departmentname}}</option>\n                </select>\n              </div> -->\n\n              <!-- <div class=\"input-field col s12 m6  l4 \">\n                <input id=\"last_name\" type=\"text\" class=\"validate\" [(ngModel)]=\"payscale\"  name=\"payscale\">\n                <label class=\"active\" for=\"last_name\">Payscale</label>\n              </div> -->\n              <div class=\"input-field col s12 m6  l4 \">\n                <label class=\"active\" for=\"last_name\">Pay  *</label>\n                <select id=\"payscale\">\n                  <option value=\"1\">Level 1</option>\n                  <option value=\"2\">Level 2</option>\n                  <option value=\"3\">Level 3</option>\n                </select>\n              </div>\n              <div class=\"input-field col s12 m6  l4 \">\n                <input id=\"address\" type=\"text\" class=\"validate\" [(ngModel)]=\"address\" name=\"address\">\n                <label class=\"active\" for=\"address\">Address</label>\n              </div>              \n              <div class=\"input-field col s12 m6  l4 \">\n                <input id=\"phone\" type=\"text\" class=\"validate\" [(ngModel)]=\"phone\" name=\"phone\">\n                <label class=\"active\" for=\"phone\">Phone</label>\n              </div>\n              <div class=\"input-field col s12 m6  l4 \">\n                <input id=\"extn\" type=\"text\" class=\"validate\" [(ngModel)]=\"extn\" name=\"extn\">\n                <label class=\"active\" for=\"extn\">Extension</label>\n              </div>\n              <div class=\"input-field col s12 m6  l4 \">\n                <input id=\"email\" type=\"text\" class=\"validate\" [(ngModel)]=\"email\" name=\"email\">\n                <label class=\"active\" for=\"email\">Email *</label>\n              </div>              \n              <div class=\"input-field col s12 m6  l4 \">\n                <input id=\"password\" type=\"password\" class=\"validate\" [(ngModel)]=\"password\" name=\"password\">\n                <label class=\"active\" for=\"password\">Password *</label>\n              </div>\n\n            </div>\n            <a class=\"waves-effect waves-deep-orange btn\" (click)=\"moveNext($event, 1)\">Next</a>\n          </div>\n        </li>\n        <li>\n          <div class=\"collapsible-header light-green-text text-darken-4 active grey lighten-5\" style=\"font-size: 20px\">\n            <i class=\"material-icons amber-text text-darken-4\" style=\"font-size: 30px\">looks_two</i>Academic Details  *</div>\n          <div class=\"collapsible-body\">\n            <div class=\"row\" *ngFor=\"let academic of academics;let i = index\">\n              <!-- <div class=\"row\"> -->\n              <table>\n                <tbody>\n                  <tr>\n                   <!--  <td>                      \n                         \n                        <div class=\"input-field col s12 \">\n                        <input id=\"typeId_{{i}}\"  name=\"{{academic.typeId}}\" type=\"hidden\" value=\"1\"  [(ngModel)]=\"academic.typeId\"  [ngModelOptions]=\"{standalone: true}\" >\n                         \n                      </div>\n                        <select id=\"typeId_{{i}}\" [(ngModel)]=\"academic.typeId\" name=\"{{academic.typeId}}\" [ngModelOptions]=\"{standalone: true}\" >\n                          <option disabled value=\"-1\">Select </option>\n                          <option value=\"1\">School</option>\n                          <option value=\"2\">Degree</option>\n                          <option value=\"3\">Masters</option>\n                          <option value=\"4\">PhD</option>\n                          <option value=\"5\">Others</option>\n                        </select>\n                        <select  id=\"typeId_{{i}}\"   >                                    \n                            <option #allTheseThings *ngFor=\"let qualification of qualificationsStaff;\" [value]=\"qualification.qname\">{{qualification.qdesc}}</option>  \n                        </select>   \n                    \n                    </td> -->\n                    <td>\n                      <div class=\"input-field col s12 \">\n                        <input id=\"courseName_{{i}}\" [(ngModel)]=\"academic.courseName\" name=\"{{academic.courseName}}\" [ngModelOptions]=\"{standalone: true}\" type=\"text\">\n                        <label for=\"courseName\">Name of the Course</label>\n                      </div>\n                    </td>\n                    <td>\n                      <div class=\"input-field col s12 \">\n                        <input id=\"board_{{i}}\" [(ngModel)]=\"academic.board\" name=\"{{academic.board}}\" [ngModelOptions]=\"{standalone: true}\" type=\"text\">\n                        <label for=\"board\">Examination Board</label>\n                      </div>\n                    </td>\n                    <td>\n                      <div class=\"input-field col s12 \">\n                        <input id=\"year_{{i}}\" [(ngModel)]=\"academic.year\" name=\"{{academic.year}}\" [ngModelOptions]=\"{standalone: true}\"\n                          type=\"number\">\n                        <label for=\"year\">Year</label>\n                      </div>\n                    </td>\n                    <td>\n                      <div class=\"input-field col s12 \">\n                        <input id=\"percentage_{{i}}\" [(ngModel)]=\"academic.percentage\" name=\"{{academic.percentage}}\" [ngModelOptions]=\"{standalone: true}\"\n                          type=\"text\">\n                        <label for=\"percentage\">Percentage</label>\n                      </div>\n                    </td>\n                    <td>\n                      <button class=\"btn btn-default form-check-label red \" (click)=\"removeAcademics(i)\">-</button>\n                    </td>\n                  </tr>\n                </tbody>\n              </table>\n              <!--  </div> -->\n\n            </div>\n            <a class=\"btn btn-default form-check-label green \" style=\"float: right\" (click)=\"addAcademics()\">\n              <i class=\"material-icons\">add</i>\n            </a>\n            <a class=\"waves-effect waves-deep-orange btn\" (click)=\"moveNext($event, 2)\">Next</a>\n          </div>\n\n        </li>\n        <li>\n          <div class=\"collapsible-header light-green-text text-darken-4 active grey lighten-5\" style=\"font-size: 20px\">\n            <i class=\"material-icons amber-text text-darken-4\" style=\"font-size: 30px\">looks_3</i>Work Experience *</div>\n          <div class=\"collapsible-body\">\n            <div class=\"row\" *ngFor=\"let workingExperience of workingExperiences;let i = index\">\n              <div class=\"row\">\n                <table>\n                  <tbody>\n                    <tr>\n                      <td>\n                        <div class=\"input-field col s12 \">                          \n                          <input id=\"designation_{{i}}\" [(ngModel)]=\"workingExperience.designation\" name=\"{{workingExperience.designation}}\" [ngModelOptions]=\"{standalone: true}\" type=\"text\">\n                          <label for=\"designation\">Designation</label>\n                        </div>\n                      </td>\n                      <td>\n                        <div class=\"input-field col s12 \">                          \n                          <input id=\"organization_{{i}}\" [(ngModel)]=\"workingExperience.organization\" name=\"{{workingExperience.organization}}\" [ngModelOptions]=\"{standalone: true}\" type=\"text\">\n                          <label for=\"organization\">Organization</label>\n                        </div>\n                      </td>\n                      <td>\n                        <div class=\"input-field col s12 \">                          \n                          <input id=\"location_{{i}}\" [(ngModel)]=\"workingExperience.location\" name=\"{{workingExperience.location}}\" [ngModelOptions]=\"{standalone: true}\" type=\"text\">\n                          <label for=\"location\">Location</label>\n                        </div>\n                      </td>\n                      <td>\n                        <div class=\"input-field col s12 \">                          \n                         <input id=\"fromYear_{{i}}\" [(ngModel)]=\"workingExperience.fromYear\" name=\"{{workingExperience.fromYear}}\" [ngModelOptions]=\"{standalone: true}\" type=\"number\">  \n                          <!-- <input id=\"fromYear_{{i}}\"   class=\"datepicker\" materialize=\"pickadate\" [(ngModel)]=\"workingExperience.fromYear\" name=\"{{workingExperience.fromYear}}\" [ngModelOptions]=\"{standalone: true}\" type=\"text\"> -->\n                    \n                          <label for=\"fromYear\">From</label>\n                        </div>\n                      </td>\n                      <td>\n                        <div class=\"input-field col s12 \">                          \n                          <input id=\"toYear_{{i}}\" [(ngModel)]=\"workingExperience.toYear\" name=\"{{workingExperience.toYear}}\" [ngModelOptions]=\"{standalone: true}\" type=\"number\">\n                          <!-- <input id=\"toYear_{{i}}\"   class=\"datepicker\" materialize=\"pickadate\" [(ngModel)]=\"workingExperience.fromYear\" name=\"{{workingExperience.fromYear}}\" [ngModelOptions]=\"{standalone: true}\" type=\"text\"> -->\n                          <label for=\"toYear\">To</label>\n                        </div>\n                      </td>\n                      <td>\n                        <button class=\"btn btn-default form-check-label red \" (click)=\"removeWorkingExperiences(i)\">-</button>\n                      </td>\n                    </tr>\n                  </tbody>\n                </table>\n              </div>\n            </div>\n            <a class=\"btn btn-default form-check-label green \" style=\"float: right\" (click)=\"addWorkingExperiences()\">\n              <i class=\"material-icons\">add</i>\n            </a>\n            <a class=\"waves-effect waves-deep-orange btn\" (click)=\"moveNext($event, 3)\">Next</a>\n          </div>\n        </li>\n        <li>\n          <div class=\"collapsible-header light-green-text text-darken-4 active grey lighten-5\" style=\"font-size: 20px\">\n            <i class=\"material-icons amber-text text-darken-4\" style=\"font-size: 30px\">looks_4</i>Skills  *</div>\n          <div class=\"collapsible-body\">\n            <div class=\"row\" *ngFor=\"let skill of skills;let i = index\">\n              <div class=\"row\">\n                <table>\n                  <tbody>\n                    <tr>\n                      <td>\n                        <div class=\"input-field col s12 \">                           \n                          <input id=\"expertise_{{i}}\" [(ngModel)]=\"skill.expertise\" name=\"{{skill.expertise}}\" [ngModelOptions]=\"{standalone: true}\" type=\"text\">\n                          <label for=\"expertise\">Expertise</label>\n                        </div>\n                      </td>\n                      <td>\n                        <div class=\"input-field col s12 \">                           \n                          <input id=\"area_{{i}}\" [(ngModel)]=\"skill.area\" name=\"{{skill.area}}\" [ngModelOptions]=\"{standalone: true}\" type=\"text\">\n                          <label for=\"area\">Area</label>\n                        </div>\n                      </td>\n                      <td>\n                        <div class=\"input-field col s12 \">                         \n                          <input id=\"certification_{{i}}\" [(ngModel)]=\"skill.certification\" name=\"{{skill.certification}}\" [ngModelOptions]=\"{standalone: true}\" type=\"text\">\n                          <label for=\"certification\">Certification</label>\n                        </div>\n                      </td>\n                      <td>\n                        <button class=\"btn btn-default form-check-label red \" (click)=\"removeSkills(i)\">-</button>\n                      </td>\n                    </tr>\n                  </tbody>\n                </table>\n              </div>\n            </div>\n            <a class=\"btn btn-default form-check-label green \" style=\"float: right\" (click)=\"addSkills()\">\n              <i class=\"material-icons\">add</i>\n            </a>\n            <a class=\"waves-effect waves-deep-orange btn\" (click)=\"moveNext($event, 4)\">Next</a>\n          </div>\n        </li>\n       <!--  <li>\n          <div class=\"collapsible-header light-green-text text-darken-4 active grey lighten-5\" style=\"font-size: 20px\">\n            <i class=\"material-icons amber-text text-darken-4\" style=\"font-size: 30px\">looks_5</i>Personal Files</div>\n          <div class=\"collapsible-body\">\n            <div class=\"row\" *ngFor=\"let files of personalFiles;let i = index\">\n              <div class=\"row\">\n                <table>\n                  <tbody>\n                    <tr>\n                      <td>\n                        <div class=\"input-field col s12  \">\n                          <label class=\"active\" for=\"last_name\">Category Name</label>\n                          <select id=\"payscale\">\n                            <option value=\"1\">Publications</option>\n                            <option value=\"2\">Journals</option>\n                            <option value=\"3\">Books</option>\n                            <option value=\"4\">Online Materials</option>\n                            <option value=\"5\">Others</option>\n                          </select>\n                        </div>\n                      </td>\n                      <td>\n                        <div class=\"input-field col s12 \">\n                          <input id=\"first_name\" type=\"text\">\n                          <label for=\"first_name\">Expertise</label>\n                        </div>\n                      </td>\n                      <td>\n                        <div class=\"input-field col s12 \">\n                          <input id=\"first_name\" type=\"text\">\n                          <label for=\"textarea1\">Description</label>\n                        </div>\n                      </td>\n                      <td>\n                        <div class=\"file-field input-field col s12\">\n                          <div class=\"btn\">\n                            <span>File</span>\n                            <input type=\"file\">\n                          </div>\n                          <div class=\"file-path-wrapper\">\n                            <input class=\"file-path validate\" type=\"text\">\n                          </div>\n                        </div>\n                      </td>\n                      <td>\n                        <button class=\"btn btn-default form-check-label red \" (click)=\"removeAPersonalFiles(i)\">-</button>\n                      </td>\n                    </tr>\n                  </tbody>\n                </table>\n              </div>\n            </div>\n            <a class=\"btn btn-default form-check-label green \" (click)=\"addPersonalFiles()\">\n              <i class=\"material-icons\">add</i>\n            </a>\n          </div>\n        </li> -->\n      </ul>\n    </div>\n\n\n    <div class=\"row\">\n      <button class=\"btn waves-effect waves-light pink darken-4\" type=\"submit\" name=\"action\" (click)=\"createReminder()\">Save\n        <i class=\"material-icons right\">add</i>\n      </button>\n      <div class=\"progress\" *ngIf=\"isLoading\">\n        <div class=\"indeterminate\"></div>\n      </div>\n    </div>\n  </form>\n</div>"

/***/ }),

/***/ "./src/app/pages/staff/staffdetails/staffdetails.component.ts":
/*!********************************************************************!*\
  !*** ./src/app/pages/staff/staffdetails/staffdetails.component.ts ***!
  \********************************************************************/
/*! exports provided: StaffdetailsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StaffdetailsComponent", function() { return StaffdetailsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _angular_Http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/Http */ "./node_modules/@angular/Http/esm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs/_esm5/add/operator/map.js");





var StaffdetailsComponent = /** @class */ (function () {
    function StaffdetailsComponent(_router, _http, route) {
        var _this = this;
        this._http = _http;
        this.route = route;
        this.isLoading = false;
        this.Schools = [];
        this.universities = [];
        this.qualificationsStaff = [];
        this.academics = [];
        this.workingExperiences = [];
        this.skills = [];
        this.personalFiles = [];
        this.router = _router;
        this._http.get('Http://musictrainer.smartx.services:8080/NoteTrainer/getAllSchools')
            .map(function (res) { return res.json(); })
            .subscribe(function (data) {
            _this.Schools = data;
            console.log(_this.Schools);
        });
    }
    StaffdetailsComponent.prototype.addAcademics = function () {
        console.log(this.academics);
        this.academics.push({});
        console.log(this.academics);
    };
    StaffdetailsComponent.prototype.addWorkingExperiences = function () {
        this.workingExperiences.push({});
    };
    StaffdetailsComponent.prototype.addSkills = function () {
        this.skills.push({});
    };
    StaffdetailsComponent.prototype.addPersonalFiles = function () {
        this.personalFiles.push({});
    };
    StaffdetailsComponent.prototype.removeAcademics = function (index) {
        var lengthofelements = this.academics.length;
        if (lengthofelements !== 0) {
            this.academics.splice(index, 1);
        }
    };
    StaffdetailsComponent.prototype.removeWorkingExperiences = function (index) {
        var lengthofelements = this.workingExperiences.length;
        if (lengthofelements !== 0) {
            this.workingExperiences.splice(index, 1);
        }
    };
    StaffdetailsComponent.prototype.removeSkills = function (index) {
        var lengthofelements = this.skills.length;
        if (lengthofelements !== 0) {
            this.skills.splice(index, 1);
        }
    };
    StaffdetailsComponent.prototype.removeAPersonalFiles = function (index) {
        var lengthofelements = this.personalFiles.length;
        if (lengthofelements !== 0) {
            this.personalFiles.splice(index, 1);
        }
    };
    StaffdetailsComponent.prototype.ngAfterViewInit = function () {
        this.things.changes.subscribe(function (t) {
            $("select").material_select();
        });
        $('#dob').pickadate({
            selectMonths: true,
            selectYears: 100,
            closeOnSelect: true
        });
    };
    StaffdetailsComponent.prototype.createReminder = function () {
        var _this = this;
        this.isLoading = true;
        var selText;
        var optionVal = new Array();
        //var academicText: string;
        //var academicVal = new Array();
        $("#qualification option:selected").each(function () {
            var $this = $(this);
            if ($this.length) {
                selText = $this.text();
                optionVal.push(selText);
            }
        });
        var selv = optionVal.join();
        var data = {
            "id": this.id,
            "salutation": $("#salutation").val(),
            "empName": this.empName,
            "fatherName": this.fatherName,
            "qualification": "1",
            "doj": new Date(this.doj),
            "adhaarno": this.adhaarno,
            "pancardno": this.pancardno,
            "natureofApp": $("#natureofApp").val(),
            "designation": $("#designation").val(),
            "deptID": $("#SchoolId").val(),
            "payscale": $("#payscale").val(),
            "email": this.email,
            "address": this.address,
            "phone": this.phone,
            "extn": this.extn,
            "staffPassword": this.password,
            "isapproved": "Y",
            "isactive": "Y",
            "created_by": 1,
            "created_date": this.getDate(),
            "modified_by": 1,
            "modified_date": this.getDate(),
            "academicDetails": this.academics,
            "workExperience": this.workingExperiences,
            "skills": this.skills
        };
        console.log('My Data' + data);
        if (this.editId && this.editId !== "" && this.editId !== "None") {
            data["id"] = this.editId;
            return this._http.put('Http://musictrainer.smartx.services:8080/NoteTrainer/updateSchoolEmployee', data)
                .subscribe(function (res) {
                console.log(res);
                _this.isLoading = false;
                var $toastContent = $('<span>Record has been saved successfully!!</span>');
                Materialize.toast($toastContent, 2000);
                _this.router.navigate(['staff']);
            }, function (err) {
                console.log(err);
                var $toastContent = $('<span>' + JSON.parse(err["_body"])[0]["errMessage"] + '</span>');
                Materialize.toast($toastContent, 2000);
                _this.isLoading = false;
            });
        }
        else {
            debugger;
            return this._http.post('Http://musictrainer.smartx.services:8080/NoteTrainer/addSchoolEmployee', data)
                .subscribe(function (res) {
                console.log(res);
                _this.isLoading = false;
                var $toastContent = $('<span>Record has been saved successfully!!</span>');
                Materialize.toast($toastContent, 2000);
                _this.router.navigate(['staff']);
            }, function (err) {
                console.log(err);
                var $toastContent = $('<span>' + JSON.parse(err["_body"])[0]["errMessage"] + '</span>');
                Materialize.toast($toastContent, 2000);
                _this.isLoading = false;
            });
        }
    };
    StaffdetailsComponent.prototype.moveNext = function (event, tab) {
        $('.collapsible').collapsible('open', tab);
    };
    StaffdetailsComponent.prototype.ngAfterViewChecked = function () {
        Materialize.updateTextFields();
    };
    StaffdetailsComponent.prototype.ngOnInit = function () {
        var _this = this;
        $("select").material_select();
        $('.collapsible').collapsible({
            onOpen: function (el) { Materialize.updateTextFields(); }
        });
        this.route
            .queryParamMap
            .map(function (params) { return params.get('session_id') || 'None'; })
            .subscribe(function (val) { return _this.editId = val; });
        console.log(typeof this.editId);
        if (this.editId && this.editId !== "" && this.editId !== "None") {
            this.isLoading = true;
            return this._http.get('Http://musictrainer.smartx.services:8080/NoteTrainer/getSchoolEmployee/' + this.editId)
                .map(function (res) { return res.json(); })
                .subscribe(function (data) {
                var record = data[0];
                _this.id = record["id"];
                _this.salutation = record["salutation"];
                _this.empName = record["empName"];
                _this.fatherName = record["fatherName"];
                _this.qualification = record["qualification"];
                _this.doj = record["doj"];
                _this.adhaarno = record["adhaarno"];
                _this.pancardno = record["pancardno"];
                _this.natureofApp = record["natureofApp"];
                _this.designation = record["designation"];
                _this.deptID = record["deptID"];
                _this.payscale = record["payscale"];
                _this.email = record["email"];
                _this.address = record["address"];
                _this.password = record["staffPassword"];
                _this.phone = record["phone"];
                _this.extn = record["extn"];
                _this.isLoading = false;
                $("#universityId").val(record["deptID"]);
                $("#salutation").val(record["salutation"]);
                $("select").material_select();
                _this.academics = record["academicDetails"];
                _this.workingExperiences = record["workExperience"];
                _this.skills = record["skills"];
                Materialize.updateTextFields();
                //debugger;
            }, function (err) {
                console.log('Something went wrong!');
                _this.isLoading = false;
            });
        }
        //   let m = this.model;
        //   m.valueChanges.subscribe(value => {
        //     Materialize.updateTextFields();
        // });
        Materialize.updateTextFields();
    };
    StaffdetailsComponent.prototype.getDate = function () {
        var myDate = new Date();
        return myDate.getFullYear() + '-' + (myDate.getMonth() + 1) + '-' + myDate.getDate();
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChildren"])('allTheseThings'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], StaffdetailsComponent.prototype, "things", void 0);
    StaffdetailsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-staffdetails',
            template: __webpack_require__(/*! ./staffdetails.component.html */ "./src/app/pages/staff/staffdetails/staffdetails.component.html"),
            styles: [__webpack_require__(/*! ./staffdetails.component.css */ "./src/app/pages/staff/staffdetails/staffdetails.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _angular_Http__WEBPACK_IMPORTED_MODULE_2__["Http"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]])
    ], StaffdetailsComponent);
    return StaffdetailsComponent;
}());



/***/ }),

/***/ "./src/app/pages/stcoach/stcoach.component.css":
/*!*****************************************************!*\
  !*** ./src/app/pages/stcoach/stcoach.component.css ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3N0Y29hY2gvc3Rjb2FjaC5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/pages/stcoach/stcoach.component.html":
/*!******************************************************!*\
  !*** ./src/app/pages/stcoach/stcoach.component.html ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">  \n    <nav class=\"z-depth-0\">\n        <div class=\"nav-wrapper white \">\n          <div class=\"col s5 m9 l9\">\n              <a [routerLink]=\"['../']\" class=\"breadcrumb grey-text\">Dashboard</a>\n               <a [routerLink]=\"['./']\" class=\"breadcrumb active\">STCoch</a>\n        \n          </div>    \n          \n                \n          <div class=\"col s2 m2 l1\">          \n              <a class=\"waves-effect cyan  btn-large\" style=\"    height: 42px;\n              line-height: 43px;\n              padding: 0px 20px;\"\n              [routerLink]=\"['./stcoachdetails']\"\n              href=\"!#\" ><i class=\"large material-icons\" style=\"font-size: 2rem; height: 42px;\n              line-height: 43px;\">add</i></a>\n          </div>\n        </div>\n    </nav>\n    <div  style=\"padding:5px\">\n        <div style=\"padding: 0px 10px\">\n            \n                  <table class=\"highlight bordered  \" style=\"border: 1px solid #ddd\">\n                    <thead class=\" blue lighten-5\">\n          <tr>\n              \n               <th>ID</th>\n              <th>FirstName</th>\n              <th>MiddleName</th>\n              <th>LastName</th>\n              <th>Gender</th>\n            <!--\n              <th>FireBaseUrl</th>\n              <th>permanentAddress</th>\n              <th>PA_City</th>\n              <th>PA_State</th>\n              <th>PIN</th>\n              <th>SportId</th>\n              <th>Email</th>\n              <th>MobileNumber</th>\n              <th>DOB</th>\n              <th>Password</th>\n              <th>ConfirmPassword</th>\n              <th>OTPGenerator</th>\n              <th>OTPConfirm</th>-->\n              <th>Action</th>\n          \n\n\n\n          </tr>\n        </thead>\n      \n        <tbody>\n          <tr *ngFor=\"let record of records;\">\n            <td>{{record.id}}</td>\n            <td>{{record.firstName}}</td>\n            <td>{{record.middleName}}</td>\n            <td>{{record.lastName}}</td>           \n            <td>{{record.gender}}</td>\n            <!--\n            <td>{{record.firebaseUrl}}</td>\n            <td>{{record.pA_City}}</td>\n            <td>{{record.pA_State}}</td>\n            <td>{{record.pin}}</td>\n            <td>{{record.sportId}}</td>\n            <td>{{record.email}}</td>\n            <td>{{record.mobileNumber}}</td>\n            <td>{{record.dob}}</td>\n            <td>{{record.Password}}</td>\n            <td>{{record.confPassword}}</td>\n            <td>{{record.otpGen}}</td>\n            <td>{{record.otpConfirm}}</td>\n             -->\n          <!--   <td>{{record.isActive}}</td> -->\n            \n\n              \n            <td>              \n              <a class=\"btn-floating waves-effect waves-light blue darken-3\" (click)=\"edit(record.id)\" ><i class=\"material-icons\">edit</i></a>\n              <a class=\"btn-floating waves-effect waves-light red darken-2 modal-trigger\" (click)=\"selectForDelete(record.id)\" href=\"#modal1\"><i class=\"material-icons\">delete</i></a>\n            </td>\n          </tr>\n        </tbody>\n      </table>\n      <div class=\"progress\" *ngIf=\"isLoading\">\n          <div class=\"indeterminate\"></div>\n      </div>\n\n      <my-pagination\n        (goPage)=\"goToPage($event)\"\n        (goNext)=\"onNext()\"\n        (goPrev)=\"onPrev()\"\n        [pagesToShow]=\"10\"\n        [page]=\"page\"\n        [perPage]=\"limit\"\n        [count]=\"total\">\n    </my-pagination>   \n      </div>\n     \n  </div> \n  <div id=\"modal12\" class=\"modal\">\n      <div class=\"modal-content\">\n        <h4>Upload the Data</h4>\n        <p>Please Choose the File.</p> <p><input type=\"file\" name=\"file\"   #fileInput (change)=\"onFileSelect($event)\" /></p>\n     <!--  </div>\n      <div class=\"modal-footer\"> -->\n       <a [routerLink]=\"['./']\" (click)=\"uploadExcelSheet()\" class=\"modal-action modal-close waves-effect waves-green btn blue\">Upload</a>  \n </div> <div class=\"modal-content\">\n        <h4>Download the Data</h4>\n       <a [routerLink]=\"['./']\" (click)=\"downloadexcelfile()\" class=\"modal-action modal-close waves-effect waves-green btn red\">Download</a>\n       <p>Total Records: {{totalEmployees}}</p>  \n      </div>\n    </div>\n\n    <div id=\"modal1\" class=\"modal\">\n      <div class=\"modal-content\">\n        <h4>Delete?</h4>\n        <p>Are you sure, you want to delete this record?</p>\n      </div>\n      <div class=\"modal-footer\">\n        <a [routerLink]=\"['./']\" (click)=\"delete()\" class=\"modal-action modal-close waves-effect waves-green btn red\">Delete</a>\n      </div>\n    </div>\n</div>\n        "

/***/ }),

/***/ "./src/app/pages/stcoach/stcoach.component.ts":
/*!****************************************************!*\
  !*** ./src/app/pages/stcoach/stcoach.component.ts ***!
  \****************************************************/
/*! exports provided: STCoachComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "STCoachComponent", function() { return STCoachComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _angular_Http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/Http */ "./node_modules/@angular/Http/esm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs/_esm5/add/operator/map.js");





var STCoachComponent = /** @class */ (function () {
    function STCoachComponent(_router, _http) {
        this._http = _http;
        this.records = [];
        this.isLoading = false;
        this.total = 0;
        this.page = 1;
        this.limit = 10;
        this.router = _router;
        this.loadIntialListOfEmplyees();
        this.countEmployeeRecords();
    }
    STCoachComponent.prototype.goToPage = function (n) {
        this.page = n;
        this.loadIntialListOfEmplyees();
    };
    STCoachComponent.prototype.onNext = function () {
        this.page++;
        this.loadIntialListOfEmplyees();
    };
    STCoachComponent.prototype.onPrev = function () {
        this.page--;
        this.loadIntialListOfEmplyees();
    };
    STCoachComponent.prototype.loadIntialListOfEmplyees = function () {
        var _this = this;
        this.isLoading = true;
        return this._http.get('Http://52.66.246.140:8080/SkillTeck/listSTCoachs?page=' + this.page + '&size=' + this.limit)
            .map(function (res) { return res.json(); })
            .subscribe(function (data) {
            _this.records = data.stcoachList;
            _this.total = data.totalRecords;
            console.log(_this.records);
            _this.isLoading = false;
        }, function (err) {
            console.log('Something went wrong!');
            _this.isLoading = false;
        });
    };
    STCoachComponent.prototype.edit = function (id) {
        var navigationExtras = {
            queryParams: { 'session_id': id },
            skipLocationChange: true
        };
        this.router.navigate(['/stcoach/stcoachdetails'], navigationExtras);
    };
    STCoachComponent.prototype.selectForDelete = function (id) {
        this.deleteId = id;
    };
    STCoachComponent.prototype.delete = function () {
        var _this = this;
        this.isLoading = true;
        return this._http.delete('Http://52.66.246.140:8080/SkillTeck/deleteSTCoach/' + this.deleteId)
            .subscribe(function (data) {
            var $toastContent = $('<span>Record has been deleted successfully!!</span>');
            Materialize.toast($toastContent, 2000);
            _this.isLoading = false;
            _this.loadIntialListOfEmplyees();
        }, function (err) {
            console.log('Something went wrong!');
            _this.isLoading = false;
        });
    };
    STCoachComponent.prototype.moveNext = function (event, tab) {
        $('.collapsible').collapsible('open', tab);
    };
    STCoachComponent.prototype.ngOnInit = function () {
        $("select").material_select();
        $('.collapsible').collapsible();
        $('.modal').modal();
    };
    STCoachComponent.prototype.ngAfterViewChecked = function () {
        var self = this;
    };
    STCoachComponent.prototype.uploadExcelSheet = function () {
    };
    STCoachComponent.prototype.downloadexcel = function () {
    };
    STCoachComponent.prototype.downloadexcelfile = function () {
        var url = 'Http://34.93.202.192:8080/SpoorsReports/getAllEmployeesToPrintXL';
        this.downloadXLFile(url).subscribe(function (res) {
            var fileURL = URL.createObjectURL(res);
            window.open(fileURL);
        });
    };
    STCoachComponent.prototype.downloadXLFile = function (url) {
        return this._http.get(url, { responseType: _angular_Http__WEBPACK_IMPORTED_MODULE_2__["ResponseContentType"].Blob }).map(function (res) {
            return new Blob([res.blob()], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        });
    };
    STCoachComponent.prototype.downloadpdf = function () {
        var url = 'Http://34.93.202.192:8080/SpoorsReports/getAllEmployeesToPrint';
        this.downloadFile(url).subscribe(function (res) {
            var fileURL = URL.createObjectURL(res);
            window.open(fileURL);
        });
    };
    STCoachComponent.prototype.downloadFile = function (url) {
        return this._http.get(url, { responseType: _angular_Http__WEBPACK_IMPORTED_MODULE_2__["ResponseContentType"].Blob }).map(function (res) {
            return new Blob([res.blob()], { type: 'application/pdf' });
        });
    };
    STCoachComponent.prototype.countEmployeeRecords = function () {
        var _this = this;
        this.isLoading = true;
        return this._http.get('Http://34.93.202.192:8080/Spoors/employeesCount')
            .map(function (res) { return res.json(); })
            .subscribe(function (data) {
            _this.totalEmployees = data.totalRecords;
            console.log('Count of Emplyees --- ' + _this.totalEmployees);
        }, function (err) {
            console.log('Something went wrong!');
        });
        this.isLoading = false;
    };
    STCoachComponent.prototype.onFileSelect = function (event) {
        var _this = this;
        console.log('File Change Event !');
        if (event.target.files.length > 0) {
            var file = event.target.files[0];
            var formdata = new FormData();
            formdata.append('file', file);
            return this._http.post('Http://34.93.202.192:8080/SpoorsEmployees/importEmpData', formdata)
                .subscribe(function (res) {
                console.log(res);
                _this.isLoading = false;
                var $toastContent = $('<span>Record has been loaded successfully!!</span>');
                Materialize.toast($toastContent, 2000);
                _this.router.navigate(['/spoorsemployees']);
            }, function (err) {
                var $toastContent = $('<span>' + JSON.parse(err["_body"])[0]["errMessage"] + '</span>');
                Materialize.toast($toastContent, 2000);
                _this.isLoading = false;
            });
        }
    };
    STCoachComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-stcoach',
            template: __webpack_require__(/*! ./stcoach.component.html */ "./src/app/pages/stcoach/stcoach.component.html"),
            styles: [__webpack_require__(/*! ./stcoach.component.css */ "./src/app/pages/stcoach/stcoach.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _angular_Http__WEBPACK_IMPORTED_MODULE_2__["Http"]])
    ], STCoachComponent);
    return STCoachComponent;
}());



/***/ }),

/***/ "./src/app/pages/stcoach/stcoachdetails/stcoachdetails.component.css":
/*!***************************************************************************!*\
  !*** ./src/app/pages/stcoach/stcoachdetails/stcoachdetails.component.css ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3N0Y29hY2gvc3Rjb2FjaGRldGFpbHMvc3Rjb2FjaGRldGFpbHMuY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/pages/stcoach/stcoachdetails/stcoachdetails.component.html":
/*!****************************************************************************!*\
  !*** ./src/app/pages/stcoach/stcoachdetails/stcoachdetails.component.html ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">  \n    <nav>\n        <div class=\"nav-wrapper white grey-text text-darken-2\">\n          <div class=\"col s12 grey-text text-darken-2\">\n             <a [routerLink]=\"['../../']\" class=\"breadcrumb grey-text\">Dashboard</a>\n            <a [routerLink]=\"['../']\" class=\"breadcrumb grey-text\">STCoach</a>\n            <a [routerLink]=\"['./']\" class=\"breadcrumb active\">Details</a>\n          </div>\n        </div>\n    </nav>\n\n    <div class=\"row\" style=\"padding: 0px 20px\">\n    <ul class=\"collapsible popout z-depth-5\" data-collapsible=\"accordion\">\n      <li>\n        <div class=\"collapsible-header light-green-text text-darken-4 active grey lighten-5\" style=\"font-size: 20px\"><i class=\"material-icons amber-text text-darken-4\" style=\"font-size: 30px\">looks_one</i>\n          STCocah Profile</div>\n        <div class=\"collapsible-body\">\n  \n          <form >\n                    <div class=\"row\">\n                      <div class=\"input-field col s12 m6  l4 \">\n                        <input  id=\"firstName\" type=\"text\" class=\"validate\" [(ngModel)]=\"firstName\" name=\" firstName\">\n                        <label class=\"active\" for=\"firstName\">FirstName</label>\n                      </div>\n\n                      <div class=\"input-field col s12 m6  l4 \">\n                        <input  id=\"middleName\" type=\"text\" class=\"validate\" [(ngModel)]=\"middleName\" name=\"middleName\">\n                          <label class=\"active\" for=\" middleName\">MiddleName</label>\n                        </div>  \n\n                        <div class=\"input-field col s12 m6  l4 \">\n                          <input  id=\"lastName\" type=\"text\" class=\"validate\" [(ngModel)]=\"lastName\" name=\"lastName\">\n                          <label class=\"active\" for=\"lastName\">LastName</label>\n                        </div> \n\n                        <div class=\"input-field col s12 m6  l4 \">\n                        <input  id=\"gender\" type=\"text\" class=\"validate\" [(ngModel)]=\"gender\" name=\"gender\">\n                          <label class=\"active\" for=\"gender\">Gender</label>\n                        </div> \n\n                        <div class=\"input-field col s12 m6  l4 \">\n                          <input  id=\"firebaseUrl\" type=\"text\" class=\"validate\" [(ngModel)]=\"firebaseUrl\" name=\"firebaseUrl\">\n                          <label class=\"active\" for=\"firebaseUrl\">FirebaseUrl</label>\n                        </div>\n\n                        <div class=\"input-field col s12 m6  l4 \">\n                          <input  id=\"permanent_Address\" type=\"text\" class=\"validate\" [(ngModel)]=\"permanent_Address\" name=\"permanent_Address\">\n                          <label class=\"active\" for= \"permanent_Address\">PermanentAddress</label>\n                        </div> \n\n                        <div class=\"input-field col s12 m6  l4 \">\n                          <input  id=\"pA_City\" type=\"text\" class=\"validate\" [(ngModel)]=\"pA_City\" name=\"pA_City\">\n                          <label class=\"active\" for=\"pA_City\">PACity</label>\n                        </div>  \n                                               \n                        \n                                              \n                        <div class=\"input-field col s12 m6  l4 \">\n                          <input  id=\"pA_State\" type=\"text\" class=\"validate\" [(ngModel)]=\"pA_State\" name=\"pA_State\">\n                          <label class=\"active\" for=\"pA_State\">PAState</label>\n                        </div> \n\n                        <div class=\"input-field col s12 m6  l4 \">\n                          <input  id=\"pin\" type=\"text\" class=\"validate\" [(ngModel)]=\"pin\" name=\"pin\">\n                          <label class=\"active\" for=\"pin\">PIN</label>\n                        </div> \n\n                         <div class=\"input-field col s12 m6  l4 \">\n                          <input  id=\"sportId\" type=\"text\" class=\"validate\" [(ngModel)]=\"sportId\" name=\"sportId\">\n                          <label class=\"active\" for=\"sportId\">SportId</label>\n                        </div> \n\n                         <div class=\"input-field col s12 m6  l4 \">\n                         <input  id=\"email\" type=\"text\" class=\"validate\" [(ngModel)]=\"email\" name=\"email\">\n                          <label class=\"active\" for=\"email\">Email</label>\n                        </div> \n\n                        <div class=\"input-field col s12 m6  l4 \">\n                         <input  id=\"mobileNumber\" type=\"text\" class=\"validate\" [(ngModel)]=\"mobileNumber\" name=\"mobileNumber\">\n                          <label class=\"active\" for=\"mobileNumber\">MobileNumber</label>\n                        </div> \n\n                        \n                        <div class=\"input-field col s12 m6  l4 \">\n                         <input  id=\"dob\" type=\"text\" class=\"validate\" [(ngModel)]=\"dob\" name=\"dob\">\n                          <label class=\"active\" for=\"dob\">DOB</label>\n                        </div> \n\n                        <div class=\"input-field col s12 m6  l4 \">\n                         <input  id=\"password\" type=\"text\" class=\"validate\" [(ngModel)]=\"password\" name=\"password\">\n                          <label class=\"active\" for=\"password\">Password</label>\n                        </div> \n\n\n                        <div class=\"input-field col s12 m6  l4 \">\n                         <input  id=\"confPassword\" type=\"text\" class=\"validate\" [(ngModel)]=\"confPassword\" name=\"confPassword\">\n                          <label class=\"active\" for=\"confPassword\">ConfirmPassword</label>\n                        </div> \n\n                        <div class=\"input-field col s12 m6  l4 \">\n                         <input  id=\"otpGen\" type=\"text\" class=\"validate\" [(ngModel)]=\"otpGen\" name=\"otpGen\">\n                          <label class=\"active\" for=\"otpGen\">OTPGenerator</label>\n                        </div> \n\n                         <div class=\"input-field col s12 m6  l4 \">\n                         <input  id=\"otpConfirm\" type=\"text\" class=\"validate\" [(ngModel)]=\"otpConfirm\" name=\"otpConfirm\">\n                          <label class=\"active\" for=\"otpConfirm\">OTPConfirm</label>\n                        </div> \n\n                        \n                         \n                       \n                    </div>\n                    <button class=\"btn waves-effect waves-light cyan\"  (click)=\"createReminder()\" name=\"action\">Save                       <i class=\"material-icons right\">add</i>\n                      </button> \n                      <div class=\"progress\" *ngIf=\"isLoading\">\n                          <div class=\"indeterminate\"></div>\n                      </div>\n                    </form>\n        </div>\n      </li>\n\n     \n    </ul>   \n  </div> \n  \n  </div>\n        "

/***/ }),

/***/ "./src/app/pages/stcoach/stcoachdetails/stcoachdetails.component.ts":
/*!**************************************************************************!*\
  !*** ./src/app/pages/stcoach/stcoachdetails/stcoachdetails.component.ts ***!
  \**************************************************************************/
/*! exports provided: STCoachdetailsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "STCoachdetailsComponent", function() { return STCoachdetailsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _angular_Http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/Http */ "./node_modules/@angular/Http/esm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs/_esm5/add/operator/map.js");





var STCoachdetailsComponent = /** @class */ (function () {
    function STCoachdetailsComponent(_router, _http, route) {
        this._http = _http;
        this.route = route;
        this.isLoading = false;
        this.router = _router;
    }
    STCoachdetailsComponent.prototype.createReminder = function () {
        var _this = this;
        this.isLoading = true;
        var data = {
            "firstName": this.firstName,
            "middleName": this.middleName,
            "lastName": this.lastName,
            "gender": this.gender,
            "firebaseUrl": this.firebaseUrl,
            "permanent_Address": this.permanent_Address,
            "pA_City": this.pA_City,
            "pA_State": this.pA_State,
            "pin": this.pin,
            "sportId": this.sportId,
            "email": this.email,
            "mobileNumber": this.mobileNumber,
            "dob": this.dob,
            "password": this.password,
            "confPassword": this.confPassword,
            "otpGen": this.otpGen,
            "otpConfirm": this.otpConfirm,
            "isActive": 'y',
            "isAprroved": 'y',
        };
        if (this.firstName == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>firstName is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.middleName == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>MiddleName is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.lastName == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>LastName is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.gender == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>Gender is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.firebaseUrl == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>firebaseUrl is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.permanent_Address == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>permanent_Address is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.pA_City == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>pA_City is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.pA_State == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>pA_State is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.pin == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>pin is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.sportId == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>sportId is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.email == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>Email is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.mobileNumber == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>mobileNumber is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.dob == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>dob is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.password == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>password is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.confPassword == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>confPassword is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.otpGen == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>otpGen is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.otpConfirm == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>otpConfirm is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.editId && this.editId !== "" && this.editId !== "None") {
            data["id"] = this.editId;
            return this._http.put('Http://52.66.246.140:8080/SkillTeck/updateSTCoach/', data)
                .subscribe(function (res) {
                console.log(res);
                _this.isLoading = false;
                var $toastContent = $('<span>Record has been saved successfully!!</span>');
                Materialize.toast($toastContent, 2000);
                _this.router.navigate(['/stcoach']);
            }, function (err) {
                var $toastContent = $('<span>' + JSON.parse(err["_body"])[0]["errMessage"] + '</span>');
                Materialize.toast($toastContent, 2000);
                _this.isLoading = false;
            });
        }
        else {
            return this._http.post('Http://52.66.246.140:8080/SkillTeck/addSTCoach/', data)
                .subscribe(function (res) {
                console.log(res);
                _this.isLoading = false;
                var $toastContent = $('<span>Record has been saved successfully!!</span>');
                Materialize.toast($toastContent, 2000);
                _this.router.navigate(['/stcoach']);
            }, function (err) {
                var $toastContent = $('<span>' + JSON.parse(err["_body"])[0]["errMessage"] + '</span>');
                Materialize.toast($toastContent, 2000);
                _this.isLoading = false;
            });
        }
    };
    STCoachdetailsComponent.prototype.moveNext = function (event, tab) {
        $('.collapsible').collapsible('open', tab);
    };
    STCoachdetailsComponent.prototype.ngAfterViewInit = function () {
        this.things.changes.subscribe(function (t) {
            $("select").material_select();
        });
    };
    STCoachdetailsComponent.prototype.ngAfterViewChecked = function () {
        Materialize.updateTextFields();
    };
    STCoachdetailsComponent.prototype.ngOnInit = function () {
        var _this = this;
        $("select").material_select();
        $('.collapsible').collapsible({
            onOpen: function (el) { Materialize.updateTextFields(); }
        });
        this.route
            .queryParamMap
            .map(function (params) { return params.get('session_id') || 'None'; })
            .subscribe(function (val) { return _this.editId = val; });
        console.log(this.editId);
        if (this.editId && this.editId !== "" && this.editId !== "None") {
            this.isLoading = true;
            return this._http.get('Http://52.66.246.140:8080/SkillTeck/getSTCoachById/' + this.editId)
                .map(function (res) { return res.json(); })
                .subscribe(function (data) {
                var record = data[0];
                _this.firstName = record["firstName"];
                _this.middleName = record["middleName"];
                _this.lastName = record["lastName"];
                _this.gender = record["gender"];
                _this.firebaseUrl = record["firebaseUrl"];
                _this.permanent_Address = record["permanent_Address"];
                _this.pA_City = record["pA_City"];
                _this.pA_State = record["pA_State"];
                _this.pin = record["pin"];
                _this.sportId = record["sportId"];
                _this.email = record["email"];
                _this.mobileNumber = record["mobileNumber"];
                _this.dob = record["dob"];
                _this.password = record["password"];
                _this.confPassword = record["confPassword"];
                _this.otpGen = record["otpGen"];
                _this.otpConfirm = record["otpConfirm"];
                $("select").material_select();
                Materialize.updateTextFields();
                _this.isLoading = false;
                //debugger;
            }, function (err) {
                console.log('Something went wrong!');
                _this.isLoading = false;
            });
        }
        Materialize.updateTextFields();
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChildren"])('allTheseThings'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], STCoachdetailsComponent.prototype, "things", void 0);
    STCoachdetailsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-stcoachdetails',
            template: __webpack_require__(/*! ./stcoachdetails.component.html */ "./src/app/pages/stcoach/stcoachdetails/stcoachdetails.component.html"),
            styles: [__webpack_require__(/*! ./stcoachdetails.component.css */ "./src/app/pages/stcoach/stcoachdetails/stcoachdetails.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _angular_Http__WEBPACK_IMPORTED_MODULE_2__["Http"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]])
    ], STCoachdetailsComponent);
    return STCoachdetailsComponent;
}());



/***/ }),

/***/ "./src/app/pages/stuser/stuser.component.css":
/*!***************************************************!*\
  !*** ./src/app/pages/stuser/stuser.component.css ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3N0dXNlci9zdHVzZXIuY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/pages/stuser/stuser.component.html":
/*!****************************************************!*\
  !*** ./src/app/pages/stuser/stuser.component.html ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">  \n    <nav class=\"z-depth-0\">\n        <div class=\"nav-wrapper white \">\n          <div class=\"col s5 m9 l9\">\n              <a [routerLink]=\"['../']\" class=\"breadcrumb grey-text\">Dashboard</a>\n               <a [routerLink]=\"['./']\" class=\"breadcrumb active\">STUser</a>\n        \n          </div>    \n          \n                \n          <div class=\"col s2 m2 l1\">          \n              <a class=\"waves-effect cyan  btn-large\" style=\"    height: 42px;\n              line-height: 43px;\n              padding: 0px 20px;\"\n              [routerLink]=\"['./stuserdetails']\"\n              href=\"!#\" ><i class=\"large material-icons\" style=\"font-size: 2rem; height: 42px;\n              line-height: 43px;\">add</i></a>\n          </div>\n        </div>\n    </nav>\n    <div  style=\"padding:5px\">\n        <div style=\"padding: 0px 10px\">\n            \n                  <table class=\"highlight bordered  \" style=\"border: 1px solid #ddd\">\n                    <thead class=\" blue lighten-5\">\n          <tr>\n              \n              <th>ID</th>\n              <th>FirstName</th>\n              <th>MiddleName</th>\n              <th>LastName</th>\n              <th>Gender</th>\n            <!--\n              <th>FireBaseUrl</th>\n              <th>permanentAddress</th>\n              <th>PA_City</th>\n              <th>PA_State</th>\n              <th>PIN</th>\n              <th>Occupation</th>\n              <th>Email</th>\n              <th>MobileNumber</th>\n              <th>DOB</th>\n              <th>Password</th>\n              <th>ConfirmPassword</th>\n              <th>OTPGenerator</th>\n              <th>OTPConfirm</th>-->\n              <th>Action</th>\n            \n\n          </tr>\n        </thead>\n      \n        <tbody>\n          <tr *ngFor=\"let record of records;\">\n           <td>{{record.id}}</td>\n            <td>{{record.firstName}}</td>\n            <td>{{record.middleName}}</td>\n            <td>{{record.lastName}}</td>           \n            <td>{{record.gender}}</td>\n            <!--\n            <td>{{record.firebaseUrl}}</td>\n            <td>{{record.pA_City}}</td>\n            <td>{{record.pA_State}}</td>\n            <td>{{record.pin}}</td>\n            <td>{{record.occupation}}</td>\n            <td>{{record.email}}</td>\n            <td>{{record.mobileNumber}}</td>\n            <td>{{record.dob}}</td>\n            <td>{{record.Password}}</td>\n            <td>{{record.confPassword}}</td>\n            <td>{{record.otpGen}}</td>\n            <td>{{record.otpConfirm}}</td>\n             -->\n          <!--   <td>{{record.isActive}}</td> -->\n            \n\n              \n            <td>              \n              <a class=\"btn-floating waves-effect waves-light blue darken-3\" (click)=\"edit(record.id)\" ><i class=\"material-icons\">edit</i></a>\n              <a class=\"btn-floating waves-effect waves-light red darken-2 modal-trigger\" (click)=\"selectForDelete(record.id)\" href=\"#modal1\"><i class=\"material-icons\">delete</i></a>\n            </td>\n          </tr>\n        </tbody>\n      </table>\n      <div class=\"progress\" *ngIf=\"isLoading\">\n          <div class=\"indeterminate\"></div>\n      </div>\n\n      <my-pagination\n        (goPage)=\"goToPage($event)\"\n        (goNext)=\"onNext()\"\n        (goPrev)=\"onPrev()\"\n        [pagesToShow]=\"10\"\n        [page]=\"page\"\n        [perPage]=\"limit\"\n        [count]=\"total\">\n    </my-pagination>   \n      </div>\n     \n  </div> \n  <div id=\"modal12\" class=\"modal\">\n      <div class=\"modal-content\">\n        <h4>Upload the Data</h4>\n        <p>Please Choose the File.</p> <p><input type=\"file\" name=\"file\"   #fileInput (change)=\"onFileSelect($event)\" /></p>\n     <!--  </div>\n      <div class=\"modal-footer\"> -->\n       <a [routerLink]=\"['./']\" (click)=\"uploadExcelSheet()\" class=\"modal-action modal-close waves-effect waves-green btn blue\">Upload</a>  \n </div> <div class=\"modal-content\">\n        <h4>Download the Data</h4>\n       <a [routerLink]=\"['./']\" (click)=\"downloadexcelfile()\" class=\"modal-action modal-close waves-effect waves-green btn red\">Download</a>\n       <p>Total Records: {{totalEmployees}}</p>  \n      </div>\n    </div>\n\n    <div id=\"modal1\" class=\"modal\">\n      <div class=\"modal-content\">\n        <h4>Delete?</h4>\n        <p>Are you sure, you want to delete this record?</p>\n      </div>\n      <div class=\"modal-footer\">\n        <a [routerLink]=\"['./']\" (click)=\"delete()\" class=\"modal-action modal-close waves-effect waves-green btn red\">Delete</a>\n      </div>\n    </div>\n</div>\n        "

/***/ }),

/***/ "./src/app/pages/stuser/stuser.component.ts":
/*!**************************************************!*\
  !*** ./src/app/pages/stuser/stuser.component.ts ***!
  \**************************************************/
/*! exports provided: STUserComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "STUserComponent", function() { return STUserComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _angular_Http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/Http */ "./node_modules/@angular/Http/esm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs/_esm5/add/operator/map.js");





var STUserComponent = /** @class */ (function () {
    function STUserComponent(_router, _http) {
        this._http = _http;
        this.records = [];
        this.isLoading = false;
        this.total = 0;
        this.page = 1;
        this.limit = 10;
        this.router = _router;
        this.loadIntialListOfEmplyees();
        this.countEmployeeRecords();
    }
    STUserComponent.prototype.goToPage = function (n) {
        this.page = n;
        this.loadIntialListOfEmplyees();
    };
    STUserComponent.prototype.onNext = function () {
        this.page++;
        this.loadIntialListOfEmplyees();
    };
    STUserComponent.prototype.onPrev = function () {
        this.page--;
        this.loadIntialListOfEmplyees();
    };
    STUserComponent.prototype.loadIntialListOfEmplyees = function () {
        var _this = this;
        this.isLoading = true;
        return this._http.get('Http://52.66.246.140:8080/SkillTeck/listSTUsers?page=' + this.page + '&size=' + this.limit)
            .map(function (res) { return res.json(); })
            .subscribe(function (data) {
            _this.records = data.stuserList;
            _this.total = data.totalRecords;
            console.log(_this.records);
            _this.isLoading = false;
        }, function (err) {
            console.log('Something went wrong!');
            _this.isLoading = false;
        });
    };
    STUserComponent.prototype.edit = function (id) {
        var navigationExtras = {
            queryParams: { 'session_id': id },
            skipLocationChange: true
        };
        this.router.navigate(['/stuser/stuserdetails'], navigationExtras);
    };
    STUserComponent.prototype.selectForDelete = function (id) {
        this.deleteId = id;
    };
    STUserComponent.prototype.delete = function () {
        var _this = this;
        this.isLoading = true;
        return this._http.delete('Http://52.66.246.140:8080/SkillTeck/deleteSTUser/' + this.deleteId)
            .subscribe(function (data) {
            var $toastContent = $('<span>Record has been deleted successfully!!</span>');
            Materialize.toast($toastContent, 2000);
            _this.isLoading = false;
            _this.loadIntialListOfEmplyees();
        }, function (err) {
            console.log('Something went wrong!');
            _this.isLoading = false;
        });
    };
    STUserComponent.prototype.moveNext = function (event, tab) {
        $('.collapsible').collapsible('open', tab);
    };
    STUserComponent.prototype.ngOnInit = function () {
        $("select").material_select();
        $('.collapsible').collapsible();
        $('.modal').modal();
    };
    STUserComponent.prototype.ngAfterViewChecked = function () {
        var self = this;
    };
    STUserComponent.prototype.uploadExcelSheet = function () {
    };
    STUserComponent.prototype.downloadexcel = function () {
    };
    STUserComponent.prototype.downloadexcelfile = function () {
        var url = 'Http://34.93.202.192:8080/SpoorsReports/getAllEmployeesToPrintXL';
        this.downloadXLFile(url).subscribe(function (res) {
            var fileURL = URL.createObjectURL(res);
            window.open(fileURL);
        });
    };
    STUserComponent.prototype.downloadXLFile = function (url) {
        return this._http.get(url, { responseType: _angular_Http__WEBPACK_IMPORTED_MODULE_2__["ResponseContentType"].Blob }).map(function (res) {
            return new Blob([res.blob()], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        });
    };
    STUserComponent.prototype.downloadpdf = function () {
        var url = 'Http://34.93.202.192:8080/SpoorsReports/getAllEmployeesToPrint';
        this.downloadFile(url).subscribe(function (res) {
            var fileURL = URL.createObjectURL(res);
            window.open(fileURL);
        });
    };
    STUserComponent.prototype.downloadFile = function (url) {
        return this._http.get(url, { responseType: _angular_Http__WEBPACK_IMPORTED_MODULE_2__["ResponseContentType"].Blob }).map(function (res) {
            return new Blob([res.blob()], { type: 'application/pdf' });
        });
    };
    STUserComponent.prototype.countEmployeeRecords = function () {
        var _this = this;
        this.isLoading = true;
        return this._http.get('Http://34.93.202.192:8080/Spoors/employeesCount')
            .map(function (res) { return res.json(); })
            .subscribe(function (data) {
            _this.totalEmployees = data.totalRecords;
            console.log('Count of Emplyees --- ' + _this.totalEmployees);
        }, function (err) {
            console.log('Something went wrong!');
        });
        this.isLoading = false;
    };
    STUserComponent.prototype.onFileSelect = function (event) {
        var _this = this;
        console.log('File Change Event !');
        if (event.target.files.length > 0) {
            var file = event.target.files[0];
            var formdata = new FormData();
            formdata.append('file', file);
            return this._http.post('Http://34.93.202.192:8080/SpoorsEmployees/importEmpData', formdata)
                .subscribe(function (res) {
                console.log(res);
                _this.isLoading = false;
                var $toastContent = $('<span>Record has been loaded successfully!!</span>');
                Materialize.toast($toastContent, 2000);
                _this.router.navigate(['/spoorsemployees']);
            }, function (err) {
                var $toastContent = $('<span>' + JSON.parse(err["_body"])[0]["errMessage"] + '</span>');
                Materialize.toast($toastContent, 2000);
                _this.isLoading = false;
            });
        }
    };
    STUserComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-stuser',
            template: __webpack_require__(/*! ./stuser.component.html */ "./src/app/pages/stuser/stuser.component.html"),
            styles: [__webpack_require__(/*! ./stuser.component.css */ "./src/app/pages/stuser/stuser.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _angular_Http__WEBPACK_IMPORTED_MODULE_2__["Http"]])
    ], STUserComponent);
    return STUserComponent;
}());



/***/ }),

/***/ "./src/app/pages/stuser/stuserdetails/stuserdetails.component.css":
/*!************************************************************************!*\
  !*** ./src/app/pages/stuser/stuserdetails/stuserdetails.component.css ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3N0dXNlci9zdHVzZXJkZXRhaWxzL3N0dXNlcmRldGFpbHMuY29tcG9uZW50LmNzcyJ9 */"

/***/ }),

/***/ "./src/app/pages/stuser/stuserdetails/stuserdetails.component.html":
/*!*************************************************************************!*\
  !*** ./src/app/pages/stuser/stuserdetails/stuserdetails.component.html ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"row\">  \n    <nav>\n        <div class=\"nav-wrapper white grey-text text-darken-2\">\n          <div class=\"col s12 grey-text text-darken-2\">\n             <a [routerLink]=\"['../../']\" class=\"breadcrumb grey-text\">Dashboard</a>\n            <a [routerLink]=\"['../']\" class=\"breadcrumb grey-text\">STUser</a>\n            <a [routerLink]=\"['./']\" class=\"breadcrumb active\">Details</a>\n          </div>\n        </div>\n    </nav>\n\n    <div class=\"row\" style=\"padding: 0px 20px\">\n    <ul class=\"collapsible popout z-depth-5\" data-collapsible=\"accordion\">\n      <li>\n        <div class=\"collapsible-header light-green-text text-darken-4 active grey lighten-5\" style=\"font-size: 20px\"><i class=\"material-icons amber-text text-darken-4\" style=\"font-size: 30px\">looks_one</i>\n         STUserProfile</div>\n        <div class=\"collapsible-body\">\n  \n          <form >\n                    <div class=\"row\">\n\n                      <div class=\"input-field col s12 m6  l4 \">\n                        <input  id=\"firstName\" type=\"text\" class=\"validate\" [(ngModel)]=\"firstName\" name=\" firstName\">\n                        <label class=\"active\" for=\"firstName\">FirstName</label>\n                      </div>\n\n                      <div class=\"input-field col s12 m6  l4 \">\n                        <input  id=\"middleName\" type=\"text\" class=\"validate\" [(ngModel)]=\"middleName\" name=\"middleName\">\n                          <label class=\"active\" for=\" middleName\">MiddleName</label>\n                        </div>  \n\n                        <div class=\"input-field col s12 m6  l4 \">\n                          <input  id=\"lastName\" type=\"text\" class=\"validate\" [(ngModel)]=\"lastName\" name=\"lastName\">\n                          <label class=\"active\" for=\"lastName\">LastName</label>\n                        </div> \n\n                        <div class=\"input-field col s12 m6  l4 \">\n                        <input  id=\"gender\" type=\"text\" class=\"validate\" [(ngModel)]=\"gender\" name=\"gender\">\n                          <label class=\"active\" for=\"gender\">Gender</label>\n                        </div> \n\n                        <div class=\"input-field col s12 m6  l4 \">\n                          <input  id=\"firebaseUrl\" type=\"text\" class=\"validate\" [(ngModel)]=\"firebaseUrl\" name=\"firebaseUrl\">\n                          <label class=\"active\" for=\"firebaseUrl\">FirebaseUrl</label>\n                        </div>\n\n                        <div class=\"input-field col s12 m6  l4 \">\n                          <input  id=\"permanent_Address\" type=\"text\" class=\"validate\" [(ngModel)]=\"permanent_Address\" name=\"permanent_Address\">\n                          <label class=\"active\" for= \"permanent_Address\">PermanentAddress</label>\n                        </div> \n\n                        <div class=\"input-field col s12 m6  l4 \">\n                          <input  id=\"pA_City\" type=\"text\" class=\"validate\" [(ngModel)]=\"pA_City\" name=\"pA_City\">\n                          <label class=\"active\" for=\"pA_City\">PACity</label>\n                        </div>  \n                                               \n                        \n                                              \n                        <div class=\"input-field col s12 m6  l4 \">\n                          <input  id=\"pA_State\" type=\"text\" class=\"validate\" [(ngModel)]=\"pA_State\" name=\"pA_State\">\n                          <label class=\"active\" for=\"pA_State\">PAState</label>\n                        </div> \n\n                        <div class=\"input-field col s12 m6  l4 \">\n                          <input  id=\"pin\" type=\"text\" class=\"validate\" [(ngModel)]=\"pin\" name=\"pin\">\n                          <label class=\"active\" for=\"pin\">PIN</label>\n                        </div> \n\n                         <div class=\"input-field col s12 m6  l4 \">\n                          <input  id=\"occupation\" type=\"text\" class=\"validate\" [(ngModel)]=\"occupation\" name=\"occupation\">\n                          <label class=\"active\" for=\"occupation\">Occupation</label>\n                        </div> \n\n                         <div class=\"input-field col s12 m6  l4 \">\n                         <input  id=\"email\" type=\"text\" class=\"validate\" [(ngModel)]=\"email\" name=\"email\">\n                          <label class=\"active\" for=\"email\">Email</label>\n                        </div> \n\n                        <div class=\"input-field col s12 m6  l4 \">\n                         <input  id=\"mobileNumber\" type=\"text\" class=\"validate\" [(ngModel)]=\"mobileNumber\" name=\"mobileNumber\">\n                          <label class=\"active\" for=\"mobileNumber\">MobileNumber</label>\n                        </div> \n\n                        \n                        <div class=\"input-field col s12 m6  l4 \">\n                         <input  id=\"dob\" type=\"text\" class=\"validate\" [(ngModel)]=\"dob\" name=\"dob\">\n                          <label class=\"active\" for=\"dob\">DOB</label>\n                        </div> \n\n                        <div class=\"input-field col s12 m6  l4 \">\n                         <input  id=\"password\" type=\"text\" class=\"validate\" [(ngModel)]=\"password\" name=\"password\">\n                          <label class=\"active\" for=\"password\">Password</label>\n                        </div> \n\n\n                        <div class=\"input-field col s12 m6  l4 \">\n                         <input  id=\"confPassword\" type=\"text\" class=\"validate\" [(ngModel)]=\"confPassword\" name=\"confPassword\">\n                          <label class=\"active\" for=\"confPassword\">ConfirmPassword</label>\n                        </div> \n\n                        <div class=\"input-field col s12 m6  l4 \">\n                         <input  id=\"otpGen\" type=\"text\" class=\"validate\" [(ngModel)]=\"otpGen\" name=\"otpGen\">\n                          <label class=\"active\" for=\"otpGen\">OTPGenerator</label>\n                        </div> \n\n                         <div class=\"input-field col s12 m6  l4 \">\n                         <input  id=\"otpConfirm\" type=\"text\" class=\"validate\" [(ngModel)]=\"otpConfirm\" name=\"otpConfirm\">\n                          <label class=\"active\" for=\"otpConfirm\">OTPConfirm</label>\n                        </div> \n                         \n                         \n\n                        \n                         \n                       \n                    </div>\n                    <button class=\"btn waves-effect waves-light cyan\"  (click)=\"createReminder()\" name=\"action\">Save                       <i class=\"material-icons right\">add</i>\n                      </button> \n                      <div class=\"progress\" *ngIf=\"isLoading\">\n                          <div class=\"indeterminate\"></div>\n                      </div>\n                    </form>\n        </div>\n      </li>\n\n     \n    </ul>   \n  </div> \n  \n  </div>\n        "

/***/ }),

/***/ "./src/app/pages/stuser/stuserdetails/stuserdetails.component.ts":
/*!***********************************************************************!*\
  !*** ./src/app/pages/stuser/stuserdetails/stuserdetails.component.ts ***!
  \***********************************************************************/
/*! exports provided: STUserdetailsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "STUserdetailsComponent", function() { return STUserdetailsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _angular_Http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/Http */ "./node_modules/@angular/Http/esm5/http.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/esm5/router.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs/_esm5/add/operator/map.js");





var STUserdetailsComponent = /** @class */ (function () {
    function STUserdetailsComponent(_router, _http, route) {
        this._http = _http;
        this.route = route;
        this.isLoading = false;
        this.router = _router;
    }
    STUserdetailsComponent.prototype.createReminder = function () {
        var _this = this;
        this.isLoading = true;
        var data = {
            "firstName": this.firstName,
            "middleName": this.middleName,
            "lastName": this.lastName,
            "gender": this.gender,
            "firebaseUrl": this.firebaseUrl,
            "permanent_Address": this.permanent_Address,
            "pA_City": this.pA_City,
            "pA_State": this.pA_State,
            "pin": this.pin,
            "occupation": this.occupation,
            "email": this.email,
            "mobileNumber": this.mobileNumber,
            "dob": this.dob,
            "password": this.password,
            "confPassword": this.confPassword,
            "otpGen": this.otpGen,
            "otpConfirm": this.otpConfirm,
            "isActive": 'y',
            "isAprroved": 'y',
        };
        if (this.firstName == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>firstName is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.middleName == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>MiddleName is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.lastName == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>LastName is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.gender == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>Gender is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.firebaseUrl == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>firebaseUrl is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.permanent_Address == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>permanent_Address is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.pA_City == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>pA_City is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.pA_State == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>pA_State is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.pin == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>pin is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.occupation == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>occupation is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.email == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>Email is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.mobileNumber == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>mobileNumber is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.dob == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>dob is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.password == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>password is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.confPassword == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>confPassword is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.otpGen == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>otpGen is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.otpConfirm == null) {
            // this.isLoading = false;
            var $toastContent = $('<span>otpConfirm is Mandatory!</span>');
            this.isLoading = false;
            Materialize.toast($toastContent, 2000);
            return;
        }
        if (this.editId && this.editId !== "" && this.editId !== "None") {
            data["id"] = this.editId;
            return this._http.put('Http://52.66.246.140:8080/SkillTeck/updateSTUser/', data)
                .subscribe(function (res) {
                console.log(res);
                _this.isLoading = false;
                var $toastContent = $('<span>Record has been saved successfully!!</span>');
                Materialize.toast($toastContent, 2000);
                _this.router.navigate(['/stuser']);
            }, function (err) {
                var $toastContent = $('<span>' + JSON.parse(err["_body"])[0]["errMessage"] + '</span>');
                Materialize.toast($toastContent, 2000);
                _this.isLoading = false;
            });
        }
        else {
            return this._http.post('Http://52.66.246.140:8080/SkillTeck/addSTUser/', data)
                .subscribe(function (res) {
                console.log(res);
                _this.isLoading = false;
                var $toastContent = $('<span>Record has been saved successfully!!</span>');
                Materialize.toast($toastContent, 2000);
                _this.router.navigate(['/stuser']);
            }, function (err) {
                var $toastContent = $('<span>' + JSON.parse(err["_body"])[0]["errMessage"] + '</span>');
                Materialize.toast($toastContent, 2000);
                _this.isLoading = false;
            });
        }
    };
    STUserdetailsComponent.prototype.moveNext = function (event, tab) {
        $('.collapsible').collapsible('open', tab);
    };
    STUserdetailsComponent.prototype.ngAfterViewInit = function () {
        this.things.changes.subscribe(function (t) {
            $("select").material_select();
        });
    };
    STUserdetailsComponent.prototype.ngAfterViewChecked = function () {
        Materialize.updateTextFields();
    };
    STUserdetailsComponent.prototype.ngOnInit = function () {
        var _this = this;
        $("select").material_select();
        $('.collapsible').collapsible({
            onOpen: function (el) { Materialize.updateTextFields(); }
        });
        this.route
            .queryParamMap
            .map(function (params) { return params.get('session_id') || 'None'; })
            .subscribe(function (val) { return _this.editId = val; });
        console.log(this.editId);
        if (this.editId && this.editId !== "" && this.editId !== "None") {
            this.isLoading = true;
            return this._http.get('Http://52.66.246.140:8080/SkillTeck/getSTUserById/' + this.editId)
                .map(function (res) { return res.json(); })
                .subscribe(function (data) {
                var record = data[0];
                _this.firstName = record["firstName"];
                _this.middleName = record["middleName"];
                _this.lastName = record["lastName"];
                _this.gender = record["gender"];
                _this.firebaseUrl = record["firebaseUrl"];
                _this.permanent_Address = record["permanent_Address"];
                _this.pA_City = record["pA_City"];
                _this.pA_State = record["pA_State"];
                _this.pin = record["pin"];
                _this.occupation = record["occupation"];
                _this.email = record["email"];
                _this.mobileNumber = record["mobileNumber"];
                _this.dob = record["dob"];
                _this.password = record["password"];
                _this.confPassword = record["confPassword"];
                _this.otpGen = record["otpGen"];
                _this.otpConfirm = record["otpConfirm"];
                $("select").material_select();
                Materialize.updateTextFields();
                _this.isLoading = false;
                //debugger;
            }, function (err) {
                console.log('Something went wrong!');
                _this.isLoading = false;
            });
        }
        Materialize.updateTextFields();
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChildren"])('allTheseThings'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], STUserdetailsComponent.prototype, "things", void 0);
    STUserdetailsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-stuserdetails',
            template: __webpack_require__(/*! ./stuserdetails.component.html */ "./src/app/pages/stuser/stuserdetails/stuserdetails.component.html"),
            styles: [__webpack_require__(/*! ./stuserdetails.component.css */ "./src/app/pages/stuser/stuserdetails/stuserdetails.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"], _angular_Http__WEBPACK_IMPORTED_MODULE_2__["Http"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]])
    ], STUserdetailsComponent);
    return STUserdetailsComponent;
}());



/***/ }),

/***/ "./src/app/pagination/pagination.component.css":
/*!*****************************************************!*\
  !*** ./src/app/pagination/pagination.component.css ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BhZ2luYXRpb24vcGFnaW5hdGlvbi5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/pagination/pagination.component.html":
/*!******************************************************!*\
  !*** ./src/app/pagination/pagination.component.html ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"pagination\" *ngIf=\"count > 0\">\n\t<div class=\"description\" style=\"font-size: 13px;\n  color: #666;\">\n\t\t<span class=\"page-counts\">{{ getMin() }} - {{ getMax() }} of {{ count }}</span>\n\t\t<span class=\"page-totals\">({{ totalPages() }} pages)</span>\n\t</div>\n\t<ul class=\"pagination\">\n\t\t<li class=\"waves-effect\" (click)=\"onPrev()\" [ngClass]=\"{ 'disabled': page === 1 || loading }\"><a ><i class=\"material-icons\">chevron_left</i></a></li>\n\t\t<li class=\"waves-effect\"\n\t\t\t*ngFor=\"let pageNum of getPages()\"\n\t\t\t(click)=\"onPage(pageNum)\"\n\t\t\t[ngClass]=\"{'active pink darken-4': pageNum === page, 'disabled': loading}\"><a>{{ pageNum }}</a></li>\n\n    <li class=\"waves-effect\" (click)=\"onNext(true)\"  [ngClass]=\"{ 'disabled': lastPage() || loading }\"><a><i class=\"material-icons\">chevron_right</i></a></li>\n\t</ul>\n</div>\n\n"

/***/ }),

/***/ "./src/app/pagination/pagination.component.ts":
/*!****************************************************!*\
  !*** ./src/app/pagination/pagination.component.ts ***!
  \****************************************************/
/*! exports provided: PaginationComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PaginationComponent", function() { return PaginationComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");


var PaginationComponent = /** @class */ (function () {
    function PaginationComponent() {
        this.goPrev = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.goNext = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.goPage = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
    }
    PaginationComponent.prototype.getMin = function () {
        return ((this.perPage * this.page) - this.perPage) + 1;
    };
    PaginationComponent.prototype.getMax = function () {
        var max = this.perPage * this.page;
        if (max > this.count) {
            max = this.count;
        }
        return max;
    };
    PaginationComponent.prototype.onPage = function (n) {
        this.goPage.emit(n);
    };
    PaginationComponent.prototype.onPrev = function () {
        if (this.page > 1) {
            this.goPrev.emit(true);
        }
    };
    PaginationComponent.prototype.onNext = function (next) {
        if (!this.lastPage()) {
            this.goNext.emit(next);
        }
    };
    PaginationComponent.prototype.totalPages = function () {
        return Math.ceil(this.count / this.perPage) || 0;
    };
    PaginationComponent.prototype.lastPage = function () {
        return this.perPage * this.page > this.count;
    };
    PaginationComponent.prototype.getPages = function () {
        var c = Math.ceil(this.count / this.perPage);
        var p = this.page || 1;
        var pagesToShow = this.pagesToShow || 9;
        var pages = [];
        pages.push(p);
        var times = pagesToShow - 1;
        for (var i = 0; i < times; i++) {
            if (pages.length < pagesToShow) {
                if (Math.min.apply(null, pages) > 1) {
                    pages.push(Math.min.apply(null, pages) - 1);
                }
            }
            if (pages.length < pagesToShow) {
                if (Math.max.apply(null, pages) < c) {
                    pages.push(Math.max.apply(null, pages) + 1);
                }
            }
        }
        pages.sort(function (a, b) { return a - b; });
        return pages;
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Number)
    ], PaginationComponent.prototype, "page", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Number)
    ], PaginationComponent.prototype, "count", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Number)
    ], PaginationComponent.prototype, "perPage", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Boolean)
    ], PaginationComponent.prototype, "loading", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Number)
    ], PaginationComponent.prototype, "pagesToShow", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], PaginationComponent.prototype, "goPrev", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], PaginationComponent.prototype, "goNext", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], PaginationComponent.prototype, "goPage", void 0);
    PaginationComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'my-pagination',
            template: __webpack_require__(/*! ./pagination.component.html */ "./src/app/pagination/pagination.component.html"),
            styles: [__webpack_require__(/*! ./pagination.component.css */ "./src/app/pagination/pagination.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], PaginationComponent);
    return PaginationComponent;
}());



/***/ }),

/***/ "./src/app/services/auth.service.ts":
/*!******************************************!*\
  !*** ./src/app/services/auth.service.ts ***!
  \******************************************/
/*! exports provided: AuthService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthService", function() { return AuthService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var rxjs_BehaviorSubject__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/BehaviorSubject */ "./node_modules/rxjs/_esm5/BehaviorSubject.js");
/* harmony import */ var _angular_Http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/Http */ "./node_modules/@angular/Http/esm5/http.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs/_esm5/add/operator/map.js");





var AuthService = /** @class */ (function () {
    function AuthService(_http) {
        this._http = _http;
        this.event = new rxjs_BehaviorSubject__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"](0);
        this.loginEvent$ = this.event.asObservable();
    }
    AuthService.prototype.login123 = function (username, password) {
        // let logProcess = this._http.post('Http://musictrainer.smartx.services:8080/ICMS_UserManagement/validateUsers?userName='+username+'&password='+password, {});
        var _this = this;
        var logProcess = this._http.post('Http://musictrainer.smartx.services:8080/NoteTrainer/validateUsers?userName=' + username + '&password=' + password, {});
        //logProcess.subscribe(() => this.event.next(1));
        logProcess.subscribe(function (res) {
            var result = res.json()[0];
            console.log(result);
            localStorage.setItem('currentUser', result.firstname + ' ' + result.lastname);
            localStorage.setItem('userid', result.userid);
            localStorage.setItem('authToken', result.usertoken);
            localStorage.setItem('role', result.role);
            _this.event.next(1);
            //this.router.navigate(['/dashboard']);
        }, function (err) {
            var $toastContent = $('<span class=""><i class="material-icons left red-text">error</i>Please provide a valid username and password</span>');
            Materialize.toast($toastContent, 2000);
            _this.event.next(1);
        });
        //  this.router.navigate(['/dashboard']);
        return logProcess;
        // if (username === "admin" && password === "secure") {
        //   localStorage.setItem('currentUser', username);
        //   this.event.next(1);
        //   return true;
        // }
        // return false;
    };
    AuthService.prototype.login = function (username, password) {
         if (username === "capco" && password === "welcome123") {
             localStorage.setItem('currentUser', username);
            localStorage.setItem('role', "0");
            this.event.next(1);
            return true;
        }
        else {
            var $toastContent = $('<span class=""><i class="material-icons left red-text">error</i>Invalid Username / Password</span>');
            Materialize.toast($toastContent, 3000);
        }
        return false;
    };
    AuthService.prototype.recover = function (email) {
        var _this = this;
         var logProcess = this._http.post('Http://musictrainer.smartx.services:8080/NoteTrainer/recoverPassword?email=' + email, {});
        //logProcess.subscribe(() => this.event.next(1));
        logProcess.subscribe(function (res) {
            var result = res.json()[0];
            var $toastContent = $('<span class=""><i class="material-icons left red-text">error</i>Password Sent your registered Email</span>');
            Materialize.toast($toastContent, 3000);
            _this.event.next(1);
            //this.router.navigate(['/dashboard']);
        }, function (err) {
            var $toastContent = $('<span class=""><i class="material-icons left red-text">error</i>Please provide a valid Email</span>');
            Materialize.toast($toastContent, 2000);
            _this.event.next(1);
        });
        //  this.router.navigate(['/dashboard']);
        return logProcess;
        // if (username === "admin" && password === "secure") {
        //   localStorage.setItem('currentUser', username);
        //   this.event.next(1);
        //   return true;
        // }
        // return false;
    };
    AuthService.prototype.logout = function () {
        // remove user from local storage to log user out
        localStorage.removeItem('currentUser');
        this.event.next(0);
    };
    AuthService.prototype.isAuthenicated = function () {
        var currentUser = localStorage.getItem('currentUser');
        if (currentUser && currentUser !== "") {
            return true;
        }
        return false;
    };
    AuthService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_Http__WEBPACK_IMPORTED_MODULE_3__["Http"]])
    ], AuthService);
    return AuthService;
}());



/***/ }),

/***/ "./src/app/services/httpcalls.service.ts":
/*!***********************************************!*\
  !*** ./src/app/services/httpcalls.service.ts ***!
  \***********************************************/
/*! exports provided: HhttpcallsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HhttpcallsService", function() { return HhttpcallsService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _angular_common_Http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/Http */ "./node_modules/@angular/common/esm5/http.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs/_esm5/add/operator/map.js");
/* harmony import */ var rxjs_add_operator_toPromise__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/add/operator/toPromise */ "./node_modules/rxjs/_esm5/add/operator/toPromise.js");
/* harmony import */ var rxjs_add_operator_toPromise__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(rxjs_add_operator_toPromise__WEBPACK_IMPORTED_MODULE_4__);





var HhttpcallsService = /** @class */ (function () {
    function HhttpcallsService(Http) {
        this.Http = Http;
        this.resturl = 'Http://musictrainer.smartx.services:8080/NoteTrainer/';
    }
    HhttpcallsService.prototype.getAllCourse = function () {
        return this.Http.get('Http://musictrainer.smartx.services:8080/NoteTrainer/getAllCollegeCourses')
            .toPromise()
            .then(function (res) { console.log('In getAllCourse ' + res); return res; });
    };
    HhttpcallsService.prototype.getAllSemester = function () {
        return this.Http.get('Http://musictrainer.smartx.services:8080/NoteTrainer/getAllCollegeSemesters')
            .toPromise()
            .then(function (res) { console.log('In getAllSemester ' + res); return res; });
    };
    HhttpcallsService.prototype.getCourseTimetable = function (courseId, SemesterId, WeekId) {
        return this.Http.get('Http://musictrainer.smartx.services:8080/NoteTrainer/timetable/' + courseId + '/' + SemesterId + '/' + WeekId)
            .toPromise()
            .then(function (res) { console.log('In getCourseTimetable ' + res); return res; });
    };
    HhttpcallsService.prototype.addCourseTimeTable = function (itemObj) {
        return this.Http.post('Http://musictrainer.smartx.services:8080/NoteTrainer/timetable/', itemObj)
            .toPromise();
    };
    HhttpcallsService.prototype.updateCourseTimeTable = function (itemObj) {
        return this.Http.put('Http://musictrainer.smartx.services:8080/NoteTrainer/timetable/', itemObj)
            .toPromise();
    };
    HhttpcallsService.prototype.getAllWorkWeeks = function () {
        return this.Http.get('Http://musictrainer.smartx.services:8080/NoteTrainer/getAllWorkWeeks')
            .toPromise()
            .then(function (res) { console.log('In getAllWorkWeeks ' + res); return res; });
    };
    HhttpcallsService.prototype.getWorkingDaysForWeek = function (weekId) {
        return this.Http.get('Http://musictrainer.smartx.services:8080/NoteTrainer/getWorkingDaysForWeek/' + weekId)
            .toPromise()
            .then(function (res) { console.log('In getWorkingDaysForWeek ' + res); return res; });
    };
    HhttpcallsService.prototype.getCourseSubjects = function (courseId) {
        return this.Http.get('Http://musictrainer.smartx.services:8080/NoteTrainer/getClassSubjectsByGradeId?id='
            + courseId)
            .toPromise()
            .then(function (res) { console.log('In getCourseSubjects ' + res); return res; });
    };
    HhttpcallsService.prototype.getAllItems = function (itemId) {
        return this.Http.get(this.resturl + 'getAllItems/' + itemId)
            .toPromise()
            .then(function (res) { console.log('In getAllItems ' + res); return res; });
    };
    HhttpcallsService.prototype.getAllItemCount = function () {
        return this.Http.get(this.resturl + 'reports/allitemcount')
            .toPromise()
            .then(function (res) { console.log('In getAllItemCount ' + res); return res; });
    };
    HhttpcallsService.prototype.getTenYearOldData = function () {
        return this.Http.get(this.resturl + 'reports/tenyearsolditem')
            .toPromise()
            .then(function (res) { console.log('In getTenYearOldData ' + res); return res; });
    };
    HhttpcallsService.prototype.getAMCList = function () {
        return this.Http.get(this.resturl + 'reports/amclist')
            .toPromise()
            .then(function (res) { console.log('In getAMCList ' + res); return res; });
    };
    HhttpcallsService.prototype.getCalibiratedList = function () {
        return this.Http.get(this.resturl + 'reports/calibratedlist')
            .toPromise()
            .then(function (res) { console.log('In getCalibiratedList ' + res); return res; });
    };
    HhttpcallsService.prototype.getLifeCompletedList = function () {
        return this.Http.get(this.resturl + 'reports/lifecompleted')
            .toPromise()
            .then(function (res) { console.log('In getLifeCompletedList ' + res); return res; });
    };
    HhttpcallsService.prototype.getNextMonthMaintenance = function () {
        return this.Http.get(this.resturl + 'reports/nextmonthmaintenance')
            .toPromise()
            .then(function (res) { console.log('In getNextMonthMaintenance ' + res); return res; });
    };
    HhttpcallsService.prototype.getSoftwareRenewal = function () {
        return this.Http.get(this.resturl + 'reports/softwarelist')
            .toPromise()
            .then(function (res) { console.log('In getSoftwareRenewal ' + res); return res; });
    };
    HhttpcallsService.prototype.getFirefighting = function () {
        return this.Http.get(this.resturl + 'reports/fireextservicelist')
            .toPromise()
            .then(function (res) { console.log('In getFirefighting ' + res); return res; });
    };
    HhttpcallsService.prototype.getVechicleDetails = function () {
        return this.Http.get(this.resturl + 'reports/vehicleservicelist')
            .toPromise()
            .then(function (res) { console.log('In getVechicleDetails ' + res); return res; });
    };
    HhttpcallsService.prototype.getEquipmentFailure = function () {
        return this.Http.get(this.resturl + 'reports/brokenlist')
            .toPromise()
            .then(function (res) { console.log('In getEquipmentFailure ' + res); return res; });
    };
    HhttpcallsService.prototype.getPurchaseList = function () {
        return this.Http.get(this.resturl + 'reports/purchaseandrenewallist')
            .toPromise()
            .then(function (res) { console.log('In getPurchaseList ' + res); return res; });
    };
    HhttpcallsService.prototype.getMaintenanceCost = function () {
        return this.Http.get(this.resturl + 'reports/amccostlist')
            .toPromise()
            .then(function (res) { console.log('In getMaintenanceCost ' + res); return res; });
    };
    HhttpcallsService.prototype.getFourYearExp = function () {
        return this.Http.get(this.resturl + 'reports/fouryearmoneyspentitems')
            .toPromise()
            .then(function (res) { console.log('In getFourYearExp ' + res); return res; });
    };
    HhttpcallsService.prototype.addItems = function (itemObj) {
        return this.Http.post(this.resturl + 'addItem', itemObj)
            .toPromise();
    };
    HhttpcallsService.prototype.updateItems = function (itemObj) {
        return this.Http.put(this.resturl + 'updateItem', itemObj)
            .toPromise();
    };
    HhttpcallsService.prototype.deleteItems = function (typeid, id) {
        return this.Http.delete(this.resturl + 'deleteItem/' + typeid + '/' + id)
            .toPromise();
    };
    HhttpcallsService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_Http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
    ], HhttpcallsService);
    return HhttpcallsService;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.
var environment = {
    production: false
};


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/esm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/esm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! D:\Microservices\Skilltech\SkillTeckUI\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map