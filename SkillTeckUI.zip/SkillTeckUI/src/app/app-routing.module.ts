import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
 
 
import { LoginComponent } from './login/login.component';
 
 
 
import { STUserComponent  } from './pages/stuser/stuser.component';
import { STUserdetailsComponent  } from './pages/stuser/stuserdetails/stuserdetails.component';

import { STCoachComponent  } from './pages/stcoach/stcoach.component';
import { STCoachdetailsComponent } from './pages/stcoach/stcoachdetails/stcoachdetails.component';

  
const routes: Routes = [
  { path: '', redirectTo: '/stuser', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
    
        
  { path: 'stuser', component: STUserComponent },
  { path: 'stuser/stuserdetails', component: STUserdetailsComponent },

  { path: 'stcoach', component: STCoachComponent },
  { path: 'stcoach/stcoachdetails', component: STCoachdetailsComponent },
   
  

 ]; 

@NgModule({
  exports: [RouterModule],
  imports: [RouterModule.forRoot(routes)]
})
export class AppRoutingModule { }