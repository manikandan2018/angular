import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { STUserdetailsComponent } from './stuserdetails.component';

describe('STUserdetailsComponent', () => {
  let component: STUserdetailsComponent;
  let fixture: ComponentFixture<STUserdetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ STUserdetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(STUserdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
