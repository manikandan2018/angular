import 'rxjs/add/operator/toPromise';

import { HttpClient } from '@angular/common/Http';
import { Injectable } from '@angular/core';

@Injectable()
export class EventService {

    constructor(private Http: HttpClient) { }
  private  eventServiceURL:string  = 'Http://musictrainer.smartx.services:8080/ICMSEventSchedule/events';

  getCourses() {
    return this.Http.get<any>('Http://musictrainer.smartx.services:8080/ICMSCollegeCourse/getAllCollegeCourses')
      .toPromise()
      .then(res => { console.log("In Service "+res); return <any[]>res})
      ;
    }
    getSemesters() {
      return this.Http.get<any>('Http://musictrainer.smartx.services:8080/ICMSCollegeSemester/getAllCollegeSemesters')
        .toPromise()
        .then(res => { console.log("In Service "+res); return <any[]>res})
        ;
      }
   


    getEvents(course,semester,classId) {
    return this.Http.get<any>(this.eventServiceURL+'?course='+course+'&semester='+semester+'&classId='+classId)
      .toPromise()
      .then(res => { console.log("In Service "+res); return <any[]>res})
      ;
    }

    addEvents(eventData: any) {
      return this.Http.post<any>(this.eventServiceURL,eventData)
        .toPromise()
        .then(res => { console.log("In Service "+res); return <any[]>res})
        .catch(this.handleError) ;
      }
      updateEvents(eventData: any) {
        return this.Http.put<any>(this.eventServiceURL,eventData)
          .toPromise()
          .then(res => { console.log("In Service "+res); return <any[]>res})
          .catch(this.handleError) ;
        }
        deleteEvents(eventData: any) {
          return this.Http.delete<any>(this.eventServiceURL+'/'+eventData)
            .toPromise()
            .then(res => { console.log("In Service "+res); return <any[]>res})
            .catch(this.handleError) ;
          }
      private handleError(error: any): Promise<any> {
        console.error('An error occurred', error);
        return Promise.reject(error.message || error);
    }
}