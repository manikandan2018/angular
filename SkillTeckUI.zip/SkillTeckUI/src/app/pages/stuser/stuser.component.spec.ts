import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import {STUserComponent } from './stuserdetails.component';

describe('STUserComponent', () => {
  let component:STUserComponent;
  let fixture: ComponentFixture<STUserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [STUserComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(STUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
