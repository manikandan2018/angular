import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { STCoachdetailsComponent } from './stcoachdetails.component';

describe('STCoachdetailsComponent', () => {
  let component: STCoachdetailsComponent;
  let fixture: ComponentFixture<STCoachdetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ STCoachdetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(STCoachdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
