import { Component, OnInit } from '@angular/core';
import { Http, Response, Headers ,ResponseContentType} from '@angular/Http';
import {Router,  NavigationExtras} from '@angular/router';
import { FormBuilder, FormGroup } from '@angular/forms';

import 'rxjs/add/operator/map';

declare var $: any;
declare var Materialize: any;

@Component({
  selector: 'app-stuser',
  templateUrl: './stuser.component.html',
  styleUrls: ['./stuser.component.css']
})
export class STUserComponent implements  OnInit {

  records: any[] = [];
  isLoading: boolean = false;
  router: Router;
  deleteId: string;
totalEmployees: string;
  uploadForm: FormGroup;  

 total = 0;
  page = 1;
  limit = 10;
  goToPage(n: number): void {
    this.page = n;
    this.loadIntialListOfEmplyees();
  }

  onNext(): void {
    this.page++;
    this.loadIntialListOfEmplyees();
  }

  onPrev(): void {
    this.page--;
    this.loadIntialListOfEmplyees();
  }

  
  constructor(_router: Router, private _http: Http) {
    this.router = _router;
    this.loadIntialListOfEmplyees();
    this.countEmployeeRecords();
   }

   private loadIntialListOfEmplyees() {
     this.isLoading = true;
     return this._http.get('Http://52.66.246.140:8080/SkillTeck/listSTUsers?page=' + this.page + '&size=' + this.limit)
    .map((res: Response) => res.json())
      .subscribe(data => {
        this.records = data.stuserList;
        this.total = data.totalRecords;
        console.log(this.records);
        this.isLoading = false;
    }, 
    err => { 
      console.log('Something went wrong!');
      this.isLoading = false;      
    });
   }

 public edit(id: string) {
  let navigationExtras: NavigationExtras = {
    queryParams: { 'session_id': id },
    skipLocationChange: true
  };   
    this.router.navigate(['/stuser/stuserdetails'], navigationExtras);
  }   

  public selectForDelete(id: string) {
      this.deleteId = id;
  }    

  public delete() {
    this.isLoading = true;
    return this._http.delete('Http://52.66.246.140:8080/SkillTeck/deleteSTUser/' + this.deleteId)    
     .subscribe(data => {            
          var $toastContent = $('<span>Record has been deleted successfully!!</span>');
          Materialize.toast($toastContent, 2000);
            this.isLoading = false;
            this.loadIntialListOfEmplyees();
    }, 
    err => {
      console.log('Something went wrong!');
      this.isLoading = false;      
    });
  }

  public moveNext(event, tab) {
    $('.collapsible').collapsible('open', tab);
  }

  ngOnInit() {
    $("select").material_select();
    $('.collapsible').collapsible(); 
    $('.modal').modal();
  }

  ngAfterViewChecked() {
    let self = this;
    
  }

uploadExcelSheet(): any {
  
  }


downloadexcel(): any {
  
  }

downloadexcelfile(): any {
    let url = 'Http://34.93.202.192:8080/SpoorsReports/getAllEmployeesToPrintXL';
    this.downloadXLFile(url).subscribe(
      (res) => {
        let fileURL = URL.createObjectURL(res);
        window.open(fileURL);
      }
    );
  }

  downloadXLFile(url): any {
    return this._http.get(url, { responseType: ResponseContentType.Blob }).map(
      (res) => {
        return new Blob([res.blob()], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      });
  }

   downloadpdf(): any {
    let url = 'Http://34.93.202.192:8080/SpoorsReports/getAllEmployeesToPrint';
    this.downloadFile(url).subscribe(
      (res) => {
        let fileURL = URL.createObjectURL(res);
        window.open(fileURL);
      }
    );
  }
  downloadFile(url): any {
    return this._http.get(url, { responseType: ResponseContentType.Blob }).map(
      (res) => {
        return new Blob([res.blob()], { type: 'application/pdf' });
      });
  }


countEmployeeRecords() {
     this.isLoading = true;
     
     return this._http.get('Http://34.93.202.192:8080/Spoors/employeesCount')
       .map((res: Response) => res.json())
      .subscribe(data => {
        this.totalEmployees = data.totalRecords;
        console.log('Count of Emplyees --- '+this.totalEmployees);
       },
      err => {
        console.log('Something went wrong!');
       });
       this.isLoading = false;
  }


 onFileSelect(event){
    console.log('File Change Event !');
if (event.target.files.length > 0) {
      const file = event.target.files[0];
      const formdata: FormData = new FormData();
    formdata.append('file', file);
 return this._http.post('Http://34.93.202.192:8080/SpoorsEmployees/importEmpData', formdata)
        .subscribe(
        res => {
          console.log(res);
          this.isLoading = false;
          var $toastContent = $('<span>Record has been loaded successfully!!</span>');
          Materialize.toast($toastContent, 2000);
          this.router.navigate(['/spoorsemployees']);
        },
        err => {
          var $toastContent = $('<span>'+JSON.parse(err["_body"])[0]["errMessage"]+'</span>');
          Materialize.toast($toastContent, 2000);            
          this.isLoading = false;
        }
        );


    }
  }
}



