import { Component, OnInit } from '@angular/core';
import { EventService } from './EventService';
import { SelectItem } from 'primeng/api';
import { Message } from 'primeng/api';
import { MessageService } from 'primeng/components/common/messageservice';
import { Http, Response, Headers } from '@angular/Http';

@Component({
    selector: 'app-schedulecmp',
    templateUrl: './schedulecmp.component.html',
    styleUrls: ['./schedulecmp.component.css']
})

export class SchedulecmpComponent implements OnInit {

    constructor(private eventService: EventService,private messageService: MessageService,private _http: Http) {

    this.loadEvents();

     }

     public loadEvents(){


 return this._http.get('Http://182.76.65.30:9090/ICMSReminder/getAllICMSEventSchedulers')
         .map((res: Response) => res.json())
         .subscribe(data => {
                this.records = data.courseSubjectList;
                      console.log(this.records);
   

     });
     }
    msgs: Message[] = [];
    events: any[];
    displayDialog: boolean;
    isEdit: boolean;
    selectedCourse: any;
    courses: any[] = [];
    semester : any[]=[];
    ClassNames : any[]=[];
    selectedSemester:any;
    selectedClass:any;
    classValue : string;
    semesterValue:string;
    courseValue:string;
      records: any[] = [];

    eventModel = {
        "title": "",
        "start": null,
        "end": null,
        "course": "",
        "semester": "",
        "classId": "", "eventid": ""
    };
    header: any;
    call(event) {
        
        this.eventModel.title = event.calEvent.title; debugger;
        this.eventModel.start = new Date(event.calEvent.start);
        this.eventModel.end = new Date(event.calEvent.end);
        this.eventModel.classId = event.calEvent.classId;
        this.eventModel.semester = event.calEvent.semester;
        this.eventModel.course = event.calEvent.course;
        this.eventModel.eventid = event.calEvent.eventid;
        this.displayDialog = true;
        this.isEdit = true;
    }

    handleAdd(event) {
        this.isEdit = false;
        this.eventModel = {
            "title": "",
            "start": null,
            "end": null,
            "course": "",
            "semester": "",
            "classId": "", "eventid": ""
        };
        this.displayDialog = true;
    }
    handleSave(event) {
        this.eventModel.course = this.courseValue;
        this.eventModel.semester = this.semesterValue;
        this.eventModel.classId = this.classValue;

        console.log(this.eventModel);

        if (this.isEdit) {
            this.eventService.updateEvents(this.eventModel).then(events => { this.eventService.getEvents(this.courseValue,this.semesterValue,this.classValue).then(events => { console.log(events); this.events = events; this.msgs.push({ severity: 'info', summary: 'Info Message', detail: 'Event Added Successfully' });}); });
        } else {
            let endDate = this.eventModel.end.getTime();
            let startDate = this.eventModel.start.getTime();
            this.eventModel.start = startDate;
            this.eventModel.end = endDate;
            delete this.eventModel.eventid;

            console.log(this.eventModel);
            this.eventService.addEvents(this.eventModel).then(events => { this.msgs.push({ severity: 'info', summary: 'Info Message', detail: 'Event Updated Successfully' }); this.eventService.getEvents(this.courseValue,this.semesterValue,this.classValue).then(events => { console.log(events); this.events = events; }); });
        }
        this.displayDialog = false;
        this.isEdit = false;


    }

    handleCancel(event) {
        this.eventModel = {
            "title": "",
            "start": null,
            "end": null,
            "course": "",
            "semester": "",
            "classId": "", "eventid": ""
        };
        this.displayDialog = false;
        this.isEdit = false;
    }
    handleDelete(event) {
        this.displayDialog = false;
        this.isEdit = false;
        this.eventService.deleteEvents(this.eventModel.eventid).then(events => { this.msgs.push({ severity: 'info', summary: 'Info Message', detail: 'Event Deleted Successfully' });this.eventService.getEvents(this.courseValue,this.semesterValue,this.classValue).then(events => { console.log(events); this.events = events; }); });
    }


    ngOnInit() {

        this.header = {
            left: 'prev,next today',
            center: 'title',
            right: 'month,agendaWeek,agendaDay'
        };
        this.ClassNames = [
            { name: 'Class A', code: 'A' },
            { name: 'Class B', code: 'B' }
            
        ];
          this.events = [
              {
                  "title": "Semester Examination ",
                  "start": "2018-07-12 04:20", "user": "arun"
              },
              {
                  "title": "Semester Examination",
                  "start": "2018-07-12",
                  "end": "2018-07-23", "user": "arun"
              },
              {
                  "title": "Repeating Event",
                  "start": "2018-01-09T18:00:00", "user": "arun"
              },
              {
                  "title": "Repeating Event",
                  "start": "2018-01-16T16:00:00", "user": "arun"
              },
              {
                  "title": "Conference",
                  "start": "2018-01-11",
                  "end": "2018-01-13",
                  "user": "arun"
              }
          ];
        
        this.eventService.getSemesters().then(sem => { console.log(sem); this.semester = sem;if(this.semester.length>0){
            this.semesterValue = this.semester[0].id;
        } });
        
        this.eventService.getCourses().then(sem => { console.log(sem); this.courses = sem; if(this.courses.length>0){
            this.courseValue = this.courses[0].id;
        }});
        
        if(this.ClassNames.length>0){
            this.classValue = this.ClassNames[0].code;
        }

    }
    handleFetchEvents($event) {
        console.log("Course "+ this.courseValue+"  Semester "+this.semesterValue,+" Classs "+this.classValue)
        this.eventService.getEvents(this.courseValue,this.semesterValue,this.classValue ).then(events => { console.log(events); this.events = events; });
    }
    handleclassChange(event) {
        console.log(event);
        this.classValue = this.selectedClass.code;
        this.selectedClass.id = 11;
    }
    handleSemesterChange(event) {
        console.log(event);
        this.semesterValue = this.selectedSemester.id;
    }
    handleCourseChange(event) {
        console.log(event);
        this.courseValue = this.selectedClass.id;
    }
}
