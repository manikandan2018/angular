import { TestBed, inject } from '@angular/core/testing';

import { HhttpcallsService } from './httpcalls.service';

describe('HhttpcallsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [HhttpcallsService]
    });
  });

  it('should be created', inject([HhttpcallsService], (service: HhttpcallsService) => {
    expect(service).toBeTruthy();
  }));
});
