import { Component, OnInit, AfterViewChecked, ViewChildren, AfterViewInit  } from '@angular/core';
import { Http, Response, Headers } from '@angular/Http';
import { HttpClient } from '@angular/common/Http';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { NgModel, FormControl } from '@angular/forms';
import 'rxjs/add/operator/map';

declare var $: any;
declare var Materialize: any;

@Component({
  selector: 'app-stuserdetails',
  templateUrl: './stuserdetails.component.html',
  styleUrls: ['./stuserdetails.component.css']
})
export class STUserdetailsComponent implements  OnInit, AfterViewChecked {

  isLoading: boolean = false;

  basenote: string;
  style: string;
  notelabel: string;
  speedscale: string;
  notespeed: string;
      
  isApproved: string;
  isActive: string;

     
   id: string;
   firstName: string;
   middleName: string;
   lastName: string;
   gender: string;
   firebaseUrl: string;
   permanent_Address: string;
   pA_City: string;
   pA_State: string;
   pin: string;
   occupation: string;
   email: string;
   mobileNumber; string;
   dob: string;
   password: string;
   confPassword: string;
   otpGen: string;
   otpConfirm: string;


   
  
  
editId: string;


  router: Router;
   RAGAMusicProfileCode : string;
  @ViewChildren('allTheseThings') things;

    constructor(_router: Router, private _http: Http, private route: ActivatedRoute) {
    this.router = _router;
     
  }

  private createReminder() {
    this.isLoading = true;
    var data = {
        "firstName": this.firstName,
        "middleName": this.middleName,
        "lastName": this.lastName,
        "gender": this.gender,
        "firebaseUrl": this.firebaseUrl,
        "permanent_Address": this.permanent_Address,
        "pA_City": this.pA_City,
        "pA_State": this.pA_State,
        "pin": this.pin,
        "occupation": this.occupation,
        "email": this.email,
        "mobileNumber": this.mobileNumber,
        "dob": this.dob,
        "password": this.password,
        "confPassword": this.confPassword,
        "otpGen": this.otpGen,
        "otpConfirm": this.otpConfirm,
        "isActive":'y',
        "isAprroved":'y',     
    };
    if(this.firstName==null){
     // this.isLoading = false;
      var $toastContent = $('<span>firstName is Mandatory!</span>');
      this.isLoading = false;
      Materialize.toast($toastContent, 2000);
      return;
    }
    if(this.middleName==null){
     // this.isLoading = false;
      var $toastContent = $('<span>MiddleName is Mandatory!</span>');
      this.isLoading = false;
      Materialize.toast($toastContent, 2000);
      return;
    }
    if(this.lastName==null){
     // this.isLoading = false;
      var $toastContent = $('<span>LastName is Mandatory!</span>');
      this.isLoading = false;
      Materialize.toast($toastContent, 2000);
      return;
    }
    if(this.gender==null){
     // this.isLoading = false;
      var $toastContent = $('<span>Gender is Mandatory!</span>');
      this.isLoading = false;
      Materialize.toast($toastContent, 2000);
      return;
    }
    if(this.firebaseUrl==null){
     // this.isLoading = false;
      var $toastContent = $('<span>firebaseUrl is Mandatory!</span>');
      this.isLoading = false;
      Materialize.toast($toastContent, 2000);
      return;
    }
    if(this.permanent_Address==null){
     // this.isLoading = false;
      var $toastContent = $('<span>permanent_Address is Mandatory!</span>');
      this.isLoading = false;
      Materialize.toast($toastContent, 2000);
      return;
    }
    if(this.pA_City==null){
     // this.isLoading = false;
      var $toastContent = $('<span>pA_City is Mandatory!</span>');
      this.isLoading = false;
      Materialize.toast($toastContent, 2000);
      return;
    }
    if(this.pA_State==null){
     // this.isLoading = false;
      var $toastContent = $('<span>pA_State is Mandatory!</span>');
      this.isLoading = false;
      Materialize.toast($toastContent, 2000);
      return;
    }
    if(this.pin==null){
     // this.isLoading = false;
      var $toastContent = $('<span>pin is Mandatory!</span>');
      this.isLoading = false;
      Materialize.toast($toastContent, 2000);
      return;
    }
    if(this.occupation==null){
     // this.isLoading = false;
      var $toastContent = $('<span>occupation is Mandatory!</span>');
      this.isLoading = false;
      Materialize.toast($toastContent, 2000);
      return;
    }
    if(this.email==null){
     // this.isLoading = false;
      var $toastContent = $('<span>Email is Mandatory!</span>');
      this.isLoading = false;
      Materialize.toast($toastContent, 2000);
      return;
    }
    if(this.mobileNumber==null){
     // this.isLoading = false;
      var $toastContent = $('<span>mobileNumber is Mandatory!</span>');
      this.isLoading = false;
      Materialize.toast($toastContent, 2000);
      return;
    }
    if(this.dob==null){
     // this.isLoading = false;
      var $toastContent = $('<span>dob is Mandatory!</span>');
      this.isLoading = false;
      Materialize.toast($toastContent, 2000);
      return;
    }
    if(this.password==null){
     // this.isLoading = false;
      var $toastContent = $('<span>password is Mandatory!</span>');
      this.isLoading = false;
      Materialize.toast($toastContent, 2000);
      return;
    }
    if(this.confPassword==null){
     // this.isLoading = false;
      var $toastContent = $('<span>confPassword is Mandatory!</span>');
      this.isLoading = false;
      Materialize.toast($toastContent, 2000);
      return;
    }
    if(this.otpGen==null){
     // this.isLoading = false;
      var $toastContent = $('<span>otpGen is Mandatory!</span>');
      this.isLoading = false;
      Materialize.toast($toastContent, 2000);
      return;
    }
    if(this.otpConfirm==null){
     // this.isLoading = false;
      var $toastContent = $('<span>otpConfirm is Mandatory!</span>');
      this.isLoading = false;
      Materialize.toast($toastContent, 2000);
      return;
    }

    if (this.editId  && this.editId !== ""  && this.editId !== "None") {
      data["id"] = this.editId;
      return this._http.put('Http://52.66.246.140:8080/SkillTeck/updateSTUser/', data)
        .subscribe(
        res => {
          console.log(res);
          this.isLoading = false;
          var $toastContent = $('<span>Record has been saved successfully!!</span>');
          Materialize.toast($toastContent, 2000);
          this.router.navigate(['/stuser']);
        },
        err => {
          var $toastContent = $('<span>'+JSON.parse(err["_body"])[0]["errMessage"]+'</span>');
          Materialize.toast($toastContent, 2000);                      
          this.isLoading = false;
        }
        );
    } else {
      return this._http.post('Http://52.66.246.140:8080/SkillTeck/addSTUser/', data)
        .subscribe(
        res => {
          console.log(res);
          this.isLoading = false;
          var $toastContent = $('<span>Record has been saved successfully!!</span>');
          Materialize.toast($toastContent, 2000);
          this.router.navigate(['/stuser']);
        },
        err => {
          var $toastContent = $('<span>'+JSON.parse(err["_body"])[0]["errMessage"]+'</span>');
          Materialize.toast($toastContent, 2000);            
          this.isLoading = false;
        }
        );
    }
  }

  public moveNext(event, tab) {
    $('.collapsible').collapsible('open', tab);
  }

  ngAfterViewInit() {
    this.things.changes.subscribe(t => {
      $("select").material_select();
    })
    
  }

  ngAfterViewChecked() {
   
    Materialize.updateTextFields();

  }
  ngOnInit() {
    $("select").material_select();
    $('.collapsible').collapsible({      
      onOpen: function(el) {  Materialize.updateTextFields(); }
    });

    this.route
      .queryParamMap
      .map(params => params.get('session_id') || 'None')
      .subscribe(val => this.editId = val);

    console.log(this.editId);

    if (this.editId  && this.editId !== ""  && this.editId !== "None") {
      this.isLoading = true;
      return this._http.get('Http://52.66.246.140:8080/SkillTeck/getSTUserById/' + this.editId)
        .map((res: Response) => res.json())
        .subscribe(data => {
          var record = data[0];
      

         this.firstName = record["firstName"];
          this.middleName = record["middleName"];
          this.lastName = record["lastName"];
          this.gender = record["gender"];
          this.firebaseUrl = record["firebaseUrl"];                              
          this.permanent_Address = record["permanent_Address"];
          this.pA_City = record["pA_City"];
          this.pA_State = record["pA_State"];
          this.pin = record["pin"];
          this.occupation = record["occupation"];
          this.email = record["email"];                             
          this.mobileNumber = record["mobileNumber"];
          this.dob = record["dob"];
          this.password = record["password"];
          this.confPassword = record["confPassword"];
          this.otpGen = record["otpGen"];
          this.otpConfirm = record["otpConfirm"];  
          
 
          
          $("select").material_select();         
          Materialize.updateTextFields();
          this.isLoading = false;
          //debugger;
        },
        err => {
          console.log('Something went wrong!');
          this.isLoading = false;
        });
    }



    Materialize.updateTextFields();
  }





}




